(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Random = Package.random.Random;
var meteorInstall = Package.modules.meteorInstall;
var process = Package.modules.process;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Symbol = Package['ecmascript-runtime-server'].Symbol;
var Map = Package['ecmascript-runtime-server'].Map;
var Set = Package['ecmascript-runtime-server'].Set;

/* Package-scope variables */
var UserPresenceSessions, UserPresenceServers;

var require = meteorInstall({"node_modules":{"meteor":{"danimal:userpresence":{"userPresence.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// packages/danimal_userpresence/userPresence.js                                        //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
// serverId - unique per server per restart                                             // 1
var serverId = Random.id(); // user connections                                         // 2
                                                                                        //
UserPresenceSessions = new Mongo.Collection('userpresencesessions'); // list of servers
                                                                                        //
UserPresenceServers = new Mongo.Collection('userpresenceservers');                      // 9
                                                                                        //
UserPresenceServers._ensureIndex({                                                      // 12
  ping: 1                                                                               // 12
});                                                                                     // 12
                                                                                        //
UserPresenceServers._ensureIndex({                                                      // 13
  serverId: 1                                                                           // 13
});                                                                                     // 13
                                                                                        //
Meteor.users._ensureIndex({                                                             // 14
  'presence.serverId': 1                                                                // 14
});                                                                                     // 14
                                                                                        //
UserPresenceSessions._ensureIndex({                                                     // 15
  userId: 1                                                                             // 15
}); // keep track of which servers are online                                           // 15
                                                                                        //
                                                                                        //
Meteor.setInterval(function () {                                                        // 19
  var find = {                                                                          // 20
    serverId: serverId                                                                  // 20
  };                                                                                    // 20
  var modifier = {                                                                      // 21
    $set: {                                                                             // 21
      ping: new Date()                                                                  // 21
    }                                                                                   // 21
  };                                                                                    // 21
  UserPresenceServers.upsert(find, modifier);                                           // 22
}, 1000 * 30); // remove old servers and sessions                                       // 23
// update status of users connected to that server                                      // 27
                                                                                        //
Meteor.setInterval(function () {                                                        // 28
  var cutoff = new Date();                                                              // 29
  cutoff.setMinutes(new Date().getMinutes() - 5);                                       // 30
  UserPresenceServers.find({                                                            // 31
    ping: {                                                                             // 31
      $lt: cutoff                                                                       // 31
    }                                                                                   // 31
  }).forEach(function (server) {                                                        // 31
    UserPresenceServers.remove(server._id);                                             // 32
    UserPresenceSessions.remove({                                                       // 33
      serverId: server.serverId                                                         // 33
    });                                                                                 // 33
    Meteor.users.find({                                                                 // 34
      'presence.serverId': server.serverId                                              // 34
    }).forEach(function (user) {                                                        // 34
      trackUserStatus(user._id);                                                        // 35
    });                                                                                 // 36
  });                                                                                   // 37
}, 1000 * 10); // track user connection and disconnection                               // 38
                                                                                        //
Meteor.publish(null, function () {                                                      // 43
  var self = this;                                                                      // 44
                                                                                        //
  if (self.userId && self.connection && self.connection.id) {                           // 46
    userConnected(self.userId, self.connection);                                        // 47
    self.onStop(function () {                                                           // 49
      userDisconnected(self.userId, self.connection);                                   // 50
    });                                                                                 // 51
  }                                                                                     // 52
                                                                                        //
  self.ready();                                                                         // 54
});                                                                                     // 55
                                                                                        //
var userConnected = function (userId, connection) {                                     // 59
  UserPresenceSessions.insert({                                                         // 60
    serverId: serverId,                                                                 // 60
    userId: userId,                                                                     // 60
    connectionId: connection.id,                                                        // 60
    createdAt: new Date()                                                               // 60
  });                                                                                   // 60
  trackUserStatus(userId, connection);                                                  // 61
};                                                                                      // 62
                                                                                        //
var userDisconnected = function (userId, connection) {                                  // 66
  UserPresenceSessions.remove({                                                         // 67
    userId: userId,                                                                     // 67
    connectionId: connection.id                                                         // 67
  });                                                                                   // 67
  trackUserStatus(userId, connection);                                                  // 68
};                                                                                      // 69
                                                                                        //
var trackUserStatus = function (userId, connection) {                                   // 73
  var presence = {                                                                      // 74
    updatedAt: new Date(),                                                              // 75
    serverId: serverId                                                                  // 76
  };                                                                                    // 74
                                                                                        //
  if (connection) {                                                                     // 79
    presence.clientAddress = connection.clientAddress;                                  // 80
    presence.httpHeaders = connection.httpHeaders;                                      // 81
  }                                                                                     // 82
                                                                                        //
  var isOnline = UserPresenceSessions.find({                                            // 84
    userId: userId                                                                      // 84
  }).count();                                                                           // 84
                                                                                        //
  if (isOnline) {                                                                       // 86
    presence.status = 'online';                                                         // 87
  } else {                                                                              // 88
    presence.status = 'offline';                                                        // 89
  }                                                                                     // 90
                                                                                        //
  Meteor.users.update(userId, {                                                         // 92
    $set: {                                                                             // 92
      presence: presence                                                                // 92
    }                                                                                   // 92
  });                                                                                   // 92
};                                                                                      // 93
//////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./node_modules/meteor/danimal:userpresence/userPresence.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['danimal:userpresence'] = {}, {
  UserPresenceSessions: UserPresenceSessions,
  UserPresenceServers: UserPresenceServers
});

})();

//# sourceMappingURL=danimal_userpresence.js.map
