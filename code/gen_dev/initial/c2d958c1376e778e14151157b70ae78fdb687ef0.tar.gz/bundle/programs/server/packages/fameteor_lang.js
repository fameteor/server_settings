(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

/* Package-scope variables */
var lang;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/fameteor_lang/lib/lang_server.js                         //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
Meteor.methods({
	"lang.add": function (newlanguageCode) {
		Meteor.users.update(
			Meteor.userId(),
			{$set:{"profile.lang":newlanguageCode}}
		);
	}
});
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['fameteor:lang'] = {}, {
  lang: lang
});

})();
