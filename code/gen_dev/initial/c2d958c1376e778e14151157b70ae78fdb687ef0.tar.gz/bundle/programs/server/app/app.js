var require = meteorInstall({"server":{"donneesInitiales":{"addRegistres.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/donneesInitiales/addRegistres.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
addRegistres = [{                                                                                                      // 1
  nbPages: 0,                                                                                                          // 3
  type: "Etat civil",                                                                                                  // 3
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 3
  contenu: "	Mariages	",                                                                                               // 3
  periode: "	1915	",                                                                                                   // 3
  ordreParCommune: 121                                                                                                 // 3
}, {                                                                                                                   // 3
  nbPages: 0,                                                                                                          // 4
  type: "Etat civil",                                                                                                  // 4
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 4
  contenu: "	Mariages	",                                                                                               // 4
  periode: "	1916	",                                                                                                   // 4
  ordreParCommune: 122                                                                                                 // 4
}, {                                                                                                                   // 4
  nbPages: 0,                                                                                                          // 5
  type: "Etat civil",                                                                                                  // 5
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 5
  contenu: "	Mariages	",                                                                                               // 5
  periode: "	1917	",                                                                                                   // 5
  ordreParCommune: 123                                                                                                 // 5
}, {                                                                                                                   // 5
  nbPages: 0,                                                                                                          // 6
  type: "Etat civil",                                                                                                  // 6
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 6
  contenu: "	Mariages	",                                                                                               // 6
  periode: "	1918	",                                                                                                   // 6
  ordreParCommune: 124                                                                                                 // 6
}, {                                                                                                                   // 6
  nbPages: 0,                                                                                                          // 7
  type: "Etat civil",                                                                                                  // 7
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 7
  contenu: "	Mariages	",                                                                                               // 7
  periode: "	1919	",                                                                                                   // 7
  ordreParCommune: 125                                                                                                 // 7
}, {                                                                                                                   // 7
  nbPages: 0,                                                                                                          // 8
  type: "Etat civil",                                                                                                  // 8
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 8
  contenu: "	Mariages	",                                                                                               // 8
  periode: "	1920	",                                                                                                   // 8
  ordreParCommune: 126                                                                                                 // 8
}, {                                                                                                                   // 8
  nbPages: 0,                                                                                                          // 9
  type: "Etat civil",                                                                                                  // 9
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 9
  contenu: "	Mariages	",                                                                                               // 9
  periode: "	1921	",                                                                                                   // 9
  ordreParCommune: 127                                                                                                 // 9
}, {                                                                                                                   // 9
  nbPages: 0,                                                                                                          // 10
  type: "Etat civil",                                                                                                  // 10
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 10
  contenu: "	Mariages	",                                                                                               // 10
  periode: "	1922	",                                                                                                   // 10
  ordreParCommune: 128                                                                                                 // 10
}, {                                                                                                                   // 10
  nbPages: 0,                                                                                                          // 11
  type: "Etat civil",                                                                                                  // 11
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 11
  contenu: "	Mariages	",                                                                                               // 11
  periode: "	1923	",                                                                                                   // 11
  ordreParCommune: 129                                                                                                 // 11
}, {                                                                                                                   // 11
  nbPages: 0,                                                                                                          // 12
  type: "Etat civil",                                                                                                  // 12
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 12
  contenu: "	Mariages	",                                                                                               // 12
  periode: "	1924	",                                                                                                   // 12
  ordreParCommune: 130                                                                                                 // 12
}, {                                                                                                                   // 12
  nbPages: 0,                                                                                                          // 13
  type: "Etat civil",                                                                                                  // 13
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 13
  contenu: "	Mariages	",                                                                                               // 13
  periode: "	1925	",                                                                                                   // 13
  ordreParCommune: 131                                                                                                 // 13
}, {                                                                                                                   // 13
  nbPages: 0,                                                                                                          // 14
  type: "Etat civil",                                                                                                  // 14
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 14
  contenu: "	Mariages	",                                                                                               // 14
  periode: "	1926	",                                                                                                   // 14
  ordreParCommune: 132                                                                                                 // 14
}, {                                                                                                                   // 14
  nbPages: 0,                                                                                                          // 15
  type: "Etat civil",                                                                                                  // 15
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 15
  contenu: "	Mariages	",                                                                                               // 15
  periode: "	1927	",                                                                                                   // 15
  ordreParCommune: 133                                                                                                 // 15
}, {                                                                                                                   // 15
  nbPages: 0,                                                                                                          // 16
  type: "Etat civil",                                                                                                  // 16
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 16
  contenu: "	Mariages	",                                                                                               // 16
  periode: "	1928	",                                                                                                   // 16
  ordreParCommune: 134                                                                                                 // 16
}, {                                                                                                                   // 16
  nbPages: 0,                                                                                                          // 17
  type: "Etat civil",                                                                                                  // 17
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 17
  contenu: "	Mariages	",                                                                                               // 17
  periode: "	1929	",                                                                                                   // 17
  ordreParCommune: 135                                                                                                 // 17
}, {                                                                                                                   // 17
  nbPages: 0,                                                                                                          // 18
  type: "Etat civil",                                                                                                  // 18
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 18
  contenu: "	Mariages	",                                                                                               // 18
  periode: "	1930	",                                                                                                   // 18
  ordreParCommune: 136                                                                                                 // 18
}, {                                                                                                                   // 18
  nbPages: 0,                                                                                                          // 19
  type: "Etat civil",                                                                                                  // 19
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 19
  contenu: "	Mariages	",                                                                                               // 19
  periode: "	1931	",                                                                                                   // 19
  ordreParCommune: 137                                                                                                 // 19
}, {                                                                                                                   // 19
  nbPages: 0,                                                                                                          // 20
  type: "Etat civil",                                                                                                  // 20
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 20
  contenu: "	Mariages	",                                                                                               // 20
  periode: "	1932	",                                                                                                   // 20
  ordreParCommune: 138                                                                                                 // 20
}, {                                                                                                                   // 20
  nbPages: 0,                                                                                                          // 21
  type: "Etat civil",                                                                                                  // 21
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 21
  contenu: "	Mariages	",                                                                                               // 21
  periode: "	1933	",                                                                                                   // 21
  ordreParCommune: 139                                                                                                 // 21
}, {                                                                                                                   // 21
  nbPages: 0,                                                                                                          // 22
  type: "Etat civil",                                                                                                  // 22
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 22
  contenu: "	Mariages	",                                                                                               // 22
  periode: "	1934	",                                                                                                   // 22
  ordreParCommune: 140                                                                                                 // 22
}, {                                                                                                                   // 22
  nbPages: 0,                                                                                                          // 23
  type: "Etat civil",                                                                                                  // 23
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 23
  contenu: "	Mariages	",                                                                                               // 23
  periode: "	1935	",                                                                                                   // 23
  ordreParCommune: 141                                                                                                 // 23
}, {                                                                                                                   // 23
  nbPages: 0,                                                                                                          // 24
  type: "Etat civil",                                                                                                  // 24
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 24
  contenu: "	Mariages	",                                                                                               // 24
  periode: "	1936	",                                                                                                   // 24
  ordreParCommune: 142                                                                                                 // 24
}, {                                                                                                                   // 24
  nbPages: 0,                                                                                                          // 25
  type: "Etat civil",                                                                                                  // 25
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 25
  contenu: "	Mariages	",                                                                                               // 25
  periode: "	1937	",                                                                                                   // 25
  ordreParCommune: 143                                                                                                 // 25
}, {                                                                                                                   // 25
  nbPages: 0,                                                                                                          // 26
  type: "Etat civil",                                                                                                  // 26
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 26
  contenu: "	Mariages	",                                                                                               // 26
  periode: "	1938	",                                                                                                   // 26
  ordreParCommune: 144                                                                                                 // 26
}, {                                                                                                                   // 26
  nbPages: 0,                                                                                                          // 27
  type: "Etat civil",                                                                                                  // 27
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 27
  contenu: "	Mariages	",                                                                                               // 27
  periode: "	1939	",                                                                                                   // 27
  ordreParCommune: 145                                                                                                 // 27
}, {                                                                                                                   // 27
  nbPages: 0,                                                                                                          // 28
  type: "Etat civil",                                                                                                  // 28
  commune: "Y8xw3Ea68Jwv6Txdb",                                                                                        // 28
  contenu: "	Mariages	",                                                                                               // 28
  periode: "	1940	",                                                                                                   // 28
  ordreParCommune: 146                                                                                                 // 28
}, {                                                                                                                   // 28
  nbPages: 0,                                                                                                          // 29
  type: "Etat civil",                                                                                                  // 29
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 29
  contenu: "	Mariages	",                                                                                               // 29
  periode: "	1906	",                                                                                                   // 29
  ordreParCommune: 136                                                                                                 // 29
}, {                                                                                                                   // 29
  nbPages: 0,                                                                                                          // 30
  type: "Etat civil",                                                                                                  // 30
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 30
  contenu: "	Mariages	",                                                                                               // 30
  periode: "	1907	",                                                                                                   // 30
  ordreParCommune: 137                                                                                                 // 30
}, {                                                                                                                   // 30
  nbPages: 0,                                                                                                          // 31
  type: "Etat civil",                                                                                                  // 31
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 31
  contenu: "	Mariages	",                                                                                               // 31
  periode: "	1908	",                                                                                                   // 31
  ordreParCommune: 138                                                                                                 // 31
}, {                                                                                                                   // 31
  nbPages: 0,                                                                                                          // 32
  type: "Etat civil",                                                                                                  // 32
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 32
  contenu: "	Mariages	",                                                                                               // 32
  periode: "	1909	",                                                                                                   // 32
  ordreParCommune: 139                                                                                                 // 32
}, {                                                                                                                   // 32
  nbPages: 0,                                                                                                          // 33
  type: "Etat civil",                                                                                                  // 33
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 33
  contenu: "	Mariages	",                                                                                               // 33
  periode: "	1910	",                                                                                                   // 33
  ordreParCommune: 140                                                                                                 // 33
}, {                                                                                                                   // 33
  nbPages: 0,                                                                                                          // 34
  type: "Etat civil",                                                                                                  // 34
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 34
  contenu: "	Mariages	",                                                                                               // 34
  periode: "	1911	",                                                                                                   // 34
  ordreParCommune: 141                                                                                                 // 34
}, {                                                                                                                   // 34
  nbPages: 0,                                                                                                          // 35
  type: "Etat civil",                                                                                                  // 35
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 35
  contenu: "	Mariages	",                                                                                               // 35
  periode: "	1912	",                                                                                                   // 35
  ordreParCommune: 142                                                                                                 // 35
}, {                                                                                                                   // 35
  nbPages: 0,                                                                                                          // 36
  type: "Etat civil",                                                                                                  // 36
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 36
  contenu: "	Mariages	",                                                                                               // 36
  periode: "	1913	",                                                                                                   // 36
  ordreParCommune: 143                                                                                                 // 36
}, {                                                                                                                   // 36
  nbPages: 0,                                                                                                          // 37
  type: "Etat civil",                                                                                                  // 37
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 37
  contenu: "	Mariages	",                                                                                               // 37
  periode: "	1914	",                                                                                                   // 37
  ordreParCommune: 144                                                                                                 // 37
}, {                                                                                                                   // 37
  nbPages: 0,                                                                                                          // 38
  type: "Etat civil",                                                                                                  // 38
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 38
  contenu: "	Mariages	",                                                                                               // 38
  periode: "	1915	",                                                                                                   // 38
  ordreParCommune: 145                                                                                                 // 38
}, {                                                                                                                   // 38
  nbPages: 0,                                                                                                          // 39
  type: "Etat civil",                                                                                                  // 39
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 39
  contenu: "	Mariages	",                                                                                               // 39
  periode: "	1916	",                                                                                                   // 39
  ordreParCommune: 146                                                                                                 // 39
}, {                                                                                                                   // 39
  nbPages: 0,                                                                                                          // 40
  type: "Etat civil",                                                                                                  // 40
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 40
  contenu: "	Mariages	",                                                                                               // 40
  periode: "	1917	",                                                                                                   // 40
  ordreParCommune: 147                                                                                                 // 40
}, {                                                                                                                   // 40
  nbPages: 0,                                                                                                          // 41
  type: "Etat civil",                                                                                                  // 41
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 41
  contenu: "	Mariages	",                                                                                               // 41
  periode: "	1918	",                                                                                                   // 41
  ordreParCommune: 148                                                                                                 // 41
}, {                                                                                                                   // 41
  nbPages: 0,                                                                                                          // 42
  type: "Etat civil",                                                                                                  // 42
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 42
  contenu: "	Mariages	",                                                                                               // 42
  periode: "	1919	",                                                                                                   // 42
  ordreParCommune: 149                                                                                                 // 42
}, {                                                                                                                   // 42
  nbPages: 0,                                                                                                          // 43
  type: "Etat civil",                                                                                                  // 43
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 43
  contenu: "	Mariages	",                                                                                               // 43
  periode: "	1920	",                                                                                                   // 43
  ordreParCommune: 150                                                                                                 // 43
}, {                                                                                                                   // 43
  nbPages: 0,                                                                                                          // 44
  type: "Etat civil",                                                                                                  // 44
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 44
  contenu: "	Mariages	",                                                                                               // 44
  periode: "	1921	",                                                                                                   // 44
  ordreParCommune: 151                                                                                                 // 44
}, {                                                                                                                   // 44
  nbPages: 0,                                                                                                          // 45
  type: "Etat civil",                                                                                                  // 45
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 45
  contenu: "	Mariages	",                                                                                               // 45
  periode: "	1922	",                                                                                                   // 45
  ordreParCommune: 152                                                                                                 // 45
}, {                                                                                                                   // 45
  nbPages: 0,                                                                                                          // 46
  type: "Etat civil",                                                                                                  // 46
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 46
  contenu: "	Mariages	",                                                                                               // 46
  periode: "	1923	",                                                                                                   // 46
  ordreParCommune: 153                                                                                                 // 46
}, {                                                                                                                   // 46
  nbPages: 0,                                                                                                          // 47
  type: "Etat civil",                                                                                                  // 47
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 47
  contenu: "	Mariages	",                                                                                               // 47
  periode: "	1924	",                                                                                                   // 47
  ordreParCommune: 154                                                                                                 // 47
}, {                                                                                                                   // 47
  nbPages: 0,                                                                                                          // 48
  type: "Etat civil",                                                                                                  // 48
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 48
  contenu: "	Mariages	",                                                                                               // 48
  periode: "	1925	",                                                                                                   // 48
  ordreParCommune: 155                                                                                                 // 48
}, {                                                                                                                   // 48
  nbPages: 0,                                                                                                          // 49
  type: "Etat civil",                                                                                                  // 49
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 49
  contenu: "	Mariages	",                                                                                               // 49
  periode: "	1926	",                                                                                                   // 49
  ordreParCommune: 156                                                                                                 // 49
}, {                                                                                                                   // 49
  nbPages: 0,                                                                                                          // 50
  type: "Etat civil",                                                                                                  // 50
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 50
  contenu: "	Mariages	",                                                                                               // 50
  periode: "	1927	",                                                                                                   // 50
  ordreParCommune: 157                                                                                                 // 50
}, {                                                                                                                   // 50
  nbPages: 0,                                                                                                          // 51
  type: "Etat civil",                                                                                                  // 51
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 51
  contenu: "	Mariages	",                                                                                               // 51
  periode: "	1928	",                                                                                                   // 51
  ordreParCommune: 158                                                                                                 // 51
}, {                                                                                                                   // 51
  nbPages: 0,                                                                                                          // 52
  type: "Etat civil",                                                                                                  // 52
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 52
  contenu: "	Mariages	",                                                                                               // 52
  periode: "	1929	",                                                                                                   // 52
  ordreParCommune: 159                                                                                                 // 52
}, {                                                                                                                   // 52
  nbPages: 0,                                                                                                          // 53
  type: "Etat civil",                                                                                                  // 53
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 53
  contenu: "	Mariages	",                                                                                               // 53
  periode: "	1930	",                                                                                                   // 53
  ordreParCommune: 160                                                                                                 // 53
}, {                                                                                                                   // 53
  nbPages: 0,                                                                                                          // 54
  type: "Etat civil",                                                                                                  // 54
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 54
  contenu: "	Mariages	",                                                                                               // 54
  periode: "	1931	",                                                                                                   // 54
  ordreParCommune: 161                                                                                                 // 54
}, {                                                                                                                   // 54
  nbPages: 0,                                                                                                          // 55
  type: "Etat civil",                                                                                                  // 55
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 55
  contenu: "	Mariages	",                                                                                               // 55
  periode: "	1932	",                                                                                                   // 55
  ordreParCommune: 162                                                                                                 // 55
}, {                                                                                                                   // 55
  nbPages: 0,                                                                                                          // 56
  type: "Etat civil",                                                                                                  // 56
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 56
  contenu: "	Mariages	",                                                                                               // 56
  periode: "	1933	",                                                                                                   // 56
  ordreParCommune: 163                                                                                                 // 56
}, {                                                                                                                   // 56
  nbPages: 0,                                                                                                          // 57
  type: "Etat civil",                                                                                                  // 57
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 57
  contenu: "	Mariages	",                                                                                               // 57
  periode: "	1934	",                                                                                                   // 57
  ordreParCommune: 164                                                                                                 // 57
}, {                                                                                                                   // 57
  nbPages: 0,                                                                                                          // 58
  type: "Etat civil",                                                                                                  // 58
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 58
  contenu: "	Mariages	",                                                                                               // 58
  periode: "	1935	",                                                                                                   // 58
  ordreParCommune: 165                                                                                                 // 58
}, {                                                                                                                   // 58
  nbPages: 0,                                                                                                          // 59
  type: "Etat civil",                                                                                                  // 59
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 59
  contenu: "	Mariages	",                                                                                               // 59
  periode: "	1936	",                                                                                                   // 59
  ordreParCommune: 166                                                                                                 // 59
}, {                                                                                                                   // 59
  nbPages: 0,                                                                                                          // 60
  type: "Etat civil",                                                                                                  // 60
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 60
  contenu: "	Mariages	",                                                                                               // 60
  periode: "	1937	",                                                                                                   // 60
  ordreParCommune: 167                                                                                                 // 60
}, {                                                                                                                   // 60
  nbPages: 0,                                                                                                          // 61
  type: "Etat civil",                                                                                                  // 61
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 61
  contenu: "	Mariages	",                                                                                               // 61
  periode: "	1938	",                                                                                                   // 61
  ordreParCommune: 168                                                                                                 // 61
}, {                                                                                                                   // 61
  nbPages: 0,                                                                                                          // 62
  type: "Etat civil",                                                                                                  // 62
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 62
  contenu: "	Mariages	",                                                                                               // 62
  periode: "	1939	",                                                                                                   // 62
  ordreParCommune: 169                                                                                                 // 62
}, {                                                                                                                   // 62
  nbPages: 0,                                                                                                          // 63
  type: "Etat civil",                                                                                                  // 63
  commune: "cQuv6u45kZNuuBK5d",                                                                                        // 63
  contenu: "	Mariages	",                                                                                               // 63
  periode: "	1940	",                                                                                                   // 63
  ordreParCommune: 170                                                                                                 // 63
}, {                                                                                                                   // 63
  nbPages: 0,                                                                                                          // 64
  type: "Etat civil",                                                                                                  // 64
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 64
  contenu: "	Mariages	",                                                                                               // 64
  periode: "	1918	",                                                                                                   // 64
  ordreParCommune: 142                                                                                                 // 64
}, {                                                                                                                   // 64
  nbPages: 0,                                                                                                          // 65
  type: "Etat civil",                                                                                                  // 65
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 65
  contenu: "	Mariages	",                                                                                               // 65
  periode: "	1919	",                                                                                                   // 65
  ordreParCommune: 143                                                                                                 // 65
}, {                                                                                                                   // 65
  nbPages: 0,                                                                                                          // 66
  type: "Etat civil",                                                                                                  // 66
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 66
  contenu: "	Mariages	",                                                                                               // 66
  periode: "	1920	",                                                                                                   // 66
  ordreParCommune: 144                                                                                                 // 66
}, {                                                                                                                   // 66
  nbPages: 0,                                                                                                          // 67
  type: "Etat civil",                                                                                                  // 67
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 67
  contenu: "	Mariages	",                                                                                               // 67
  periode: "	1921	",                                                                                                   // 67
  ordreParCommune: 145                                                                                                 // 67
}, {                                                                                                                   // 67
  nbPages: 0,                                                                                                          // 68
  type: "Etat civil",                                                                                                  // 68
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 68
  contenu: "	Mariages	",                                                                                               // 68
  periode: "	1922	",                                                                                                   // 68
  ordreParCommune: 146                                                                                                 // 68
}, {                                                                                                                   // 68
  nbPages: 0,                                                                                                          // 69
  type: "Etat civil",                                                                                                  // 69
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 69
  contenu: "	Mariages	",                                                                                               // 69
  periode: "	1923	",                                                                                                   // 69
  ordreParCommune: 147                                                                                                 // 69
}, {                                                                                                                   // 69
  nbPages: 0,                                                                                                          // 70
  type: "Etat civil",                                                                                                  // 70
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 70
  contenu: "	Mariages	",                                                                                               // 70
  periode: "	1924	",                                                                                                   // 70
  ordreParCommune: 148                                                                                                 // 70
}, {                                                                                                                   // 70
  nbPages: 0,                                                                                                          // 71
  type: "Etat civil",                                                                                                  // 71
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 71
  contenu: "	Mariages	",                                                                                               // 71
  periode: "	1925	",                                                                                                   // 71
  ordreParCommune: 149                                                                                                 // 71
}, {                                                                                                                   // 71
  nbPages: 0,                                                                                                          // 72
  type: "Etat civil",                                                                                                  // 72
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 72
  contenu: "	Mariages	",                                                                                               // 72
  periode: "	1926	",                                                                                                   // 72
  ordreParCommune: 150                                                                                                 // 72
}, {                                                                                                                   // 72
  nbPages: 0,                                                                                                          // 73
  type: "Etat civil",                                                                                                  // 73
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 73
  contenu: "	Mariages	",                                                                                               // 73
  periode: "	1927	",                                                                                                   // 73
  ordreParCommune: 151                                                                                                 // 73
}, {                                                                                                                   // 73
  nbPages: 0,                                                                                                          // 74
  type: "Etat civil",                                                                                                  // 74
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 74
  contenu: "	Mariages	",                                                                                               // 74
  periode: "	1928	",                                                                                                   // 74
  ordreParCommune: 152                                                                                                 // 74
}, {                                                                                                                   // 74
  nbPages: 0,                                                                                                          // 75
  type: "Etat civil",                                                                                                  // 75
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 75
  contenu: "	Mariages	",                                                                                               // 75
  periode: "	1929	",                                                                                                   // 75
  ordreParCommune: 153                                                                                                 // 75
}, {                                                                                                                   // 75
  nbPages: 0,                                                                                                          // 76
  type: "Etat civil",                                                                                                  // 76
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 76
  contenu: "	Mariages	",                                                                                               // 76
  periode: "	1930	",                                                                                                   // 76
  ordreParCommune: 154                                                                                                 // 76
}, {                                                                                                                   // 76
  nbPages: 0,                                                                                                          // 77
  type: "Etat civil",                                                                                                  // 77
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 77
  contenu: "	Mariages	",                                                                                               // 77
  periode: "	1931	",                                                                                                   // 77
  ordreParCommune: 155                                                                                                 // 77
}, {                                                                                                                   // 77
  nbPages: 0,                                                                                                          // 78
  type: "Etat civil",                                                                                                  // 78
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 78
  contenu: "	Mariages	",                                                                                               // 78
  periode: "	1932	",                                                                                                   // 78
  ordreParCommune: 156                                                                                                 // 78
}, {                                                                                                                   // 78
  nbPages: 0,                                                                                                          // 79
  type: "Etat civil",                                                                                                  // 79
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 79
  contenu: "	Mariages	",                                                                                               // 79
  periode: "	1933	",                                                                                                   // 79
  ordreParCommune: 157                                                                                                 // 79
}, {                                                                                                                   // 79
  nbPages: 0,                                                                                                          // 80
  type: "Etat civil",                                                                                                  // 80
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 80
  contenu: "	Mariages	",                                                                                               // 80
  periode: "	1934	",                                                                                                   // 80
  ordreParCommune: 158                                                                                                 // 80
}, {                                                                                                                   // 80
  nbPages: 0,                                                                                                          // 81
  type: "Etat civil",                                                                                                  // 81
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 81
  contenu: "	Mariages	",                                                                                               // 81
  periode: "	1935	",                                                                                                   // 81
  ordreParCommune: 159                                                                                                 // 81
}, {                                                                                                                   // 81
  nbPages: 0,                                                                                                          // 82
  type: "Etat civil",                                                                                                  // 82
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 82
  contenu: "	Mariages	",                                                                                               // 82
  periode: "	1936	",                                                                                                   // 82
  ordreParCommune: 160                                                                                                 // 82
}, {                                                                                                                   // 82
  nbPages: 0,                                                                                                          // 83
  type: "Etat civil",                                                                                                  // 83
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 83
  contenu: "	Mariages	",                                                                                               // 83
  periode: "	1937	",                                                                                                   // 83
  ordreParCommune: 161                                                                                                 // 83
}, {                                                                                                                   // 83
  nbPages: 0,                                                                                                          // 84
  type: "Etat civil",                                                                                                  // 84
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 84
  contenu: "	Mariages	",                                                                                               // 84
  periode: "	1938	",                                                                                                   // 84
  ordreParCommune: 162                                                                                                 // 84
}, {                                                                                                                   // 84
  nbPages: 0,                                                                                                          // 85
  type: "Etat civil",                                                                                                  // 85
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 85
  contenu: "	Mariages	",                                                                                               // 85
  periode: "	1939	",                                                                                                   // 85
  ordreParCommune: 163                                                                                                 // 85
}, {                                                                                                                   // 85
  nbPages: 0,                                                                                                          // 86
  type: "Etat civil",                                                                                                  // 86
  commune: "Swjzw7uTvSXcSn644",                                                                                        // 86
  contenu: "	Mariages	",                                                                                               // 86
  periode: "	1940	",                                                                                                   // 86
  ordreParCommune: 164                                                                                                 // 86
}];                                                                                                                    // 86
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"chargementCadastres.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/donneesInitiales/chargementCadastres.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
chargementCadastres = [{                                                                                               // 1
  "type": "CADASTRE",                                                                                                  // 2
  "codage": "GEO_REF",                                                                                                 // 2
  "source": {                                                                                                          // 2
    "intitule": "Archives départementales 85",                                                                         // 2
    "id": "3P_234_AD_002",                                                                                             // 2
    "libreDeDroits": false                                                                                             // 2
  },                                                                                                                   // 2
  "titre": "Cadastre du Saint Jean de Monts : Section A1 de la Ferme",                                                 // 2
  "specif": {                                                                                                          // 2
    "IMAGE_mode": "IMAGE",                                                                                             // 2
    "IMAGE_px": "0",                                                                                                   // 2
    "IMAGE_py": 0,                                                                                                     // 2
    "IMAGE_nbPages": "1"                                                                                               // 2
  },                                                                                                                   // 2
  "date": {                                                                                                            // 2
    "type": "LE",                                                                                                      // 2
    "a1": 1831                                                                                                         // 2
  },                                                                                                                   // 2
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_a1.jpg",                                                             // 2
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_a1_ico.jpg",                                                             // 2
  "comment": ""                                                                                                        // 2
}, {                                                                                                                   // 2
  "type": "CADASTRE",                                                                                                  // 3
  "codage": "GEO_REF",                                                                                                 // 3
  "source": {                                                                                                          // 3
    "intitule": "Archives départementales 85",                                                                         // 3
    "id": "3P_234_AD_003",                                                                                             // 3
    "libreDeDroits": false                                                                                             // 3
  },                                                                                                                   // 3
  "titre": "Cadastre du Saint Jean de Monts : Section A2 de la Ferme",                                                 // 3
  "specif": {                                                                                                          // 3
    "IMAGE_mode": "IMAGE",                                                                                             // 3
    "IMAGE_px": "0",                                                                                                   // 3
    "IMAGE_py": 0,                                                                                                     // 3
    "IMAGE_nbPages": "1"                                                                                               // 3
  },                                                                                                                   // 3
  "date": {                                                                                                            // 3
    "type": "LE",                                                                                                      // 3
    "a1": 1831                                                                                                         // 3
  },                                                                                                                   // 3
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_a2.jpg",                                                             // 3
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_a2_ico.jpg",                                                             // 3
  "comment": ""                                                                                                        // 3
}, {                                                                                                                   // 3
  "type": "CADASTRE",                                                                                                  // 4
  "codage": "GEO_REF",                                                                                                 // 4
  "source": {                                                                                                          // 4
    "intitule": "Archives départementales 85",                                                                         // 4
    "id": "3P_234_AD_004",                                                                                             // 4
    "libreDeDroits": false                                                                                             // 4
  },                                                                                                                   // 4
  "titre": "Cadastre du Saint Jean de Monts : Section A3 de la Ferme",                                                 // 4
  "specif": {                                                                                                          // 4
    "IMAGE_mode": "IMAGE",                                                                                             // 4
    "IMAGE_px": "0",                                                                                                   // 4
    "IMAGE_py": 0,                                                                                                     // 4
    "IMAGE_nbPages": "1"                                                                                               // 4
  },                                                                                                                   // 4
  "date": {                                                                                                            // 4
    "type": "LE",                                                                                                      // 4
    "a1": 1831                                                                                                         // 4
  },                                                                                                                   // 4
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_a3.jpg",                                                             // 4
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_a3_ico.jpg",                                                             // 4
  "comment": ""                                                                                                        // 4
}, {                                                                                                                   // 4
  "type": "CADASTRE",                                                                                                  // 5
  "codage": "GEO_REF",                                                                                                 // 5
  "source": {                                                                                                          // 5
    "intitule": "Archives départementales 85",                                                                         // 5
    "id": "3P_234_AD_005",                                                                                             // 5
    "libreDeDroits": false                                                                                             // 5
  },                                                                                                                   // 5
  "titre": "Cadastre du Saint Jean de Monts : Section B1 des Rouchères",                                               // 5
  "specif": {                                                                                                          // 5
    "IMAGE_mode": "IMAGE",                                                                                             // 5
    "IMAGE_px": "0",                                                                                                   // 5
    "IMAGE_py": 0,                                                                                                     // 5
    "IMAGE_nbPages": "1"                                                                                               // 5
  },                                                                                                                   // 5
  "date": {                                                                                                            // 5
    "type": "LE",                                                                                                      // 5
    "a1": 1831                                                                                                         // 5
  },                                                                                                                   // 5
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_b1.jpg",                                                             // 5
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_b1_ico.jpg",                                                             // 5
  "comment": ""                                                                                                        // 5
}, {                                                                                                                   // 5
  "type": "CADASTRE",                                                                                                  // 6
  "codage": "GEO_REF",                                                                                                 // 6
  "source": {                                                                                                          // 6
    "intitule": "Archives départementales 85",                                                                         // 6
    "id": "3P_234_AD_006",                                                                                             // 6
    "libreDeDroits": false                                                                                             // 6
  },                                                                                                                   // 6
  "titre": "Cadastre du Saint Jean de Monts : Section B2 des Rouchères",                                               // 6
  "specif": {                                                                                                          // 6
    "IMAGE_mode": "IMAGE",                                                                                             // 6
    "IMAGE_px": "0",                                                                                                   // 6
    "IMAGE_py": 0,                                                                                                     // 6
    "IMAGE_nbPages": "1"                                                                                               // 6
  },                                                                                                                   // 6
  "date": {                                                                                                            // 6
    "type": "LE",                                                                                                      // 6
    "a1": 1831                                                                                                         // 6
  },                                                                                                                   // 6
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_b2.jpg",                                                             // 6
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_b2_ico.jpg",                                                             // 6
  "comment": ""                                                                                                        // 6
}, {                                                                                                                   // 6
  "type": "CADASTRE",                                                                                                  // 7
  "codage": "GEO_REF",                                                                                                 // 7
  "source": {                                                                                                          // 7
    "intitule": "Archives départementales 85",                                                                         // 7
    "id": "3P_234_AD_007",                                                                                             // 7
    "libreDeDroits": false                                                                                             // 7
  },                                                                                                                   // 7
  "titre": "Cadastre du Saint Jean de Monts : Section C1 des Amiaux",                                                  // 7
  "specif": {                                                                                                          // 7
    "IMAGE_mode": "IMAGE",                                                                                             // 7
    "IMAGE_px": "0",                                                                                                   // 7
    "IMAGE_py": 0,                                                                                                     // 7
    "IMAGE_nbPages": "1"                                                                                               // 7
  },                                                                                                                   // 7
  "date": {                                                                                                            // 7
    "type": "LE",                                                                                                      // 7
    "a1": 1831                                                                                                         // 7
  },                                                                                                                   // 7
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_c1.jpg",                                                             // 7
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_c1_ico.jpg",                                                             // 7
  "comment": ""                                                                                                        // 7
}, {                                                                                                                   // 7
  "type": "CADASTRE",                                                                                                  // 8
  "codage": "GEO_REF",                                                                                                 // 8
  "source": {                                                                                                          // 8
    "intitule": "Archives départementales 85",                                                                         // 8
    "id": "3P_234_AD_008",                                                                                             // 8
    "libreDeDroits": false                                                                                             // 8
  },                                                                                                                   // 8
  "titre": "Cadastre du Saint Jean de Monts : Section C2 des Amiaux",                                                  // 8
  "specif": {                                                                                                          // 8
    "IMAGE_mode": "IMAGE",                                                                                             // 8
    "IMAGE_px": "0",                                                                                                   // 8
    "IMAGE_py": 0,                                                                                                     // 8
    "IMAGE_nbPages": "1"                                                                                               // 8
  },                                                                                                                   // 8
  "date": {                                                                                                            // 8
    "type": "LE",                                                                                                      // 8
    "a1": 1831                                                                                                         // 8
  },                                                                                                                   // 8
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_c2.jpg",                                                             // 8
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_c2_ico.jpg",                                                             // 8
  "comment": ""                                                                                                        // 8
}, {                                                                                                                   // 8
  "type": "CADASTRE",                                                                                                  // 9
  "codage": "GEO_REF",                                                                                                 // 9
  "source": {                                                                                                          // 9
    "intitule": "Archives départementales 85",                                                                         // 9
    "id": "3P_234_AD_009",                                                                                             // 9
    "libreDeDroits": false                                                                                             // 9
  },                                                                                                                   // 9
  "titre": "Cadastre du Saint Jean de Monts : Section D1 de la Foucherie",                                             // 9
  "specif": {                                                                                                          // 9
    "IMAGE_mode": "IMAGE",                                                                                             // 9
    "IMAGE_px": "0",                                                                                                   // 9
    "IMAGE_py": 0,                                                                                                     // 9
    "IMAGE_nbPages": "1"                                                                                               // 9
  },                                                                                                                   // 9
  "date": {                                                                                                            // 9
    "type": "LE",                                                                                                      // 9
    "a1": 1831                                                                                                         // 9
  },                                                                                                                   // 9
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_d1.jpg",                                                             // 9
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_d1_ico.jpg",                                                             // 9
  "comment": ""                                                                                                        // 9
}, {                                                                                                                   // 9
  "type": "CADASTRE",                                                                                                  // 10
  "codage": "GEO_REF",                                                                                                 // 10
  "source": {                                                                                                          // 10
    "intitule": "Archives départementales 85",                                                                         // 10
    "id": "3P_234_AD_010",                                                                                             // 10
    "libreDeDroits": false                                                                                             // 10
  },                                                                                                                   // 10
  "titre": "Cadastre du Saint Jean de Monts : Section D2 de la Foucherie",                                             // 10
  "specif": {                                                                                                          // 10
    "IMAGE_mode": "IMAGE",                                                                                             // 10
    "IMAGE_px": "0",                                                                                                   // 10
    "IMAGE_py": 0,                                                                                                     // 10
    "IMAGE_nbPages": "1"                                                                                               // 10
  },                                                                                                                   // 10
  "date": {                                                                                                            // 10
    "type": "LE",                                                                                                      // 10
    "a1": 1831                                                                                                         // 10
  },                                                                                                                   // 10
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_d2.jpg",                                                             // 10
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_d2_ico.jpg",                                                             // 10
  "comment": ""                                                                                                        // 10
}, {                                                                                                                   // 10
  "type": "CADASTRE",                                                                                                  // 11
  "codage": "GEO_REF",                                                                                                 // 11
  "source": {                                                                                                          // 11
    "intitule": "Archives départementales 85",                                                                         // 11
    "id": "3P_234_AD_011",                                                                                             // 11
    "libreDeDroits": false                                                                                             // 11
  },                                                                                                                   // 11
  "titre": "Cadastre du Saint Jean de Monts : Section E1 des Brétinières",                                             // 11
  "specif": {                                                                                                          // 11
    "IMAGE_mode": "IMAGE",                                                                                             // 11
    "IMAGE_px": "0",                                                                                                   // 11
    "IMAGE_py": 0,                                                                                                     // 11
    "IMAGE_nbPages": "1"                                                                                               // 11
  },                                                                                                                   // 11
  "date": {                                                                                                            // 11
    "type": "LE",                                                                                                      // 11
    "a1": 1831                                                                                                         // 11
  },                                                                                                                   // 11
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_e1.jpg",                                                             // 11
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_e1_ico.jpg",                                                             // 11
  "comment": ""                                                                                                        // 11
}, {                                                                                                                   // 11
  "type": "CADASTRE",                                                                                                  // 12
  "codage": "GEO_REF",                                                                                                 // 12
  "source": {                                                                                                          // 12
    "intitule": "Archives départementales 85",                                                                         // 12
    "id": "3P_234_AD_012",                                                                                             // 12
    "libreDeDroits": false                                                                                             // 12
  },                                                                                                                   // 12
  "titre": "Cadastre du Saint Jean de Monts : Section E2 des Brétinières",                                             // 12
  "specif": {                                                                                                          // 12
    "IMAGE_mode": "IMAGE",                                                                                             // 12
    "IMAGE_px": "0",                                                                                                   // 12
    "IMAGE_py": 0,                                                                                                     // 12
    "IMAGE_nbPages": "1"                                                                                               // 12
  },                                                                                                                   // 12
  "date": {                                                                                                            // 12
    "type": "LE",                                                                                                      // 12
    "a1": 1831                                                                                                         // 12
  },                                                                                                                   // 12
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_e2.jpg",                                                             // 12
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_e2_ico.jpg",                                                             // 12
  "comment": ""                                                                                                        // 12
}, {                                                                                                                   // 12
  "type": "CADASTRE",                                                                                                  // 13
  "codage": "GEO_REF",                                                                                                 // 13
  "source": {                                                                                                          // 13
    "intitule": "Archives départementales 85",                                                                         // 13
    "id": "3P_234_AD_013",                                                                                             // 13
    "libreDeDroits": false                                                                                             // 13
  },                                                                                                                   // 13
  "titre": "Cadastre du Saint Jean de Monts : Section E3 des Brétinières",                                             // 13
  "specif": {                                                                                                          // 13
    "IMAGE_mode": "IMAGE",                                                                                             // 13
    "IMAGE_px": "0",                                                                                                   // 13
    "IMAGE_py": 0,                                                                                                     // 13
    "IMAGE_nbPages": "1"                                                                                               // 13
  },                                                                                                                   // 13
  "date": {                                                                                                            // 13
    "type": "LE",                                                                                                      // 13
    "a1": 1831                                                                                                         // 13
  },                                                                                                                   // 13
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_e3.jpg",                                                             // 13
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_e3_ico.jpg",                                                             // 13
  "comment": ""                                                                                                        // 13
}, {                                                                                                                   // 13
  "type": "CADASTRE",                                                                                                  // 14
  "codage": "GEO_REF",                                                                                                 // 14
  "source": {                                                                                                          // 14
    "intitule": "Archives départementales 85",                                                                         // 14
    "id": "3P_234_AD_014",                                                                                             // 14
    "libreDeDroits": false                                                                                             // 14
  },                                                                                                                   // 14
  "titre": "Cadastre du Saint Jean de Monts : Section E4 des Brétinières",                                             // 14
  "specif": {                                                                                                          // 14
    "IMAGE_mode": "IMAGE",                                                                                             // 14
    "IMAGE_px": "0",                                                                                                   // 14
    "IMAGE_py": 0,                                                                                                     // 14
    "IMAGE_nbPages": "1"                                                                                               // 14
  },                                                                                                                   // 14
  "date": {                                                                                                            // 14
    "type": "LE",                                                                                                      // 14
    "a1": 1831                                                                                                         // 14
  },                                                                                                                   // 14
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_e4.jpg",                                                             // 14
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_e4_ico.jpg",                                                             // 14
  "comment": ""                                                                                                        // 14
}, {                                                                                                                   // 14
  "type": "CADASTRE",                                                                                                  // 15
  "codage": "GEO_REF",                                                                                                 // 15
  "source": {                                                                                                          // 15
    "intitule": "Archives départementales 85",                                                                         // 15
    "id": "3P_234_AD_015",                                                                                             // 15
    "libreDeDroits": false                                                                                             // 15
  },                                                                                                                   // 15
  "titre": "Cadastre du Saint Jean de Monts : Section F1 du Bois Maçon",                                               // 15
  "specif": {                                                                                                          // 15
    "IMAGE_mode": "IMAGE",                                                                                             // 15
    "IMAGE_px": "0",                                                                                                   // 15
    "IMAGE_py": 0,                                                                                                     // 15
    "IMAGE_nbPages": "1"                                                                                               // 15
  },                                                                                                                   // 15
  "date": {                                                                                                            // 15
    "type": "LE",                                                                                                      // 15
    "a1": 1831                                                                                                         // 15
  },                                                                                                                   // 15
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_f1.jpg",                                                             // 15
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_f1_ico.jpg",                                                             // 15
  "comment": ""                                                                                                        // 15
}, {                                                                                                                   // 15
  "type": "CADASTRE",                                                                                                  // 16
  "codage": "GEO_REF",                                                                                                 // 16
  "source": {                                                                                                          // 16
    "intitule": "Archives départementales 85",                                                                         // 16
    "id": "3P_234_AD_016",                                                                                             // 16
    "libreDeDroits": false                                                                                             // 16
  },                                                                                                                   // 16
  "titre": "Cadastre du Saint Jean de Monts : Section F2 du Bois Maçon",                                               // 16
  "specif": {                                                                                                          // 16
    "IMAGE_mode": "IMAGE",                                                                                             // 16
    "IMAGE_px": "0",                                                                                                   // 16
    "IMAGE_py": 0,                                                                                                     // 16
    "IMAGE_nbPages": "1"                                                                                               // 16
  },                                                                                                                   // 16
  "date": {                                                                                                            // 16
    "type": "LE",                                                                                                      // 16
    "a1": 1831                                                                                                         // 16
  },                                                                                                                   // 16
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_f2.jpg",                                                             // 16
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_f2_ico.jpg",                                                             // 16
  "comment": ""                                                                                                        // 16
}, {                                                                                                                   // 16
  "type": "CADASTRE",                                                                                                  // 17
  "codage": "GEO_REF",                                                                                                 // 17
  "source": {                                                                                                          // 17
    "intitule": "Archives départementales 85",                                                                         // 17
    "id": "3P_234_AD_017",                                                                                             // 17
    "libreDeDroits": false                                                                                             // 17
  },                                                                                                                   // 17
  "titre": "Cadastre du Saint Jean de Monts : Section F3 du Bois Maçon",                                               // 17
  "specif": {                                                                                                          // 17
    "IMAGE_mode": "IMAGE",                                                                                             // 17
    "IMAGE_px": "0",                                                                                                   // 17
    "IMAGE_py": 0,                                                                                                     // 17
    "IMAGE_nbPages": "1"                                                                                               // 17
  },                                                                                                                   // 17
  "date": {                                                                                                            // 17
    "type": "LE",                                                                                                      // 17
    "a1": 1831                                                                                                         // 17
  },                                                                                                                   // 17
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_f3.jpg",                                                             // 17
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_f3_ico.jpg",                                                             // 17
  "comment": ""                                                                                                        // 17
}, {                                                                                                                   // 17
  "type": "CADASTRE",                                                                                                  // 18
  "codage": "GEO_REF",                                                                                                 // 18
  "source": {                                                                                                          // 18
    "intitule": "Archives départementales 85",                                                                         // 18
    "id": "3P_234_AD_018",                                                                                             // 18
    "libreDeDroits": false                                                                                             // 18
  },                                                                                                                   // 18
  "titre": "Cadastre du Saint Jean de Monts : Section G1 des Dunes",                                                   // 18
  "specif": {                                                                                                          // 18
    "IMAGE_mode": "IMAGE",                                                                                             // 18
    "IMAGE_px": "0",                                                                                                   // 18
    "IMAGE_py": 0,                                                                                                     // 18
    "IMAGE_nbPages": "1"                                                                                               // 18
  },                                                                                                                   // 18
  "date": {                                                                                                            // 18
    "type": "LE",                                                                                                      // 18
    "a1": 1831                                                                                                         // 18
  },                                                                                                                   // 18
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_g1.jpg",                                                             // 18
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_g1_ico.jpg",                                                             // 18
  "comment": ""                                                                                                        // 18
}, {                                                                                                                   // 18
  "type": "CADASTRE",                                                                                                  // 19
  "codage": "GEO_REF",                                                                                                 // 19
  "source": {                                                                                                          // 19
    "intitule": "Archives départementales 85",                                                                         // 19
    "id": "3P_234_AD_019",                                                                                             // 19
    "libreDeDroits": false                                                                                             // 19
  },                                                                                                                   // 19
  "titre": "Cadastre du Saint Jean de Monts : Section G2 des Dunes",                                                   // 19
  "specif": {                                                                                                          // 19
    "IMAGE_mode": "IMAGE",                                                                                             // 19
    "IMAGE_px": "0",                                                                                                   // 19
    "IMAGE_py": 0,                                                                                                     // 19
    "IMAGE_nbPages": "1"                                                                                               // 19
  },                                                                                                                   // 19
  "date": {                                                                                                            // 19
    "type": "LE",                                                                                                      // 19
    "a1": 1831                                                                                                         // 19
  },                                                                                                                   // 19
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_g2.jpg",                                                             // 19
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_g2_ico.jpg",                                                             // 19
  "comment": ""                                                                                                        // 19
}, {                                                                                                                   // 19
  "type": "CADASTRE",                                                                                                  // 20
  "codage": "GEO_REF",                                                                                                 // 20
  "source": {                                                                                                          // 20
    "intitule": "Archives départementales 85",                                                                         // 20
    "id": "3P_234_AD_020",                                                                                             // 20
    "libreDeDroits": false                                                                                             // 20
  },                                                                                                                   // 20
  "titre": "Cadastre du Saint Jean de Monts : Section G3 des Dunes",                                                   // 20
  "specif": {                                                                                                          // 20
    "IMAGE_mode": "IMAGE",                                                                                             // 20
    "IMAGE_px": "0",                                                                                                   // 20
    "IMAGE_py": 0,                                                                                                     // 20
    "IMAGE_nbPages": "1"                                                                                               // 20
  },                                                                                                                   // 20
  "date": {                                                                                                            // 20
    "type": "LE",                                                                                                      // 20
    "a1": 1831                                                                                                         // 20
  },                                                                                                                   // 20
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_g3.jpg",                                                             // 20
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_g3_ico.jpg",                                                             // 20
  "comment": ""                                                                                                        // 20
}, {                                                                                                                   // 20
  "type": "CADASTRE",                                                                                                  // 21
  "codage": "GEO_REF",                                                                                                 // 21
  "source": {                                                                                                          // 21
    "intitule": "Archives départementales 85",                                                                         // 21
    "id": "3P_234_AD_021",                                                                                             // 21
    "libreDeDroits": false                                                                                             // 21
  },                                                                                                                   // 21
  "titre": "Cadastre du Saint Jean de Monts : Section G4 des Dunes",                                                   // 21
  "specif": {                                                                                                          // 21
    "IMAGE_mode": "IMAGE",                                                                                             // 21
    "IMAGE_px": "0",                                                                                                   // 21
    "IMAGE_py": 0,                                                                                                     // 21
    "IMAGE_nbPages": "1"                                                                                               // 21
  },                                                                                                                   // 21
  "date": {                                                                                                            // 21
    "type": "LE",                                                                                                      // 21
    "a1": 1831                                                                                                         // 21
  },                                                                                                                   // 21
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_g4.jpg",                                                             // 21
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_g4_ico.jpg",                                                             // 21
  "comment": ""                                                                                                        // 21
}, {                                                                                                                   // 21
  "type": "CADASTRE",                                                                                                  // 22
  "codage": "GEO_REF",                                                                                                 // 22
  "source": {                                                                                                          // 22
    "intitule": "Archives départementales 85",                                                                         // 22
    "id": "3P_234_AD_022",                                                                                             // 22
    "libreDeDroits": false                                                                                             // 22
  },                                                                                                                   // 22
  "titre": "Cadastre du Saint Jean de Monts : Section G5 des Dunes",                                                   // 22
  "specif": {                                                                                                          // 22
    "IMAGE_mode": "IMAGE",                                                                                             // 22
    "IMAGE_px": "0",                                                                                                   // 22
    "IMAGE_py": 0,                                                                                                     // 22
    "IMAGE_nbPages": "1"                                                                                               // 22
  },                                                                                                                   // 22
  "date": {                                                                                                            // 22
    "type": "LE",                                                                                                      // 22
    "a1": 1831                                                                                                         // 22
  },                                                                                                                   // 22
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_g5.jpg",                                                             // 22
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_g5_ico.jpg",                                                             // 22
  "comment": ""                                                                                                        // 22
}, {                                                                                                                   // 22
  "type": "CADASTRE",                                                                                                  // 23
  "codage": "GEO_REF",                                                                                                 // 23
  "source": {                                                                                                          // 23
    "intitule": "Archives départementales 85",                                                                         // 23
    "id": "3P_234_AD_023",                                                                                             // 23
    "libreDeDroits": false                                                                                             // 23
  },                                                                                                                   // 23
  "titre": "Cadastre du Saint Jean de Monts : Section G6 des Dunes",                                                   // 23
  "specif": {                                                                                                          // 23
    "IMAGE_mode": "IMAGE",                                                                                             // 23
    "IMAGE_px": "0",                                                                                                   // 23
    "IMAGE_py": 0,                                                                                                     // 23
    "IMAGE_nbPages": "1"                                                                                               // 23
  },                                                                                                                   // 23
  "date": {                                                                                                            // 23
    "type": "LE",                                                                                                      // 23
    "a1": 1831                                                                                                         // 23
  },                                                                                                                   // 23
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_g6.jpg",                                                             // 23
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_g6_ico.jpg",                                                             // 23
  "comment": ""                                                                                                        // 23
}, {                                                                                                                   // 23
  "type": "CADASTRE",                                                                                                  // 24
  "codage": "GEO_REF",                                                                                                 // 24
  "source": {                                                                                                          // 24
    "intitule": "Archives départementales 85",                                                                         // 24
    "id": "3P_234_AD_024",                                                                                             // 24
    "libreDeDroits": false                                                                                             // 24
  },                                                                                                                   // 24
  "titre": "Cadastre du Saint Jean de Monts : Section G7 des Dunes",                                                   // 24
  "specif": {                                                                                                          // 24
    "IMAGE_mode": "IMAGE",                                                                                             // 24
    "IMAGE_px": "0",                                                                                                   // 24
    "IMAGE_py": 0,                                                                                                     // 24
    "IMAGE_nbPages": "1"                                                                                               // 24
  },                                                                                                                   // 24
  "date": {                                                                                                            // 24
    "type": "LE",                                                                                                      // 24
    "a1": 1831                                                                                                         // 24
  },                                                                                                                   // 24
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_g7.jpg",                                                             // 24
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_g7_ico.jpg",                                                             // 24
  "comment": ""                                                                                                        // 24
}, {                                                                                                                   // 24
  "type": "CADASTRE",                                                                                                  // 25
  "codage": "GEO_REF",                                                                                                 // 25
  "source": {                                                                                                          // 25
    "intitule": "Archives départementales 85",                                                                         // 25
    "id": "3P_234_AD_025",                                                                                             // 25
    "libreDeDroits": false                                                                                             // 25
  },                                                                                                                   // 25
  "titre": "Cadastre du Saint Jean de Monts : Section G8 des Dunes",                                                   // 25
  "specif": {                                                                                                          // 25
    "IMAGE_mode": "IMAGE",                                                                                             // 25
    "IMAGE_px": "0",                                                                                                   // 25
    "IMAGE_py": 0,                                                                                                     // 25
    "IMAGE_nbPages": "1"                                                                                               // 25
  },                                                                                                                   // 25
  "date": {                                                                                                            // 25
    "type": "LE",                                                                                                      // 25
    "a1": 1831                                                                                                         // 25
  },                                                                                                                   // 25
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_g8.jpg",                                                             // 25
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_g8_ico.jpg",                                                             // 25
  "comment": ""                                                                                                        // 25
}, {                                                                                                                   // 25
  "type": "CADASTRE",                                                                                                  // 26
  "codage": "GEO_REF",                                                                                                 // 26
  "source": {                                                                                                          // 26
    "intitule": "Archives départementales 85",                                                                         // 26
    "id": "3P_234_AD_026",                                                                                             // 26
    "libreDeDroits": false                                                                                             // 26
  },                                                                                                                   // 26
  "titre": "Cadastre du Saint Jean de Monts : Section H1 d' Orouet",                                                   // 26
  "specif": {                                                                                                          // 26
    "IMAGE_mode": "IMAGE",                                                                                             // 26
    "IMAGE_px": "0",                                                                                                   // 26
    "IMAGE_py": 0,                                                                                                     // 26
    "IMAGE_nbPages": "1"                                                                                               // 26
  },                                                                                                                   // 26
  "date": {                                                                                                            // 26
    "type": "LE",                                                                                                      // 26
    "a1": 1831                                                                                                         // 26
  },                                                                                                                   // 26
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_h1.jpg",                                                             // 26
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_h1_ico.jpg",                                                             // 26
  "comment": ""                                                                                                        // 26
}, {                                                                                                                   // 26
  "type": "CADASTRE",                                                                                                  // 27
  "codage": "GEO_REF",                                                                                                 // 27
  "source": {                                                                                                          // 27
    "intitule": "Archives départementales 85",                                                                         // 27
    "id": "3P_234_CE_027",                                                                                             // 27
    "libreDeDroits": false                                                                                             // 27
  },                                                                                                                   // 27
  "titre": "Cadastre du Saint Jean de Monts : Section H2 d' Orouet",                                                   // 27
  "specif": {                                                                                                          // 27
    "IMAGE_mode": "IMAGE",                                                                                             // 27
    "IMAGE_px": "0",                                                                                                   // 27
    "IMAGE_py": 0,                                                                                                     // 27
    "IMAGE_nbPages": "1"                                                                                               // 27
  },                                                                                                                   // 27
  "date": {                                                                                                            // 27
    "type": "LE",                                                                                                      // 27
    "a1": 1831                                                                                                         // 27
  },                                                                                                                   // 27
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_h2.jpg",                                                             // 27
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_h2_ico.jpg",                                                             // 27
  "comment": ""                                                                                                        // 27
}, {                                                                                                                   // 27
  "type": "CADASTRE",                                                                                                  // 28
  "codage": "GEO_REF",                                                                                                 // 28
  "source": {                                                                                                          // 28
    "intitule": "Archives départementales 85",                                                                         // 28
    "id": "3P_234_AD_028",                                                                                             // 28
    "libreDeDroits": false                                                                                             // 28
  },                                                                                                                   // 28
  "titre": "Cadastre du Saint Jean de Monts : Section H3 d' Orouet",                                                   // 28
  "specif": {                                                                                                          // 28
    "IMAGE_mode": "IMAGE",                                                                                             // 28
    "IMAGE_px": "0",                                                                                                   // 28
    "IMAGE_py": 0,                                                                                                     // 28
    "IMAGE_nbPages": "1"                                                                                               // 28
  },                                                                                                                   // 28
  "date": {                                                                                                            // 28
    "type": "LE",                                                                                                      // 28
    "a1": 1831                                                                                                         // 28
  },                                                                                                                   // 28
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_h3.jpg",                                                             // 28
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_h3_ico.jpg",                                                             // 28
  "comment": ""                                                                                                        // 28
}, {                                                                                                                   // 28
  "type": "CADASTRE",                                                                                                  // 29
  "codage": "GEO_REF",                                                                                                 // 29
  "source": {                                                                                                          // 29
    "intitule": "Archives départementales 85",                                                                         // 29
    "id": "3P_234_AD_029",                                                                                             // 29
    "libreDeDroits": false                                                                                             // 29
  },                                                                                                                   // 29
  "titre": "Cadastre du Saint Jean de Monts : Section I1 de l' Abbaye d' Orouet",                                      // 29
  "specif": {                                                                                                          // 29
    "IMAGE_mode": "IMAGE",                                                                                             // 29
    "IMAGE_px": "0",                                                                                                   // 29
    "IMAGE_py": 0,                                                                                                     // 29
    "IMAGE_nbPages": "1"                                                                                               // 29
  },                                                                                                                   // 29
  "date": {                                                                                                            // 29
    "type": "LE",                                                                                                      // 29
    "a1": 1831                                                                                                         // 29
  },                                                                                                                   // 29
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_i1.jpg",                                                             // 29
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_i1_ico.jpg",                                                             // 29
  "comment": ""                                                                                                        // 29
}, {                                                                                                                   // 29
  "type": "CADASTRE",                                                                                                  // 30
  "codage": "GEO_REF",                                                                                                 // 30
  "source": {                                                                                                          // 30
    "intitule": "Archives départementales 85",                                                                         // 30
    "id": "3P_234_AD_030",                                                                                             // 30
    "libreDeDroits": false                                                                                             // 30
  },                                                                                                                   // 30
  "titre": "Cadastre du Saint Jean de Monts : Section I2 de l'Abbaye d'Orouet",                                        // 30
  "specif": {                                                                                                          // 30
    "IMAGE_mode": "IMAGE",                                                                                             // 30
    "IMAGE_px": "0",                                                                                                   // 30
    "IMAGE_py": 0,                                                                                                     // 30
    "IMAGE_nbPages": "1"                                                                                               // 30
  },                                                                                                                   // 30
  "date": {                                                                                                            // 30
    "type": "LE",                                                                                                      // 30
    "a1": 1831                                                                                                         // 30
  },                                                                                                                   // 30
  "urlDocument": "/geo_refs/brut/SaintJeanDeMonts_i2.jpg",                                                             // 30
  "urlIcone": "/geo_refs/ico/SaintJeanDeMonts_i2_ico.jpg",                                                             // 30
  "comment": ""                                                                                                        // 30
}];                                                                                                                    // 30
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"parametres.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/parametres.js                                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// ==============================================                                                                      // 1
// Id de l'administrateur de l'application                                                                             // 2
// ==============================================                                                                      // 3
idAdministrateurAppli = "a24Ac3s3sZEAedQmP";                                                                           // 4
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"serveur.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/serveur.js                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// ==============================================                                                                      // 1
//  MODULES                                                                                                            // 2
// ==============================================                                                                      // 3
os = Npm.require("os" // Pour obtenir des infos sur l'OS, CPU...                                                       // 4
);                                                                                                                     // 4
fs = Npm.require('fs');                                                                                                // 5
                                                                                                                       //
var exec = Npm.require('child_process').exec; // ==============================================                        // 6
// GESTION ENVIRONNEMENT PROD ou DEV                                                                                   // 10
// ==============================================                                                                      // 11
// Variable pour gérer les environnements :                                                                            // 12
// - TEST (Windows)                                                                                                    // 13
// - PROD (Linux)                                                                                                      // 14
// La sélection se fait automatiquement par détection de l'OS                                                          // 15
// en utilisant : Npm.require("os")	                                                                                   // 16
                                                                                                                       //
                                                                                                                       //
var env = {                                                                                                            // 18
	// ------------------------------------------                                                                         // 19
	// Environnement de test                                                                                              // 20
	// ------------------------------------------                                                                         // 21
	'Windows_NT': {                                                                                                       // 22
		// Pour la gestion des DUMP/RESTORE MongoDb                                                                          // 23
		'dumpDir': 'c:\\data\\mongo\\dumps\\',                                                                               // 24
		'dumpCommand': 'c:\\mongodb\\bin\\mongodump -h 127.0.0.1:3001 -d meteor --out ',                                     // 25
		// + dumpDir                                                                                                         // 25
		'restoreCommand': 'c:\\mongodb\\bin\\mongorestore -h 127.0.0.1:3001 -d meteor ',                                     // 26
		// + dumpDir                                                                                                         // 26
		'deleteDumpCommand': 'rmdir /S /Q ',                                                                                 // 27
		// + dumpDir                                                                                                         // 27
		// Pour la conversion SVG -> PNG                                                                                     // 28
		'tmpDir': 'c:\\gen_tmp\\',                                                                                           // 29
		'pathToBatik': 'c:\\batik\\batik-rasterizer-1.8.jar',                                                                // 30
		'UriPathToCssFile': 'http://localhost:3000/'                                                                         // 31
	},                                                                                                                    // 22
	// ------------------------------------------                                                                         // 33
	// Environnement de prod                                                                                              // 34
	// ------------------------------------------                                                                         // 35
	'Linux': {                                                                                                            // 36
		// Pour la gestion des DUMP/RESTORE MongoDb                                                                          // 37
		'dumpDir': '/data/mongo/dumps',                                                                                      // 38
		'dumpCommand': '',                                                                                                   // 39
		// + dumpDir                                                                                                         // 39
		'restoreCommand': '',                                                                                                // 40
		// + dumpDir                                                                                                         // 40
		'deleteDumpCommand': '',                                                                                             // 41
		// + dumpDir                                                                                                         // 41
		// Pour la conversion SVG -> PNG                                                                                     // 42
		'tmpDir': '',                                                                                                        // 43
		'pathToBatik': '',                                                                                                   // 44
		'UriPathToCssFile': ''                                                                                               // 45
	} // ==============================================                                                                   // 36
	// DETECTION ENVIRONNEMENT PROD ou DEV                                                                                // 50
	// ==============================================                                                                     // 51
                                                                                                                       //
};                                                                                                                     // 18
console.log('---------------------------------------------');                                                          // 52
console.log('Démarrage serveur');                                                                                      // 53
                                                                                                                       //
switch (os.type()) {                                                                                                   // 54
	case 'Windows_NT':                                                                                                    // 55
	case 'Linux':                                                                                                         // 56
		// Détection OK, on initialise la variable ENV selon l'OS                                                            // 57
		console.log('OS serveur détecté : ' + os.type());                                                                    // 58
		var ENV = env[os.type()];                                                                                            // 59
		break;                                                                                                               // 60
                                                                                                                       //
	default:                                                                                                              // 61
		console.error('Erreur "server.js" : OS non supporté : ' + os.type());                                                // 62
		break;                                                                                                               // 63
} // ==============================================                                                                    // 54
//  GESTION des ADMIN                                                                                                  // 67
// ==============================================                                                                      // 68
// On a 4 niveau de droit d'accès incrémentaux  définis dans la collection user (profile.role) :                       // 69
// - SUPERADMIN                                                                                                        // 70
// - ADMIN                                                                                                             // 71
// - USER                                                                                                              // 72
                                                                                                                       //
                                                                                                                       //
idAdministrateurAppli = "a24Ac3s3sZEAedQmP"; /*                                                                        // 74
                                             // Initialisation du SUPERADMIN (qui ensuite peut donner des droits au autres)
                                             Meteor.users.update(                                                      //
                                             	{_id: idAdministrateurAppli},                                            //
                                             	{$set: {                                                                 //
                                             			'profile.role':"SUPERADMIN",                                           //
                                             			'profile.lang':"fr",                                                   //
                                             			'profile.history':[],                                                  //
                                             			'profile._id':"pZXq8wXxGMFHuARd8",                                     //
                                             			'profile.accountJustCreated':false,                                    //
                                             			'profile.visitedObjects':{"PERS":[],"LIEU":[],"HIST":[],"DOC":[]}      //
                                             		}                                                                       //
                                             	}                                                                        //
                                             );                                                                        //
                                             */ // ?????????????????????????????????                                   //
// Temporaire pendant les devs                                                                                         // 95
// Il faudra aussi préoir un mécanisme de vérification des paramètres perso de l'utilisateur                           // 96
// On initialise aussi les préférences à la valeur par défaut                                                          // 97
                                                                                                                       //
Meteor.users.update({                                                                                                  // 98
	_id: idAdministrateurAppli                                                                                            // 98
}, {                                                                                                                   // 98
	$set: {                                                                                                               // 98
		'profile.prefs': usersDefaultPrefs                                                                                   // 98
	}                                                                                                                     // 98
}); // ?????????????????????????????????                                                                               // 98
// Fonction pour vérifier si l'utilisateur est un super-administrateur                                                 // 101
// (si Meteor.user().profile.role n'est pas accessible directement comme dans les ALLOW)                               // 102
                                                                                                                       //
isSuperAdmin = function (userId) {                                                                                     // 103
	var user = Meteor.users.findOne({                                                                                     // 104
		_id: userId                                                                                                          // 104
	});                                                                                                                   // 104
	return user && user.profile && user.profile.role === "SUPERADMIN";                                                    // 105
}; // Fonction pour vérifier si l'utilisateur est un administrateur                                                    // 106
// (si Meteor.user().profile.role n'est pas accessible directement comme dans les ALLOW)                               // 109
                                                                                                                       //
                                                                                                                       //
isAdmin = function (userId) {                                                                                          // 110
	var user = Meteor.users.findOne({                                                                                     // 111
		_id: userId                                                                                                          // 111
	});                                                                                                                   // 111
	return user && user.profile && (user.profile.role === "SUPERADMIN" || user.profile.role === "ADMIN");                 // 112
}; // ==============================================                                                                   // 113
// A la création d'un compte                                                                                           // 116
// ==============================================                                                                      // 117
// ??????????????????????????????????????????????                                                                      // 119
// A remettre en place si on souhaite permettre la création d'un login par l'utilisateur                               // 120
// A tester car on doit activer cette fonction même si c'est l'administrateur qui crée le user                         // 121
// Il faudrait donc prévoir de tester si on est dans le premier cas ou le second ?                                     // 122
// ??????????????????????????????????????????????                                                                      // 123
/*                                                                                                                     // 125
Accounts.onCreateUser(function(options, user) {                                                                        //
	// On rajoute le rôle par défault                                                                                     //
	user.profile = {};                                                                                                    //
	user.profile.role 					= "USER";                                                                                      //
	user.profile.lang 					= "fr";                                                                                        //
	user.profile.accountJustCreated 	= true; // C'est la première connexion                                               //
	user.profile.visitedObjects 		= {"PERS":[],"LIEU":[],"HIST":[],"DOC":[]};                                             //
	// On rajoute les préférences paramétrables par défaut de l'utilisateur                                               //
	user.profile.prefs = usersDefaultPrefs;	                                                                              //
	return user;                                                                                                          //
});                                                                                                                    //
*/ // ==============================================                                                                   //
// Publications                                                                                                        // 141
// ==============================================                                                                      // 142
                                                                                                                       //
                                                                                                                       //
Meteor.publish("tousLesUtilisateurs", function () {                                                                    // 143
	// Si le demandeur est un admin, on lui renvoie tout                                                                  // 144
	if (isAdmin(this.userId)) return Meteor.users.find(); // Sinon il n'aura que la vue sur lui                           // 145
	else this.ready();                                                                                                    // 145
});                                                                                                                    // 148
Meteor.publish("tousLesLieux", function () {                                                                           // 151
	return Lieux.find();                                                                                                  // 152
});                                                                                                                    // 153
Meteor.publish("tousLesDocs", function () {                                                                            // 154
	return Docs.find();                                                                                                   // 155
});                                                                                                                    // 156
Meteor.publish("toutesLesPers", function () {                                                                          // 157
	return Pers.find();                                                                                                   // 158
});                                                                                                                    // 159
Meteor.publish("tousLesRegistres", function () {                                                                       // 160
	return Registres.find();                                                                                              // 161
});                                                                                                                    // 162
Meteor.publish("tousLesBugs", function () {                                                                            // 163
	return Bugs.find();                                                                                                   // 164
});                                                                                                                    // 165
Meteor.publish("tousLesHists", function () {                                                                           // 166
	return Hists.find();                                                                                                  // 167
});                                                                                                                    // 168
Meteor.publish("toutesLesProfs", function () {                                                                         // 169
	return Profs.find();                                                                                                  // 170
});                                                                                                                    // 171
Meteor.publish("tousLesLiens", function () {                                                                           // 172
	return Liens.find();                                                                                                  // 173
});                                                                                                                    // 174
Meteor.publish("tousLesActesArchives", function () {                                                                   // 175
	return ActesArchives.find();                                                                                          // 176
});                                                                                                                    // 177
Meteor.publish("tousLesCoupleEvents", function () {                                                                    // 178
	return CoupleEvents.find();                                                                                           // 179
});                                                                                                                    // 180
Meteor.publish("tousLesTags", function () {                                                                            // 181
	return Tags.find();                                                                                                   // 182
}); // ==============================================                                                                  // 183
// Méthodes autorisées au client                                                                                       // 188
// ==============================================                                                                      // 189
                                                                                                                       //
Pers.allow({                                                                                                           // 190
	insert: function (userId, doc) {                                                                                      // 191
		// the user must be logged in                                                                                        // 192
		return userId;                                                                                                       // 193
	},                                                                                                                    // 194
	update: function (userId, doc, fields, modifier) {                                                                    // 195
		// can only change your own documents except ADMIN                                                                   // 196
		return doc.createdBy === userId || isAdmin(userId);                                                                  // 197
	},                                                                                                                    // 198
	remove: function (userId, doc) {                                                                                      // 199
		// Seul l'owner ou l'administrateur peut supprimer                                                                   // 200
		return doc.createdBy === userId || isAdmin(userId);                                                                  // 201
	} /*                                                                                                                  // 202
   fetch: ['owner']                                                                                                    //
   */                                                                                                                  //
});                                                                                                                    // 190
CoupleEvents.allow({                                                                                                   // 208
	insert: function (userId, doc) {                                                                                      // 209
		// the user must be logged in                                                                                        // 210
		// ?????????????????????????                                                                                         // 212
		// And add (TBD) : have the rights on the people                                                                     // 213
		// ????????????????????????                                                                                          // 214
		return userId;                                                                                                       // 216
	},                                                                                                                    // 217
	update: function (userId, doc, fields, modifier) {                                                                    // 218
		// ?????????????????????????                                                                                         // 220
		// And add (TBD) : have the rights on the people                                                                     // 221
		// ????????????????????????                                                                                          // 222
		// can only change your own documents except ADMIN                                                                   // 224
		return doc.createdBy === userId || isAdmin(userId);                                                                  // 225
	},                                                                                                                    // 226
	remove: function (userId, doc) {                                                                                      // 227
		// Seul l'owner ou l'administrateur peut supprimer                                                                   // 228
		// ?????????????????????????                                                                                         // 230
		// And add (TBD) : have the rights on the people                                                                     // 231
		// ????????????????????????                                                                                          // 232
		return doc.createdBy === userId || isAdmin(userId);                                                                  // 234
	} /*                                                                                                                  // 235
   fetch: ['owner']                                                                                                    //
   */                                                                                                                  //
});                                                                                                                    // 208
Lieux.allow({                                                                                                          // 241
	insert: function (userId, doc) {                                                                                      // 242
		// the user must be logged in                                                                                        // 243
		return userId;                                                                                                       // 244
	},                                                                                                                    // 245
	update: function (userId, doc, fields, modifier) {                                                                    // 246
		// can only change your own documents except ADMIN                                                                   // 247
		return doc.createdBy === userId || isAdmin(userId);                                                                  // 248
	},                                                                                                                    // 249
	remove: function (userId, doc) {                                                                                      // 250
		// Seul l'owner ou l'administrateur peut supprimer                                                                   // 251
		return doc.createdBy === userId || isAdmin(userId);                                                                  // 252
	} /*                                                                                                                  // 253
   fetch: ['owner']                                                                                                    //
   */                                                                                                                  //
});                                                                                                                    // 241
Hists.allow({                                                                                                          // 259
	insert: function (userId, doc) {                                                                                      // 260
		// the user must be logged in                                                                                        // 261
		return userId;                                                                                                       // 262
	},                                                                                                                    // 263
	update: function (userId, doc, fields, modifier) {                                                                    // 264
		// can only change your own documents except ADMIN                                                                   // 265
		return doc.createdBy === userId || isAdmin(userId);                                                                  // 266
	},                                                                                                                    // 267
	remove: function (userId, doc) {                                                                                      // 268
		// Seul l'owner ou l'administrateur peut supprimer                                                                   // 269
		return doc.createdBy === userId || isAdmin(userId);                                                                  // 270
	} /*                                                                                                                  // 271
     fetch: ['owner']                                                                                                  //
     */                                                                                                                //
});                                                                                                                    // 259
Docs.allow({                                                                                                           // 277
	insert: function (userId, doc) {                                                                                      // 278
		// the user must be logged in                                                                                        // 279
		return userId;                                                                                                       // 280
	},                                                                                                                    // 281
	update: function (userId, doc, fields, modifier) {                                                                    // 282
		// can only change your own documents except ADMIN                                                                   // 283
		return doc.createdBy === userId || isAdmin(userId);                                                                  // 284
	},                                                                                                                    // 285
	remove: function (userId, doc) {                                                                                      // 286
		// Seul l'owner ou l'administrateur peut supprimer                                                                   // 287
		return doc.createdBy === userId || isAdmin(userId);                                                                  // 288
	} /*                                                                                                                  // 289
   fetch: ['owner']                                                                                                    //
   */                                                                                                                  //
});                                                                                                                    // 277
Profs.allow({                                                                                                          // 295
	insert: function (userId, doc) {                                                                                      // 296
		// the user must be logged in                                                                                        // 297
		return userId;                                                                                                       // 298
	},                                                                                                                    // 299
	update: function (userId, doc, fields, modifier) {                                                                    // 300
		// Seul l'owner ou l'administrateur peut updater                                                                     // 301
		return isAdmin(userId);                                                                                              // 302
	},                                                                                                                    // 303
	remove: function (userId, doc) {                                                                                      // 304
		// Seul l'owner ou l'administrateur peut supprimer                                                                   // 305
		return isAdmin(userId);                                                                                              // 306
	} /*                                                                                                                  // 307
   fetch: ['owner']                                                                                                    //
   */                                                                                                                  //
});                                                                                                                    // 295
Liens.allow({                                                                                                          // 313
	insert: function (userId, doc) {                                                                                      // 314
		// the user must be logged in                                                                                        // 315
		return userId;                                                                                                       // 316
	},                                                                                                                    // 317
	update: function (userId, doc, fields, modifier) {                                                                    // 318
		// can only change your own links except ADMIN                                                                       // 319
		return doc.createdBy === userId || isAdmin(userId);                                                                  // 320
	},                                                                                                                    // 321
	remove: function (userId, doc) {                                                                                      // 322
		// Seul l'owner ou l'administrateur peut supprimer                                                                   // 323
		return doc.createdBy === userId || isAdmin(userId);                                                                  // 324
	} /*                                                                                                                  // 325
   fetch: ['owner']                                                                                                    //
   */                                                                                                                  //
});                                                                                                                    // 313
ActesArchives.allow({                                                                                                  // 331
	insert: function (userId, doc) {                                                                                      // 332
		// the user must be logged in                                                                                        // 333
		return userId;                                                                                                       // 334
	},                                                                                                                    // 335
	update: function (userId, doc, fields, modifier) {                                                                    // 336
		// can only change your own links except ADMIN                                                                       // 337
		return doc.createdBy === userId || isAdmin(userId);                                                                  // 338
	},                                                                                                                    // 339
	remove: function (userId, doc) {                                                                                      // 340
		// Seul l'owner ou l'administrateur peut supprimer                                                                   // 341
		return doc.createdBy === userId || isAdmin(userId);                                                                  // 342
	} /*                                                                                                                  // 343
   fetch: ['owner']                                                                                                    //
   */                                                                                                                  //
});                                                                                                                    // 331
Tags.allow({                                                                                                           // 349
	insert: function (userId, doc) {                                                                                      // 350
		// the user must be logged in                                                                                        // 351
		return userId;                                                                                                       // 352
	},                                                                                                                    // 353
	update: function (userId, doc, fields, modifier) {                                                                    // 354
		// can only change your own documents except ADMIN                                                                   // 355
		return doc.createdBy === userId || isAdmin(userId);                                                                  // 356
	},                                                                                                                    // 357
	remove: function (userId, doc) {                                                                                      // 358
		// Seul l'owner ou l'administrateur peut supprimer                                                                   // 359
		return doc.createdBy === userId || isAdmin(userId);                                                                  // 360
	} /*                                                                                                                  // 361
   fetch: ['owner']                                                                                                    //
   */                                                                                                                  //
});                                                                                                                    // 349
Meteor.users.deny({                                                                                                    // 367
	// Pour interdire de se faire ADMIN si on est USER et SUPERADMIN si on est ADMIN                                      // 368
	update: function (userId, doc, fields, modifier) {                                                                    // 369
		debugger;                                                                                                            // 370
		if (JSON.stringify(modifier).indexOf("SUPERADMIN") != -1 && !isSuperAdmin(userId)) return true;else {                // 371
			if (JSON.stringify(modifier).indexOf("ADMIN") != -1 && !isAdmin(userId)) return true;else return false;             // 374
		}                                                                                                                    // 377
	}                                                                                                                     // 378
});                                                                                                                    // 367
Meteor.users.allow({                                                                                                   // 381
	remove: function (userId, doc) {                                                                                      // 382
		// Seul l'administrateur peut supprimer des utilisateurs mais pas lui même                                           // 383
		return isAdmin(userId) && userId != doc._id;                                                                         // 384
	}                                                                                                                     // 385
});                                                                                                                    // 381
Registres.allow({                                                                                                      // 388
	insert: function (userId, doc) {                                                                                      // 389
		// Seul l'administrateur peut ajouter des registres                                                                  // 390
		return isAdmin(userId);                                                                                              // 391
	},                                                                                                                    // 392
	update: function (userId, doc, fields, modifier) {                                                                    // 393
		// Seul l'administrateur peut modifier des registres                                                                 // 394
		return isAdmin(userId);                                                                                              // 395
	},                                                                                                                    // 396
	remove: function (userId, doc) {                                                                                      // 397
		// Seul l'administrateur peut supprimer des registres                                                                // 398
		return isAdmin(userId);                                                                                              // 399
	} /*                                                                                                                  // 400
     fetch: ['owner']                                                                                                  //
     */                                                                                                                //
});                                                                                                                    // 388
Bugs.allow({                                                                                                           // 407
	insert: function (userId, doc) {                                                                                      // 408
		// Seul l'administrateur peut ajouter des bugs                                                                       // 409
		return isAdmin(userId);                                                                                              // 410
	},                                                                                                                    // 411
	update: function (userId, doc, fields, modifier) {                                                                    // 412
		// Seul l'administrateur peut modifier des bugs                                                                      // 413
		return isAdmin(userId);                                                                                              // 414
	},                                                                                                                    // 415
	remove: function (userId, doc) {                                                                                      // 416
		// Seul l'administrateur peut supprimer des bugs                                                                     // 417
		return isAdmin(userId);                                                                                              // 418
	} /*                                                                                                                  // 419
     fetch: ['owner']                                                                                                  //
     */                                                                                                                //
}); // ==============================================                                                                  // 407
// METHODES serveur                                                                                                    // 426
// ==============================================                                                                      // 427
                                                                                                                       //
Meteor.methods({                                                                                                       // 428
	"svgToPngDownload": function (svgCode, width, height, cssFileName) {                                                  // 429
		// Parametres ----------------                                                                                       // 430
		var nbPixelsParPointSVG = 4; // Code ----------------------                                                          // 431
                                                                                                                       //
		try {                                                                                                                // 433
			// On enregistre le fichier SVG dans une directory temporaire                                                       // 434
			var path = ENV.tmpDir + new Date().getTime();                                                                       // 435
			var filepath = path + '.svg';                                                                                       // 436
			var resultFilePath = path + '.png';                                                                                 // 437
			var buffer = new Buffer(svgCode);                                                                                   // 438
			fs.writeFileSync(filepath, buffer); // On peut rajouter des options                                                 // 439
			// On lance la transformation Batik Rasterizer                                                                      // 440
                                                                                                                       //
			var runCmd = Meteor.wrapAsync(exec); // ????????????????????????????????????????????????????????????????????        // 441
			// A gérer le chargement du CSS, on est obligé de fournir une URI !!!                                               // 443
			// ????????????????????????????????????????????????????????????????????                                             // 444
                                                                                                                       //
			var cmd = 'java -Xmx1024m -jar ' + ENV.pathToBatik + ' ' + filepath + ' -d ' + ENV.tmpDir + ' -h ' + height * nbPixelsParPointSVG + ' -w ' + width * nbPixelsParPointSVG; // S'il y a un fichier CSS de fourni, on l'utilise
                                                                                                                       //
			if (cssFileName) cmd = cmd + ' -cssUser ' + ENV.UriPathToCssFile + cssFileName; // On lance la conversion           // 447
                                                                                                                       //
			var result = runCmd(cmd); // ????????????????????????????????????????????????????????????????????                   // 449
			// Optimisation : via DDP ne peut-on pas coder autrement qu'en base64 ??                                            // 451
			// ????????????????????????????????????????????????????????????????????                                             // 452
			// On encode le résultat en base64                                                                                  // 453
                                                                                                                       //
			var bitmap = fs.readFileSync(resultFilePath);                                                                       // 454
			return new Buffer(bitmap).toString('base64');                                                                       // 455
		} catch (err) {                                                                                                      // 456
			throw new Meteor.Error(500, err.message);                                                                           // 458
		}                                                                                                                    // 459
	},                                                                                                                    // 460
	"dump": function () {                                                                                                 // 461
		if (isAdmin(Meteor.userId())) {                                                                                      // 462
			runCmd = Meteor.wrapAsync(exec);                                                                                    // 463
                                                                                                                       //
			try {                                                                                                               // 464
				// On crée un dump dans une sous directory dont le nom est le TS                                                   // 465
				var result = runCmd(ENV.dumpCommand + ENV.dumpDir + new Date().getTime());                                         // 466
				return result;                                                                                                     // 467
			} catch (err) {                                                                                                     // 468
				throw new Meteor.Error(500, err.message);                                                                          // 470
			}                                                                                                                   // 471
		} else throw new Meteor.Error(403, "Vous n'avez pas les droits");                                                    // 472
	},                                                                                                                    // 474
	"dumpList": function () {                                                                                             // 475
		try {                                                                                                                // 476
			var files = fs.readdirSync(ENV.dumpDir); // On renvoie l'array contenant les noms de fichiers                       // 477
                                                                                                                       //
			return files.reverse();                                                                                             // 479
		} catch (err) {                                                                                                      // 480
			throw new Meteor.Error(500, err.message);                                                                           // 482
		}                                                                                                                    // 483
	},                                                                                                                    // 484
	"deleteDump": function (dumpTimeStamp) {                                                                              // 485
		if (isAdmin(Meteor.userId())) {                                                                                      // 486
			runCmd = Meteor.wrapAsync(exec);                                                                                    // 487
                                                                                                                       //
			try {                                                                                                               // 488
				result = runCmd(ENV.deleteDumpCommand + ENV.dumpDir + dumpTimeStamp);                                              // 489
				return result;                                                                                                     // 490
			} catch (err) {                                                                                                     // 491
				throw new Meteor.Error(500, err.message);                                                                          // 493
			}                                                                                                                   // 494
		} else throw new Meteor.Error(403, "Vous n'avez pas les droits");                                                    // 496
	},                                                                                                                    // 498
	"restoreDump": function (dumpTimeStamp) {                                                                             // 499
		if (isAdmin(Meteor.userId())) {                                                                                      // 500
			runCmd = Meteor.wrapAsync(exec);                                                                                    // 501
                                                                                                                       //
			try {                                                                                                               // 502
				console.log(ENV.restoreCommand + ENV.dumpDir + dumpTimeStamp + "\\meteor");                                        // 503
				result = runCmd(ENV.restoreCommand + ENV.dumpDir + dumpTimeStamp + "\\meteor");                                    // 504
				return result;                                                                                                     // 505
			} catch (err) {                                                                                                     // 506
				throw new Meteor.Error(500, err.message);                                                                          // 508
			}                                                                                                                   // 509
		} else throw new Meteor.Error(403, "Vous n'avez pas les droits");                                                    // 510
	},                                                                                                                    // 512
	// Création d'un login correspondant éventuellement à la personne dont l'id est passé en paramètre                    // 513
	"createLogin": function (email, password, id) {                                                                       // 514
		// Uniquemment pour l'administrateur !                                                                               // 515
		if (isAdmin(Meteor.userId())) {                                                                                      // 516
			// Si cela concerne une personne de la base existante                                                               // 517
			if (id && Pers.findOne({                                                                                            // 518
				_id: id                                                                                                            // 518
			})) {                                                                                                               // 518
				// ???????????????????????????????????????                                                                         // 519
				// A faire : Vérifier les paramètres email et password                                                             // 520
				// ???????????????????????????????????????                                                                         // 521
				var profile = {};                                                                                                  // 522
				profile.role = "USER";                                                                                             // 523
				profile.lang = "fr";                                                                                               // 524
				profile._id = id; // On court-circuite la phase accountJustCreated dans ce cas                                     // 525
                                                                                                                       //
				profile.accountJustCreated = false;                                                                                // 527
				profile.visitedObjects = {                                                                                         // 528
					"PERS": [],                                                                                                       // 528
					"LIEU": [],                                                                                                       // 528
					"HIST": [],                                                                                                       // 528
					"DOC": []                                                                                                         // 528
				}; // On rajoute les préférences paramétrables par défaut de l'utilisateur                                         // 528
                                                                                                                       //
				profile.prefs = usersDefaultPrefs; // On crée l'utilisateur                                                        // 530
                                                                                                                       //
				console.log("création : " + Accounts.createUser({                                                                  // 532
					// username: username, à implémenter ?                                                                            // 533
					email: email,                                                                                                     // 534
					password: password,                                                                                               // 535
					profile: profile                                                                                                  // 536
				}));                                                                                                               // 532
			} else throw new Meteor.Error(403, "Cette personne n'est pas connue dans la base");                                 // 538
		} else throw new Meteor.Error(403, "Vous n'avez pas les droits");                                                    // 540
	},                                                                                                                    // 542
	"schemasDataCheck": function () {                                                                                     // 543
		var collectionList = [{                                                                                              // 544
			"label": "Pers",                                                                                                    // 545
			"collection": Pers,                                                                                                 // 545
			"schema": SCHEMA.pers                                                                                               // 545
		}, {                                                                                                                 // 545
			"label": "Lieux",                                                                                                   // 546
			"collection": Lieux,                                                                                                // 546
			"schema": SCHEMA.lieu                                                                                               // 546
		}, {                                                                                                                 // 546
			"label": "Hists",                                                                                                   // 547
			"collection": Hists,                                                                                                // 547
			"schema": SCHEMA.hist                                                                                               // 547
		}, {                                                                                                                 // 547
			"label": "Docs",                                                                                                    // 548
			"collection": Docs,                                                                                                 // 548
			"schema": SCHEMA.doc                                                                                                // 548
		}, {                                                                                                                 // 548
			"label": "Liens",                                                                                                   // 549
			"collection": Liens,                                                                                                // 549
			"schema": SCHEMA.lien                                                                                               // 549
		}, {                                                                                                                 // 549
			"label": "Profs",                                                                                                   // 550
			"collection": Profs,                                                                                                // 550
			"schema": SCHEMA.prof                                                                                               // 550
		}, {                                                                                                                 // 550
			"label": "CoupleEvents",                                                                                            // 551
			"collection": CoupleEvents,                                                                                         // 551
			"schema": SCHEMA.coupleEvent                                                                                        // 551
		}, {                                                                                                                 // 551
			"label": "Registres",                                                                                               // 552
			"collection": Registres,                                                                                            // 552
			"schema": SCHEMA.registre                                                                                           // 552
		}, {                                                                                                                 // 552
			"label": "ActesArchives",                                                                                           // 553
			"collection": ActesArchives,                                                                                        // 553
			"schema": SCHEMA.acteArchives                                                                                       // 553
		}, {                                                                                                                 // 553
			"label": "Bugs",                                                                                                    // 554
			"collection": Bugs,                                                                                                 // 554
			"schema": SCHEMA.bug                                                                                                // 554
		}];                                                                                                                  // 554
		var resultat = [];                                                                                                   // 556
                                                                                                                       //
		for (index in meteorBabelHelpers.sanitizeForInObject(collectionList)) {                                              // 557
			var objCourant = collectionList[index];                                                                             // 558
			var validationContext = objCourant.schema.newContext();                                                             // 559
			var listeObjets = objCourant.collection.find().fetch();                                                             // 560
			var resultatCollection = []; // On balaye tous les objets                                                           // 561
                                                                                                                       //
			for (index in meteorBabelHelpers.sanitizeForInObject(listeObjets)) {                                                // 563
				var pers = listeObjets[index];                                                                                     // 564
				validationContext.validate(pers);                                                                                  // 565
                                                                                                                       //
				if (!validationContext.isValid()) {                                                                                // 566
					// On supprime les erreurs {"name":"_id","type":"keyNotInSchema"}                                                 // 567
					var errorsArray = validationContext.validationErrors();                                                           // 568
                                                                                                                       //
					if (errorsArray.length > 1) {                                                                                     // 569
						// On push l'objet dans la liste des erreurs                                                                     // 570
						resultatCollection.push({                                                                                        // 571
							"id": pers._id,                                                                                                 // 571
							"errors": validationContext.validationErrors()                                                                  // 571
						});                                                                                                              // 571
					}                                                                                                                 // 572
				}                                                                                                                  // 573
			}                                                                                                                   // 574
                                                                                                                       //
			resultat.push({                                                                                                     // 575
				"label": objCourant.label,                                                                                         // 575
				"value": resultatCollection                                                                                        // 575
			});                                                                                                                 // 575
		}                                                                                                                    // 576
                                                                                                                       //
		return resultat;                                                                                                     // 577
	},                                                                                                                    // 578
	'getVersion': function () {                                                                                           // 579
		try {                                                                                                                // 580
			return JSON.parse(Assets.getText("version.json"));                                                                  // 581
		} catch (e) {                                                                                                        // 582
			throw new Meteor.Error(404, "Pas d'information de version disponible.");                                            // 584
		}                                                                                                                    // 585
	}                                                                                                                     // 586
}); // ==============================================                                                                  // 428
// Attachement des SCHEMAS                                                                                             // 592
// ==============================================                                                                      // 593
                                                                                                                       //
Lieux.attachSchema(SCHEMA.lieu);                                                                                       // 594
Docs.attachSchema(SCHEMA.doc);                                                                                         // 595
Pers.attachSchema(SCHEMA.pers);                                                                                        // 596
Registres.attachSchema(SCHEMA.registre);                                                                               // 597
Bugs.attachSchema(SCHEMA.bug);                                                                                         // 598
Hists.attachSchema(SCHEMA.hist);                                                                                       // 599
Profs.attachSchema(SCHEMA.prof);                                                                                       // 600
Liens.attachSchema(SCHEMA.lien);                                                                                       // 601
ActesArchives.attachSchema(SCHEMA.acteArchives);                                                                       // 602
CoupleEvents.attachSchema(SCHEMA.coupleEvent);                                                                         // 603
Tags.attachSchema(SCHEMA.tag); // ==============================================                                       // 604
// Gestion des connexions utilisateurs                                                                                 // 607
// ==============================================                                                                      // 608
// A la connection -----------------------------------------------------                                               // 609
                                                                                                                       //
Meteor.onConnection(function (connection) {                                                                            // 610
	console.log("Nouvelle connexion de : " + connection.clientAddress + " (" + connection.id + ")."); // On ajoute une callback pour gérer la déconnexion
                                                                                                                       //
	var connectionId = connection.id;                                                                                     // 613
	connection.onClose(function () {                                                                                      // 614
		console.log("Deconnexion de  : " + connectionId);                                                                    // 615
	});                                                                                                                   // 616
}); // Pour faire le lien entre login et connection ----------------------                                             // 617
                                                                                                                       //
Accounts.validateLoginAttempt(function (info) {                                                                        // 620
	// Suivi des connexions des utilisateurs                                                                              // 621
	console.log("Tentative de login de " + (info.user && info.user._id) + " sur connexion " + info.connection.id); // On valide le login
                                                                                                                       //
	return true;                                                                                                          // 624
}); // Au login successfull ------------------------------------------------                                           // 625
                                                                                                                       //
Accounts.onLogin(function (info) {                                                                                     // 628
	console.log("Login OK de : " + (info.user && info.user._id) + " sur connexion " + info.connection.id);                // 629
}); // En cas d'erreur de loginl ------------------------------------------------                                      // 630
                                                                                                                       //
Accounts.onLoginFailure(function (info) {                                                                              // 633
	console.log("Login NOK sur connexion " + info.connection.id);                                                         // 634
}); /*                                                                                                                 // 635
    // Import de nouveaux registres                                                                                    //
    for (var index in addRegistres) {                                                                                  //
    	var registreEnCours = addRegistres[index];                                                                        //
    	console.log("Registre période : " + registreEnCours.periode + ", résultat : " + Registres.insert(registreEnCours));
    }                                                                                                                  //
    */ /*                                                                                                              //
       // Import de nouveaux cadastres                                                                                 //
       for (var index in chargementCadastres) {                                                                        //
       	var cadastreEnCours = chargementCadastres[index];                                                              //
       	console.log(cadastreEnCours.titre + ", résultat : " + Docs.insert(cadastreEnCours));                           //
       }                                                                                                               //
       */ /*                                                                                                           //
          // =================================================                                                         //
          // Modification des ref actes en array de docs                                                               //
          // =================================================                                                         //
          // Pour la naissance                                                                                         //
          var listePers = Pers.find({"naissance.acte":{$exists:true}}).fetch();                                        //
          console.log("nombre de personne ayant une référence d'acte de naissance: " + listePers.length);              //
          var nb = 0;                                                                                                  //
          for (index in listePers) {                                                                                   //
          	var pers = listePers[index];                                                                                //
          	if (pers.naissance) {                                                                                       //
          		var docRef = pers.naissance.acte;                                                                          //
          		if (docRef) {                                                                                              //
          			if (Pers.update({ _id: pers._id },{$set: {"naissance.docs":[docRef]}}))	{                                 //
          				nb += 1;                                                                                                 //
          			}                                                                                                         //
          			else console.log("Pas de mise à jour pour " + pers._id);                                                  //
          		}                                                                                                          //
          		else console.log("Pas de référence d'acte pour " + pers._id);                                              //
          	}                                                                                                           //
          	else console.log("Pas d'acte de naissance pour " + pers._id);                                               //
          }                                                                                                            //
          console.log(nb + " références d'actes de naissance modifiés");                                               //
                                                                                                                       //
          // Pour le décès                                                                                             //
          listePers = Pers.find({"deces.acte":{$exists:true}}).fetch();                                                //
          console.log("nombre de personne ayant une référence d'acte de décès: " + listePers.length);                  //
          var nb = 0;                                                                                                  //
          for (index in listePers) {                                                                                   //
          	var pers = listePers[index];                                                                                //
          	if (pers.deces) {                                                                                           //
          		var docRef = pers.deces.acte;                                                                              //
          		if (docRef) {                                                                                              //
          			if (Pers.update({ _id: pers._id },{$set: {"deces.docs":[docRef]}}))	{                                     //
          				nb += 1;                                                                                                 //
          			}                                                                                                         //
          			else console.log("Pas de mise à jour pour " + pers._id);                                                  //
          		}                                                                                                          //
          		else console.log("Pas de référence d'acte pour " + pers._id);                                              //
          	}                                                                                                           //
          	else console.log("Pas d'acte de deces pour " + pers._id);                                                   //
          }                                                                                                            //
          console.log(nb + " références d'actes de décès modifiés");                                                   //
                                                                                                                       //
          // Pour les mariages                                                                                         //
          listePers = Pers.find({"mariages":{$exists:true}}).fetch();                                                  //
          console.log("nombre de personne ayant une référence d'acte de mariage: " + listePers.length);                //
          var nb = 0;                                                                                                  //
          var nbTotal = 0;                                                                                             //
          var nbDeleted = 0;                                                                                           //
          for (index in listePers) {                                                                                   //
          	var pers = listePers[index];                                                                                //
          	if (pers.mariages) {                                                                                        //
          		var update = false;                                                                                        //
          		for (indexM in pers.mariages) {                                                                            //
          			var mariage = pers.mariages[indexM];                                                                      //
          			var docRef = mariage.acte;                                                                                //
          			if (docRef) {                                                                                             //
          				var setIntruction = {$set:{}};                                                                           //
          				setIntruction.$set["mariages." + indexM + ".docs"] = [docRef];                                           //
          				if (Pers.update({ _id: pers._id },setIntruction))	{                                                      //
          					update = true;                                                                                          //
          					nbTotal +=1;                                                                                            //
          				}                                                                                                        //
          				else console.log("Pas de mise à jour pour " + pers._id);                                                 //
          			}                                                                                                         //
          			// On supprime l'ancienne référence vers l'acte                                                           //
          			var setIntruction = {$unset:{}};                                                                          //
          			setIntruction.$unset["mariages." + indexM + ".acte"] = "";                                                //
          			if (Pers.update({ _id: pers._id },setIntruction))	nbDeleted +=1;                                          //
          		}	                                                                                                         //
          		if (update) nb += 1;	                                                                                      //
          	}                                                                                                           //
          	else console.log("Pas d'acte de mariage pour " + pers._id);                                                 //
          }                                                                                                            //
          console.log(nb + " personnes dont références d'actes de mariages modifiés");                                 //
          console.log(nbTotal + " références d'actes total de mariages modifiés");                                     //
          console.log(nbDeleted + " références d'actes total de mariages supprimés");                                  //
                                                                                                                       //
          // Supprimer tous les actes maintenant                                                                       //
          console.log(Pers.update({"naissance.acte":{$exists:true}},   { $unset: { "naissance.acte": ""} },{multi:true}) + "ref actes naissance supprimés");
          console.log(Pers.update({"deces.acte":{$exists:true}},   { $unset: { "deces.acte": ""} },{multi:true}) + "ref actes décès supprimés");
          console.log(Pers.update({"mariages.$.acte":{$exists:true}},   { $unset: { "mariages.$.acte": ""} },{multi:true}) + "ref actes mariage supprimés");
          */ /*                                                                                                        //
             // =================================================                                                      //
             // Suppression des dates républicaines rep1 et rep2                                                       //
             // =================================================                                                      //
             // Pour les personnes                                                                                     //
             console.log(Pers.update({"naissance.date.rep1":{$exists:true}},   { $unset: { "naissance.date.rep1": ""} },{multi:true}));
             console.log(Pers.update({"naissance.date.rep2":{$exists:true}},   { $unset: { "naissance.date.rep2": ""} },{multi:true}));
             console.log(Pers.update({"deces.date.rep1":{$exists:true}},   { $unset: { "deces.date.rep1": ""} },{multi:true}));
             console.log(Pers.update({"deces.date.rep2":{$exists:true}},   { $unset: { "deces.date.rep2": ""} },{multi:true}));
                                                                                                                       //
             // Pour les mariages, on supprime de la liste des mariages rep1 et rep2                                   //
             var listePers = Pers.find({"mariages":{$exists:true}}).fetch();                                           //
             var nb = 0;                                                                                               //
             for (index in listePers) {                                                                                //
             	var pers = listePers[index];                                                                             //
             	var mariages = JSON.parse(JSON.stringify(pers.mariages));                                                //
             	for (index2 in mariages) {                                                                               //
             		var mariageCourant = mariages[index2];                                                                  //
             		if ( mariageCourant.date && ("rep1" in mariageCourant.date))		delete mariageCourant.date["rep1"];       //
             		if ( mariageCourant.date && ("rep2" in mariageCourant.date))		delete mariageCourant.date["rep2"];       //
             	}                                                                                                        //
             	Pers.update({_id:pers._id},  { $set: { "mariages": mariages} });                                         //
             	// On update les mariages pour la personne                                                               //
             	nb += 1;                                                                                                 //
             }                                                                                                         //
             console.log(nb + " mariages modifiés");                                                                   //
                                                                                                                       //
             // Pour des docs                                                                                          //
             console.log(Docs.update({"date.rep1":{$exists:true}},   { $unset: { "date.rep1": ""} },{multi:true}));    //
             console.log(Docs.update({"date.rep2":{$exists:true}},   { $unset: { "date.rep2": ""} },{multi:true}));    //
                                                                                                                       //
             // Pour les points d'histoire                                                                             //
             console.log(Hists.update({"date.rep1":{$exists:true}},   { $unset: { "date.rep1": ""} },{multi:true}));   //
             console.log(Hists.update({"date.rep2":{$exists:true}},   { $unset: { "date.rep2": ""} },{multi:true}));   //
                                                                                                                       //
             // =================================================                                                      //
             */ /*                                                                                                     //
                // Ajout des champs d'état de recherche actes et enfants pour les personnes                            //
                var listePers = Pers.find().fetch();                                                                   //
                var nb = 0;                                                                                            //
                for (index in listePers) {                                                                             //
                	var persCourant = listePers[index];                                                                   //
                	Pers.update(persCourant._id,{$set: {etatRechActes:"INCOMPLET_A_COMPLETER"}});                         //
                	nb += 1;                                                                                              //
                }                                                                                                      //
                console.log(nb + " personnes modifiées");                                                              //
                */ /*                                                                                                  //
                   // Exemple de modification multiple                                                                 //
                   console.log("Nb de users modifiés : " + Meteor.users.update( {} , {$unset: { "profile.lastLogin" : "" } } , {multi: true}));
                   */ // Impression de la variable d'environnement ----                                                //
                                                                                                                       //
console.log("ROOT_URL : " + Meteor.absoluteUrl());                                                                     // 798
console.log('Serveur démarré');                                                                                        // 799
console.log('---------------------------------------------');                                                          // 800
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"common":{"calendrierRepublicain.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// common/calendrierRepublicain.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// ==============================================                                                                      // 1
// Objet calRep de gestion du calendrier républicain                                                                   // 2
// ==============================================                                                                      // 3
// ??????????????????????????????????????????????                                                                      // 5
// A faire :                                                                                                           // 6
// - vérifier les paramètres, notamment la période de conversion : 22 sept 1792 au 31 déc 1805                         // 7
// ??????????????????????????????????????????????                                                                      // 8
// Inspiration de  : http://archives.numerisees.calvados.fr/cg14v3/outils/calendrier/calendrier_greg_rev.php mais bien bugué dans le sens grep -> rep !
CalendrierRepublicain = {                                                                                              // 12
	// Attributs                                                                                                          // 13
	// Correspond aux jours du calendrier grégorien / mois grégorien, correspondant au 1er du mois républicain dans l'ordre des mois indiqués dans l'array "mois"
	'jour': Array(Array(20, 19, 21, 20, 20, 19, 19, 18, 22, 22, 21, 21), /* 1792 soit An 0 - An I */ // Le 1er Pluviôse An I correspond au 20 janvier 1792, le 1er Ventôse au 19 février 1792, le 1er Germinal au 21 mars 1792 ...
	Array(20, 19, 21, 20, 20, 19, 19, 18, 22, 22, 21, 21), /* 1793 soit An I - An II */Array(20, 19, 21, 20, 20, 19, 19, 18, 22, 22, 21, 21), /* 1794 soit An II - An III */Array(20, 19, 21, 20, 20, 19, 19, 18, 23, 23, 22, 22), /* 1795 soit An III - An IV */Array(21, 20, 21, 20, 20, 19, 19, 18, 22, 22, 21, 21), /* 1796 soit An IV - An V */Array(20, 19, 21, 20, 20, 19, 19, 18, 22, 22, 21, 21), /* 1797 soit An V - An VI */Array(20, 19, 21, 20, 20, 19, 19, 18, 22, 22, 21, 21), /* 1798 soit An VI - An VII */Array(20, 19, 21, 20, 20, 19, 19, 18, 23, 23, 22, 22), /* 1799 soit An VII - An VIII */Array(21, 20, 22, 21, 21, 20, 20, 19, 23, 23, 22, 22), /* 1800 soit An VIII - An IX */Array(21, 20, 22, 21, 21, 20, 20, 19, 23, 23, 22, 22), /* 1801 soit An IX - An X */Array(21, 20, 22, 21, 21, 20, 20, 19, 23, 23, 22, 22), /* 1802 soit An X - An XI */Array(21, 20, 22, 21, 21, 20, 20, 19, 24, 24, 23, 23), /* 1803 soit An XI - An XII */Array(22, 21, 22, 21, 21, 20, 20, 19, 23, 23, 22, 22), /* 1804 soit An XII - An XIII */Array(21, 20, 22, 21, 21, 20, 20, 19, 23, 23, 22, 22 /* 1805 soit An XIII - An XIV */ // Vérifié sur un autre calendrier
	)),                                                                                                                   // 30
	// Correspond aux mois républicain synchronisés aux mois grégorien (commencant par janvier : array[0])                // 32
	'mois': Array("Pluviôse", "Ventôse", "Germinal", "Floréal", "Prairial", "Messidor", "Thermidor", "Fructidor", "Vendémiaire", "Brumaire", "Frimaire", "Nivôse"),
	'annee': Array("An I", "An II", "An III", "An IV", "An V", "An VI", "An VII", "An VIII", "An IX", "An X", "An XI", "An XII", "An XIII", "An XIV"),
	// Propriétés                                                                                                         // 36
	'estBissextile': function (annee) {                                                                                   // 37
		if (annee % 4 == 0) {                                                                                                // 38
			if (annee % 100 == 0) return annee % 400 == 0;else return true;                                                     // 39
		} else return false;                                                                                                 // 41
	},                                                                                                                    // 43
	'estJourRepublicain': function (jour, mois, annee) {                                                                  // 44
		// Si la date est complète et entre le 22 septembre 1792 et avant le 1er janvier 1806                                // 45
		// On force les paramètres à ::Integer                                                                               // 46
		jour = parseInt(jour);                                                                                               // 47
		mois = parseInt(mois);                                                                                               // 48
		annee = parseInt(annee); // On vérifie la complétude des paramètres                                                  // 49
                                                                                                                       //
		if (jour && mois && annee) {                                                                                         // 51
			if (jour >= 1 && jour <= 31 && mois >= 1 && mois <= 12) {                                                           // 52
				mois = mois - 1; // Pour l'utilisation du constructeur Date                                                        // 53
				// On vérifie le créneau                                                                                           // 54
                                                                                                                       //
				var dateMinIncludedTS = new Date(1792, 8, 22).getTime();                                                           // 55
				var dateMaxExcludedTS = new Date(1806, 0, 1).getTime();                                                            // 56
				var dateTS = new Date(annee, mois, jour).getTime();                                                                // 57
				if (dateTS >= dateMinIncludedTS && dateTS < dateMaxExcludedTS) return true;else return false;                      // 58
			} else return false;                                                                                                // 60
		} else return false;                                                                                                 // 62
	},                                                                                                                    // 64
	'nbJourMois': function (mois, annee) {                                                                                // 65
		if (mois == 2) {                                                                                                     // 66
			if (this.estBissextile(annee)) return 29;else return 28;                                                            // 67
		} else {                                                                                                             // 69
			if (mois == 1 || mois == 3 || mois == 5 || mois == 7 || mois == 8 || mois == 10 || mois == 12) return 31;else return 30;
		}                                                                                                                    // 79
	},                                                                                                                    // 80
	'repToGreg': function (jourRep, moisRep, anneeRep) {                                                                  // 81
		// Avec les mois numérotés de 1 à 12 de Vendémiaire à Fructidor,                                                     // 82
		// Les jours complémentaires sont les jours  31 à 35 du mois 12 de l'année considérée,                               // 83
		// Les années sont les années républicaines de 1 à 14.                                                               // 84
		// On force les paramètres à ::Integer                                                                               // 86
		jourRep = parseInt(jourRep);                                                                                         // 87
		moisRep = parseInt(moisRep);                                                                                         // 88
		anneeRep = parseInt(anneeRep);                                                                                       // 89
                                                                                                                       //
		if (jourRep && moisRep && anneeRep) {                                                                                // 91
			moisGreg = moisRep + 8;                                                                                             // 92
			anneeGreg = anneeRep + 1791;                                                                                        // 93
                                                                                                                       //
			if (moisGreg > 12) {                                                                                                // 94
				moisGreg -= 12;                                                                                                    // 95
				anneeGreg++;                                                                                                       // 96
			}                                                                                                                   // 97
                                                                                                                       //
			jourGreg = this.jour[anneeGreg - 1792][moisGreg - 1] + jourRep - 1;                                                 // 98
                                                                                                                       //
			if (jourGreg > this.nbJourMois(moisGreg, anneeGreg)) {                                                              // 99
				jourGreg -= this.nbJourMois(moisGreg, anneeGreg);                                                                  // 100
				moisGreg++;                                                                                                        // 101
                                                                                                                       //
				if (moisGreg > 12) {                                                                                               // 102
					moisGreg -= 12;                                                                                                   // 103
					anneeGreg++;                                                                                                      // 104
				}                                                                                                                  // 105
			}                                                                                                                   // 106
                                                                                                                       //
			return {                                                                                                            // 107
				'jour': jourGreg,                                                                                                  // 107
				'mois': moisGreg,                                                                                                  // 107
				'annee': anneeGreg                                                                                                 // 107
			};                                                                                                                  // 107
		} else return false;                                                                                                 // 108
	},                                                                                                                    // 110
	'gregToRep': function (jourGreg, moisGreg, anneeGreg) {                                                               // 111
		// On retourne :                                                                                                     // 112
		// Les mois numérotés de 1 à 12 de Vendémiaire à Fructidor,                                                          // 113
		// Les jours complémentaires sont les jours  31 à 35 du mois 12 de l'année considérée,                               // 114
		// Les années sont les années républicaines de 1 à 14.                                                               // 115
		// On force les paramètres à integer                                                                                 // 117
		jourGreg = parseInt(jourGreg);                                                                                       // 118
		moisGreg = parseInt(moisGreg);                                                                                       // 119
		anneeGreg = parseInt(anneeGreg); // Si c'est dans le créneau des jours républicains, on le convertit                 // 120
                                                                                                                       //
		if (this.estJourRepublicain(jourGreg, moisGreg, anneeGreg)) {                                                        // 122
			var result = {                                                                                                      // 123
				jour: null,                                                                                                        // 123
				mois: null,                                                                                                        // 123
				annee: null,                                                                                                       // 123
				text: null                                                                                                         // 123
			};                                                                                                                  // 123
                                                                                                                       //
			if (jourGreg >= this.jour[anneeGreg - 1792][moisGreg - 1]) {                                                        // 124
				// On calcule le résultat                                                                                          // 125
				result.jour = jourGreg + 1 - this.jour[anneeGreg - 1792][moisGreg - 1]; // L'année révolutionnaire commence en Vendémiaire (1er mois de l'année) dont l'indice dans les tables est 8
                                                                                                                       //
				if (moisGreg <= 8) anneeGreg--;                                                                                    // 128
				result.mois = moisGreg + 4;                                                                                        // 129
				if (result.mois > 12) result.mois -= 12;                                                                           // 130
				result.annee = anneeGreg - 1791; // On calcule le texte                                                            // 131
                                                                                                                       //
				result.text = result.jour + " " + this.mois[moisGreg - 1] + " " + this.annee[anneeGreg - 1792];                    // 133
			} else {                                                                                                            // 134
				// On calcule le jour pour le mois précédent :                                                                     // 136
				// Le 1er d'un mois républicain équivaut au 31 du mois d'avant sauf si le mois courant est vendémiaire,            // 137
				// il faut alors ajouter les 5 ou 6 sans-culottides !                                                              // 138
				if (moisGreg == 9) {                                                                                               // 139
					// Si sextile (1795 1799 1804) : on ajoute 6 sans-culottides                                                      // 140
					if (anneeGreg % 4 == 3) result.jour = 37 - (this.jour[anneeGreg - 1792][moisGreg - 1] - jourGreg); // Si non bissextile : on ajoute 5 sans-culottides
					else result.jour = 36 - (this.jour[anneeGreg - 1792][moisGreg - 1] - jourGreg);                                   // 141
				} else result.jour = 31 - (this.jour[anneeGreg - 1792][moisGreg - 1] - jourGreg); // On passe au mois précédent			
                                                                                                                       //
                                                                                                                       //
				moisGreg--;                                                                                                        // 147
                                                                                                                       //
				if (moisGreg <= 0) {                                                                                               // 148
					moisGreg = 12;                                                                                                    // 149
					anneeGreg--;                                                                                                      // 150
				} // L'année révolutionnaire commence en Vendémiaire (1er mois de l'année) dont l'indice dans les tables est 8     // 151
                                                                                                                       //
                                                                                                                       //
				if (moisGreg <= 8) anneeGreg--; // On calcule les mois et années                                                   // 153
                                                                                                                       //
				result.mois = moisGreg + 4;                                                                                        // 155
				if (result.mois > 12) result.mois -= 12;                                                                           // 156
				result.annee = anneeGreg - 1791; // On calcule les éventuels jours complémentaires et le texte                     // 157
                                                                                                                       //
				if (result.jour > 30) {                                                                                            // 159
					switch (result.jour - 30) {                                                                                       // 160
						case 1:                                                                                                          // 161
							result.text = "1er Compl. " + this.annee[anneeGreg - 1792];                                                     // 162
							break;                                                                                                          // 163
                                                                                                                       //
						default:                                                                                                         // 164
							result.text = result.jour - 30 + "ième Compl. " + this.annee[anneeGreg - 1792];                                 // 165
							break;                                                                                                          // 166
					}                                                                                                                 // 160
				} else result.text = result.jour + " " + this.mois[moisGreg - 1] + " " + this.annee[anneeGreg - 1792];             // 168
			}                                                                                                                   // 170
                                                                                                                       //
			return result;                                                                                                      // 171
		} else return false;                                                                                                 // 172
	}                                                                                                                     // 174
};                                                                                                                     // 12
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"common.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// common/common.js                                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// ==============================================                                                                      // 1
// Fonctions globales communes                                                                                         // 2
// ==============================================                                                                      // 3
gf_thereIsNoPointingObject = function (pointingObjectList) {                                                           // 5
	// Si tt est vide, on revoie true                                                                                     // 6
	return pointingObjectList.PERS.length === 0 && pointingObjectList.COUPLE_EVENT.length === 0 && pointingObjectList.LIEU.length === 0 && pointingObjectList.HIST.length === 0 && pointingObjectList.DOC.length === 0 && pointingObjectList.LIEN.length === 0 && pointingObjectList.REGISTRE.length === 0 && pointingObjectList.ACTE_ARCHIVES.length === 0;
}; // Obtenir la liste de tous les objets pointant vers un objet donné                                                 // 15
                                                                                                                       //
                                                                                                                       //
gf_getPointingObjects = function (obj, type) {                                                                         // 18
	// On vérifie les paramètres --------------------------                                                               // 19
	if (type == "PERS" || type == "COUPLE_EVENT" || type == "LIEU" || type == "HIST" || type == "DOC" || type == "LIEN" || type == "REGISTRE" || type == "ACTE_ARCHIVES" || type == "TAG") {
		// Ici les paramètres sont OK ---------------------                                                                  // 29
		// On prépare le résultat -------------------------                                                                  // 30
		var result = {                                                                                                       // 31
			PERS: [],                                                                                                           // 32
			COUPLE_EVENT: [],                                                                                                   // 33
			LIEU: [],                                                                                                           // 34
			HIST: [],                                                                                                           // 35
			DOC: [],                                                                                                            // 36
			LIEN: [],                                                                                                           // 37
			REGISTRE: [],                                                                                                       // 38
			ACTE_ARCHIVES: []                                                                                                   // 39
		};                                                                                                                   // 31
                                                                                                                       //
		for (typeObjetsRecherches in meteorBabelHelpers.sanitizeForInObject(parms_liens)) {                                  // 42
			for (propriete in meteorBabelHelpers.sanitizeForInObject(parms_liens[typeObjetsRecherches])) {                      // 43
				// Si le type de l'objet correspond à la propriete                                                                 // 44
				if (type === propriete) {                                                                                          // 45
					// On balaye les champs possibles                                                                                 // 46
					var listeChampsCourants = parms_liens[typeObjetsRecherches][propriete];                                           // 47
                                                                                                                       //
					for (index in meteorBabelHelpers.sanitizeForInObject(listeChampsCourants)) {                                      // 48
						var lienCourant = listeChampsCourants[index];                                                                    // 49
						var request = {}; // Construction de la requête selon le matchType                                               // 50
                                                                                                                       //
						var matchTypeCorrect = true;                                                                                     // 52
                                                                                                                       //
						switch (lienCourant.matchType) {                                                                                 // 53
							case "id":                                                                                                      // 54
								request[lienCourant.prop] = obj._id;                                                                           // 55
								break;                                                                                                         // 56
                                                                                                                       //
							case "containId":                                                                                               // 57
								request[lienCourant.prop] = {};                                                                                // 58
								request[lienCourant.prop].$regex = ".*" + obj._id + ".*";                                                      // 59
								request[lienCourant.prop].$options = 'i';                                                                      // 60
								break;                                                                                                         // 61
                                                                                                                       //
							case "containOldId":                                                                                            // 62
								request[lienCourant.prop] = {};                                                                                // 63
								request[lienCourant.prop].$regex = ".*" + obj.id + ".*";                                                       // 64
								request[lienCourant.prop].$options = 'i';                                                                      // 65
								break;                                                                                                         // 66
                                                                                                                       //
							case "lienPour":                                                                                                // 67
								request[lienCourant.prop] = obj._id;                                                                           // 68
								request["pour.type"] = type;                                                                                   // 69
								break;                                                                                                         // 70
                                                                                                                       //
							case "lienVers":                                                                                                // 71
								request[lienCourant.prop] = obj._id;                                                                           // 72
								request["vers.type"] = type;                                                                                   // 73
								break;                                                                                                         // 74
                                                                                                                       //
							default:                                                                                                        // 75
								console.log("Erreur module\"gf_getPointingObjects\" : matchType non supporté (seuls \"id\", \"containId\" et \"containOldId\" autorisés) : " + lienCourant.matchType); // Pour éviter de faire la recherche
                                                                                                                       //
								matchTypeCorrect = false;                                                                                      // 78
								break;                                                                                                         // 79
						} // Application de la requête à la bonne collection                                                             // 53
                                                                                                                       //
                                                                                                                       //
						if (matchTypeCorrect) {                                                                                          // 82
							switch (typeObjetsRecherches) {                                                                                 // 83
								case "PERS":                                                                                                   // 84
									var list = Pers.find(request).fetch();                                                                        // 85
									break;                                                                                                        // 86
                                                                                                                       //
								case "COUPLE_EVENT":                                                                                           // 87
									var list = CoupleEvents.find(request).fetch();                                                                // 88
									break;                                                                                                        // 89
                                                                                                                       //
								case "LIEU":                                                                                                   // 90
									var list = Lieux.find(request).fetch();                                                                       // 91
									break;                                                                                                        // 92
                                                                                                                       //
								case "HIST":                                                                                                   // 93
									var list = Hists.find(request).fetch();                                                                       // 94
									break;                                                                                                        // 95
                                                                                                                       //
								case "DOC":                                                                                                    // 96
									var list = Docs.find(request).fetch();                                                                        // 97
									break;                                                                                                        // 98
                                                                                                                       //
								case "LIEN":                                                                                                   // 99
									var list = Liens.find(request).fetch();                                                                       // 100
									break;                                                                                                        // 101
                                                                                                                       //
								case "REGISTRE":                                                                                               // 102
									var list = Registres.find(request).fetch();                                                                   // 103
									break;                                                                                                        // 104
                                                                                                                       //
								case "ACTE_ARCHIVES":                                                                                          // 105
									var list = ActesArchives.find(request).fetch();                                                               // 106
									break;                                                                                                        // 107
                                                                                                                       //
								default:                                                                                                       // 108
									console.log("Erreur module\"gf_getPointingObjects\" : type d'objet non supporté : " + typeObjetsRecherches);  // 109
									break;                                                                                                        // 110
							}                                                                                                               // 83
                                                                                                                       //
							var resultat = {                                                                                                // 112
								"prop": lienCourant.prop,                                                                                      // 113
								"matchType": lienCourant.matchType,                                                                            // 114
								"afficherInfos": lienCourant.afficherInfos,                                                                    // 115
								"intitule": lienCourant.intitule[LANG],                                                                        // 116
								"list": list                                                                                                   // 117
							};                                                                                                              // 112
							if (list.length != 0) result[typeObjetsRecherches].push(resultat);                                              // 119
						}                                                                                                                // 120
					}                                                                                                                 // 121
				}                                                                                                                  // 122
			}                                                                                                                   // 123
		}                                                                                                                    // 124
                                                                                                                       //
		return result;                                                                                                       // 125
	} else return false;                                                                                                  // 126
}; // ==============================================                                                                   // 128
// Extensions String                                                                                                   // 131
// ==============================================                                                                      // 132
                                                                                                                       //
                                                                                                                       //
String.prototype.diacriticFilter = function () {                                                                       // 134
	return this.replace(/[èéêë]/g, "e").replace(/[àâ]/g, "a").replace(/[ç]/g, "c").replace(/[ùû]/g, "u").replace(/[ïî]/g, "i").replace(/[ôö]/g, "o");
};                                                                                                                     // 136
                                                                                                                       //
String.prototype.capitalizeFirstLetter = function () {                                                                 // 138
	return this.charAt(0).diacriticFilter().toUpperCase() + this.slice(1);                                                // 139
}; // ==============================================                                                                   // 140
// Collections                                                                                                         // 143
// ==============================================                                                                      // 144
                                                                                                                       //
                                                                                                                       //
Lieux = new Meteor.Collection("lieux");                                                                                // 145
Docs = new Meteor.Collection("docs");                                                                                  // 146
Pers = new Meteor.Collection("pers");                                                                                  // 147
Registres = new Meteor.Collection("registres");                                                                        // 148
Bugs = new Meteor.Collection("bugs");                                                                                  // 149
Hists = new Meteor.Collection("hists");                                                                                // 150
Profs = new Meteor.Collection("profs");                                                                                // 151
Liens = new Meteor.Collection("liens");                                                                                // 152
ActesArchives = new Meteor.Collection("actesArchives");                                                                // 153
CoupleEvents = new Meteor.Collection("coupleEvents");                                                                  // 154
Tags = new Meteor.Collection("tags"); // ==============================================                                // 155
// Forbit Account creation from client                                                                                 // 158
// ==============================================                                                                      // 159
                                                                                                                       //
Accounts.config({                                                                                                      // 160
	forbidClientAccountCreation: true                                                                                     // 161
});                                                                                                                    // 160
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"commonParms.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// common/commonParms.js                                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// ==============================================                                                                      // 1
// Pour générer les listes d'options (avec un intitulé générique en option)                                            // 2
// ==============================================                                                                      // 3
parametreCommuns = {                                                                                                   // 4
	// Types d'objets possibles pour les liens                                                                            // 5
	"typesObjetsGen": [{                                                                                                  // 6
		valeur: "PERS",                                                                                                      // 7
		intitule: {                                                                                                          // 7
			"FR": "personne"                                                                                                    // 7
		}                                                                                                                    // 7
	}, {                                                                                                                  // 7
		valeur: "LIEU",                                                                                                      // 8
		intitule: {                                                                                                          // 8
			"FR": "lieu"                                                                                                        // 8
		}                                                                                                                    // 8
	}, {                                                                                                                  // 8
		valeur: "HIST",                                                                                                      // 9
		intitule: {                                                                                                          // 9
			"FR": "pt d'histoire"                                                                                               // 9
		}                                                                                                                    // 9
	}, {                                                                                                                  // 9
		valeur: "DOC",                                                                                                       // 10
		intitule: {                                                                                                          // 10
			"FR": "document"                                                                                                    // 10
		}                                                                                                                    // 10
	}],                                                                                                                   // 10
	// Types de zones possibles pour les liens                                                                            // 12
	"typesZonesLien": [{                                                                                                  // 13
		valeur: "ALL",                                                                                                       // 14
		intitule: {                                                                                                          // 14
			"FR": "pas de zone spécifiée, tout"                                                                                 // 14
		}                                                                                                                    // 14
	}, {                                                                                                                  // 14
		valeur: "CIRCLE",                                                                                                    // 15
		intitule: {                                                                                                          // 15
			"FR": "cercle"                                                                                                      // 15
		}                                                                                                                    // 15
	}, {                                                                                                                  // 15
		valeur: "RECT",                                                                                                      // 16
		intitule: {                                                                                                          // 16
			"FR": "rectangle"                                                                                                   // 16
		}                                                                                                                    // 16
	}, {                                                                                                                  // 16
		valeur: "POINT",                                                                                                     // 17
		intitule: {                                                                                                          // 17
			"FR": "point"                                                                                                       // 17
		}                                                                                                                    // 17
	}, {                                                                                                                  // 17
		valeur: "LAT_LNG",                                                                                                   // 18
		intitule: {                                                                                                          // 18
			"FR": "lattitude-longitude"                                                                                         // 18
		}                                                                                                                    // 18
	}, {                                                                                                                  // 18
		valeur: "RECORDING",                                                                                                 // 19
		intitule: {                                                                                                          // 19
			"FR": "extrait audio ou vidéo"                                                                                      // 19
		}                                                                                                                    // 19
	}, {                                                                                                                  // 19
		valeur: "PDF",                                                                                                       // 20
		intitule: {                                                                                                          // 20
			"FR": "zone sur un PDF"                                                                                             // 20
		}                                                                                                                    // 20
	}],                                                                                                                   // 20
	// Types de lieux ------------------------------------------------------                                              // 22
	"typesLieux": [{                                                                                                      // 23
		valeur: "LIEUDIT",                                                                                                   // 24
		intitule: {                                                                                                          // 24
			"FR": "un lieu-dit"                                                                                                 // 24
		}                                                                                                                    // 24
	}, {                                                                                                                  // 24
		valeur: "COMMUNE",                                                                                                   // 25
		intitule: {                                                                                                          // 25
			"FR": "une commune"                                                                                                 // 25
		}                                                                                                                    // 25
	}, {                                                                                                                  // 25
		valeur: "DEPARTEMENT",                                                                                               // 26
		intitule: {                                                                                                          // 26
			"FR": "un département"                                                                                              // 26
		}                                                                                                                    // 26
	}, {                                                                                                                  // 26
		valeur: "PAYS",                                                                                                      // 27
		intitule: {                                                                                                          // 27
			"FR": "un pays"                                                                                                     // 27
		}                                                                                                                    // 27
	}, {                                                                                                                  // 27
		valeur: "CONTINENT",                                                                                                 // 28
		intitule: {                                                                                                          // 28
			"FR": "un continent"                                                                                                // 28
		}                                                                                                                    // 28
	}, {                                                                                                                  // 28
		valeur: "MAISON",                                                                                                    // 29
		intitule: {                                                                                                          // 29
			"FR": "un maison"                                                                                                   // 29
		}                                                                                                                    // 29
	}, {                                                                                                                  // 29
		valeur: "MOULIN",                                                                                                    // 30
		intitule: {                                                                                                          // 30
			"FR": "un moulin"                                                                                                   // 30
		}                                                                                                                    // 30
	}, {                                                                                                                  // 30
		valeur: "PONT",                                                                                                      // 31
		intitule: {                                                                                                          // 31
			"FR": "un pont"                                                                                                     // 31
		}                                                                                                                    // 31
	}, {                                                                                                                  // 31
		valeur: "CHATEAU",                                                                                                   // 32
		intitule: {                                                                                                          // 32
			"FR": "un château"                                                                                                  // 32
		}                                                                                                                    // 32
	}, {                                                                                                                  // 32
		valeur: "ABBAYE",                                                                                                    // 33
		intitule: {                                                                                                          // 33
			"FR": "un abbaye"                                                                                                   // 33
		}                                                                                                                    // 33
	}, {                                                                                                                  // 33
		valeur: "ECUEIL",                                                                                                    // 34
		intitule: {                                                                                                          // 34
			"FR": "un écueil"                                                                                                   // 34
		}                                                                                                                    // 34
	}, {                                                                                                                  // 34
		valeur: "ILE",                                                                                                       // 35
		intitule: {                                                                                                          // 35
			"FR": "une île"                                                                                                     // 35
		}                                                                                                                    // 35
	}, {                                                                                                                  // 35
		valeur: "ZONEMARITIME",                                                                                              // 36
		intitule: {                                                                                                          // 36
			"FR": "une zone maritime"                                                                                           // 36
		}                                                                                                                    // 36
	}, {                                                                                                                  // 36
		valeur: "MER",                                                                                                       // 37
		intitule: {                                                                                                          // 37
			"FR": "une mer"                                                                                                     // 37
		}                                                                                                                    // 37
	}, {                                                                                                                  // 37
		valeur: "OCEAN",                                                                                                     // 38
		intitule: {                                                                                                          // 38
			"FR": "un océan"                                                                                                    // 38
		}                                                                                                                    // 38
	}, {                                                                                                                  // 38
		valeur: "TERRE",                                                                                                     // 39
		intitule: {                                                                                                          // 39
			"FR": "la Terre"                                                                                                    // 39
		}                                                                                                                    // 39
	}, {                                                                                                                  // 39
		valeur: "REGIONE_IT",                                                                                                // 40
		intitule: {                                                                                                          // 40
			"FR": "une région (it.)"                                                                                            // 40
		}                                                                                                                    // 40
	}, {                                                                                                                  // 40
		valeur: "PROVINCIA_IT",                                                                                              // 41
		intitule: {                                                                                                          // 41
			"FR": "une province (it.)"                                                                                          // 41
		}                                                                                                                    // 41
	}],                                                                                                                   // 41
	// Sur-lieu normal d'un lieu -------------------------------------------                                              // 44
	"surlieuNormal": {                                                                                                    // 45
		"LIEUDIT": "COMMUNE",                                                                                                // 46
		"COMMUNE": "DEPARTEMENT",                                                                                            // 47
		"DEPARTEMENT": "PAYS",                                                                                               // 48
		"PAYS": "CONTINENT",                                                                                                 // 49
		"CONTINENT": "TERRE",                                                                                                // 50
		"MAISON": "LIEUDIT",                                                                                                 // 51
		"MOULIN": "LIEUDIT",                                                                                                 // 52
		"PONT": "LIEUDIT",                                                                                                   // 53
		"CHATEAU": "LIEUDIT",                                                                                                // 54
		"ABBAYE": "LIEUDIT",                                                                                                 // 55
		"ECUEIL": "ZONEMARITIME",                                                                                            // 56
		"ILE": "ZONEMARITIME",                                                                                               // 57
		"ZONEMARITIME": "TERRE",                                                                                             // 58
		"MER": "TERRE",                                                                                                      // 59
		"OCEAN": "TERRE",                                                                                                    // 60
		"TERRE": null                                                                                                        // 61
	},                                                                                                                    // 45
	// Types de dates ------------------------------------------------------                                              // 63
	"typesDates": [{                                                                                                      // 64
		valeur: "LE",                                                                                                        // 65
		intitule: {                                                                                                          // 65
			"FR": "Le"                                                                                                          // 65
		}                                                                                                                    // 65
	}, {                                                                                                                  // 65
		valeur: "VERS",                                                                                                      // 66
		intitule: {                                                                                                          // 66
			"FR": "Vers"                                                                                                        // 66
		}                                                                                                                    // 66
	}, {                                                                                                                  // 66
		valeur: "AVANT",                                                                                                     // 67
		intitule: {                                                                                                          // 67
			"FR": "Avant"                                                                                                       // 67
		}                                                                                                                    // 67
	}, {                                                                                                                  // 67
		valeur: "APRES",                                                                                                     // 68
		intitule: {                                                                                                          // 68
			"FR": "Après"                                                                                                       // 68
		}                                                                                                                    // 68
	}, {                                                                                                                  // 68
		valeur: "ENTRE",                                                                                                     // 69
		intitule: {                                                                                                          // 69
			"FR": "Entre"                                                                                                       // 69
		}                                                                                                                    // 69
	}],                                                                                                                   // 69
	// Types de registres --------------------------------------------------                                              // 72
	"typesRegistres": [{                                                                                                  // 73
		valeur: "Registres Paroissiaux, collection communale",                                                               // 74
		intitule: {                                                                                                          // 74
			"FR": "Registres Paroissiaux, collection communale"                                                                 // 74
		}                                                                                                                    // 74
	}, {                                                                                                                  // 74
		valeur: "Registres Paroissiaux, collection départementale",                                                          // 75
		intitule: {                                                                                                          // 75
			"FR": "Registres Paroissiaux, collection départementale"                                                            // 75
		}                                                                                                                    // 75
	}, {                                                                                                                  // 75
		valeur: "Registres Paroissiaux",                                                                                     // 76
		intitule: {                                                                                                          // 76
			"FR": "Registres Paroissiaux"                                                                                       // 76
		}                                                                                                                    // 76
	}, {                                                                                                                  // 76
		valeur: "Actes de catholicité",                                                                                      // 77
		intitule: {                                                                                                          // 77
			"FR": "Actes de catholicité"                                                                                        // 77
		}                                                                                                                    // 77
	}, {                                                                                                                  // 77
		valeur: "Etat civil",                                                                                                // 78
		intitule: {                                                                                                          // 78
			"FR": "Etat civil"                                                                                                  // 78
		}                                                                                                                    // 78
	}, {                                                                                                                  // 78
		valeur: "Tables",                                                                                                    // 79
		intitule: {                                                                                                          // 79
			"FR": "Tables"                                                                                                      // 79
		}                                                                                                                    // 79
	}],                                                                                                                   // 79
	// Types de docs -------------------------------------------------------                                              // 82
	"typesDocs": [{                                                                                                       // 83
		valeur: "ACTE",                                                                                                      // 84
		intitule: {                                                                                                          // 84
			"FR": "un acte d'état civil ou religieux"                                                                           // 84
		}                                                                                                                    // 84
	}, {                                                                                                                  // 84
		valeur: "NOTAIRE",                                                                                                   // 85
		intitule: {                                                                                                          // 85
			"FR": "un acte notarial"                                                                                            // 85
		}                                                                                                                    // 85
	}, {                                                                                                                  // 85
		valeur: "MILITAIRE",                                                                                                 // 86
		intitule: {                                                                                                          // 86
			"FR": "un document militaire"                                                                                       // 86
		}                                                                                                                    // 86
	}, {                                                                                                                  // 86
		valeur: "COMMUNAL",                                                                                                  // 87
		intitule: {                                                                                                          // 87
			"FR": "un document communal"                                                                                        // 87
		}                                                                                                                    // 87
	}, {                                                                                                                  // 87
		valeur: "JUSTICE",                                                                                                   // 88
		intitule: {                                                                                                          // 88
			"FR": "un acte de justice"                                                                                          // 88
		}                                                                                                                    // 88
	}, {                                                                                                                  // 88
		valeur: "PHOTO",                                                                                                     // 89
		intitule: {                                                                                                          // 89
			"FR": "une photo"                                                                                                   // 89
		}                                                                                                                    // 89
	}, {                                                                                                                  // 89
		valeur: "VIDEO",                                                                                                     // 90
		intitule: {                                                                                                          // 90
			"FR": "une vidéo"                                                                                                   // 90
		}                                                                                                                    // 90
	}, {                                                                                                                  // 90
		valeur: "CARTE_POSTALE",                                                                                             // 91
		intitule: {                                                                                                          // 91
			"FR": "une carte postale"                                                                                           // 91
		}                                                                                                                    // 91
	}, {                                                                                                                  // 91
		valeur: "CARTE",                                                                                                     // 92
		intitule: {                                                                                                          // 92
			"FR": "une carte géographique"                                                                                      // 92
		}                                                                                                                    // 92
	}, {                                                                                                                  // 92
		valeur: "CADASTRE",                                                                                                  // 93
		intitule: {                                                                                                          // 93
			"FR": "une carte cadastrale"                                                                                        // 93
		}                                                                                                                    // 93
	}, {                                                                                                                  // 93
		valeur: "COURRIER",                                                                                                  // 94
		intitule: {                                                                                                          // 94
			"FR": "un courrier"                                                                                                 // 94
		}                                                                                                                    // 94
	}, {                                                                                                                  // 94
		valeur: "JOURNAL",                                                                                                   // 95
		intitule: {                                                                                                          // 95
			"FR": "un journal"                                                                                                  // 95
		}                                                                                                                    // 95
	}, {                                                                                                                  // 95
		valeur: "LIVRE",                                                                                                     // 96
		intitule: {                                                                                                          // 96
			"FR": "un livre"                                                                                                    // 96
		}                                                                                                                    // 96
	}, {                                                                                                                  // 96
		valeur: "PAPIER",                                                                                                    // 97
		intitule: {                                                                                                          // 97
			"FR": "un papier autre"                                                                                             // 97
		}                                                                                                                    // 97
	}, {                                                                                                                  // 97
		valeur: "OBJET",                                                                                                     // 98
		intitule: {                                                                                                          // 98
			"FR": "un objet"                                                                                                    // 98
		}                                                                                                                    // 98
	}, {                                                                                                                  // 98
		valeur: "AUTRE",                                                                                                     // 99
		intitule: {                                                                                                          // 99
			"FR": "autre chose"                                                                                                 // 99
		}                                                                                                                    // 99
	}],                                                                                                                   // 99
	// Codages de docs ----------------------------------------------------                                               // 102
	// Le codage correspond au viewer utilisé                                                                             // 103
	"codagesDocs": [{                                                                                                     // 104
		valeur: "IMAGE",                                                                                                     // 105
		intitule: {                                                                                                          // 105
			"FR": "codage image"                                                                                                // 105
		}                                                                                                                    // 105
	}, {                                                                                                                  // 105
		valeur: "CARTE",                                                                                                     // 106
		intitule: {                                                                                                          // 106
			"FR": "codage carte"                                                                                                // 106
		}                                                                                                                    // 106
	}, {                                                                                                                  // 106
		valeur: "GEO_REF",                                                                                                   // 107
		intitule: {                                                                                                          // 107
			"FR": "codage image géo-référencée"                                                                                 // 107
		}                                                                                                                    // 107
	}, {                                                                                                                  // 107
		valeur: "ACTE",                                                                                                      // 108
		intitule: {                                                                                                          // 108
			"FR": "codage acte"                                                                                                 // 108
		}                                                                                                                    // 108
	}, {                                                                                                                  // 108
		valeur: "VIDEO",                                                                                                     // 109
		intitule: {                                                                                                          // 109
			"FR": "codage vidéo"                                                                                                // 109
		}                                                                                                                    // 109
	}, {                                                                                                                  // 109
		valeur: "GROUPE",                                                                                                    // 110
		intitule: {                                                                                                          // 110
			"FR": "codage groupe"                                                                                               // 110
		}                                                                                                                    // 110
	}, {                                                                                                                  // 110
		valeur: "TEXTE_XML",                                                                                                 // 111
		intitule: {                                                                                                          // 111
			"FR": "codage texte XML"                                                                                            // 111
		}                                                                                                                    // 111
	}, {                                                                                                                  // 111
		valeur: "PDF",                                                                                                       // 112
		intitule: {                                                                                                          // 112
			"FR": "codage pdf"                                                                                                  // 112
		}                                                                                                                    // 112
	}, {                                                                                                                  // 112
		valeur: "DOC",                                                                                                       // 113
		intitule: {                                                                                                          // 113
			"FR": "codage Word"                                                                                                 // 113
		}                                                                                                                    // 113
	}],                                                                                                                   // 113
	// Affichage de la nature de l'acte                                                                                   // 116
	"typeActe": [{                                                                                                        // 117
		valeur: "NAISSANCE",                                                                                                 // 118
		intitule: {                                                                                                          // 118
			"FR": "Acte de naissance"                                                                                           // 118
		}                                                                                                                    // 118
	}, {                                                                                                                  // 118
		valeur: "NAIS-DEC",                                                                                                  // 119
		intitule: {                                                                                                          // 119
			"FR": "Acte de naissance et décès"                                                                                  // 119
		}                                                                                                                    // 119
	}, {                                                                                                                  // 119
		valeur: "BAPTEME",                                                                                                   // 120
		intitule: {                                                                                                          // 120
			"FR": "Acte de baptême"                                                                                             // 120
		}                                                                                                                    // 120
	}, {                                                                                                                  // 120
		valeur: "BAPT-SEP",                                                                                                  // 121
		intitule: {                                                                                                          // 121
			"FR": "Acte de baptême et de sépulture"                                                                             // 121
		}                                                                                                                    // 121
	}, {                                                                                                                  // 121
		valeur: "MARIAGE",                                                                                                   // 122
		intitule: {                                                                                                          // 122
			"FR": "Acte de mariage"                                                                                             // 122
		}                                                                                                                    // 122
	}, {                                                                                                                  // 122
		valeur: "PUBLICATION-BANS",                                                                                          // 123
		intitule: {                                                                                                          // 123
			"FR": "Certificat de publication des bans"                                                                          // 123
		}                                                                                                                    // 123
	}, {                                                                                                                  // 123
		valeur: "PROMESSE",                                                                                                  // 124
		intitule: {                                                                                                          // 124
			"FR": "Acte de promesse de mariage"                                                                                 // 124
		}                                                                                                                    // 124
	}, {                                                                                                                  // 124
		valeur: "DECES",                                                                                                     // 125
		intitule: {                                                                                                          // 125
			"FR": "Acte de décès"                                                                                               // 125
		}                                                                                                                    // 125
	}, {                                                                                                                  // 125
		valeur: "DEC-NAIS",                                                                                                  // 126
		intitule: {                                                                                                          // 126
			"FR": "Acte de décès et de naissance"                                                                               // 126
		}                                                                                                                    // 126
	}, {                                                                                                                  // 126
		valeur: "SEPULTURE",                                                                                                 // 127
		intitule: {                                                                                                          // 127
			"FR": "Acte de sépulture"                                                                                           // 127
		}                                                                                                                    // 127
	}, {                                                                                                                  // 127
		valeur: "SEP-BAPT",                                                                                                  // 128
		intitule: {                                                                                                          // 128
			"FR": "Acte de sépulture et de baptême"                                                                             // 128
		}                                                                                                                    // 128
	}, {                                                                                                                  // 128
		valeur: "DIVORCE",                                                                                                   // 129
		intitule: {                                                                                                          // 129
			"FR": "Acte de divorce"                                                                                             // 129
		}                                                                                                                    // 129
	}, {                                                                                                                  // 129
		valeur: "PACS",                                                                                                      // 130
		intitule: {                                                                                                          // 130
			"FR": "Acte de PACS"                                                                                                // 130
		}                                                                                                                    // 130
	}, {                                                                                                                  // 130
		valeur: "AUTRE",                                                                                                     // 131
		intitule: {                                                                                                          // 131
			"FR": "Autre acte"                                                                                                  // 131
		}                                                                                                                    // 131
	}],                                                                                                                   // 131
	// Affichage de la nature de l'évènement conjugal                                                                     // 134
	"coupleEventType": [{                                                                                                 // 135
		valeur: "MARIAGE",                                                                                                   // 136
		intitule: {                                                                                                          // 136
			"FR": "mariage"                                                                                                     // 136
		}                                                                                                                    // 136
	}, {                                                                                                                  // 136
		valeur: "DIVORCE",                                                                                                   // 137
		intitule: {                                                                                                          // 137
			"FR": "divorce"                                                                                                     // 137
		}                                                                                                                    // 137
	}, {                                                                                                                  // 137
		valeur: "UNION-LIBRE",                                                                                               // 138
		intitule: {                                                                                                          // 138
			"FR": "union libre"                                                                                                 // 138
		}                                                                                                                    // 138
	}, {                                                                                                                  // 138
		valeur: "PACS",                                                                                                      // 139
		intitule: {                                                                                                          // 139
			"FR": "PACS"                                                                                                        // 139
		}                                                                                                                    // 139
	}],                                                                                                                   // 139
	// Mode de l'image                                                                                                    // 142
	"modeIMAGE": [{                                                                                                       // 143
		valeur: "IMAGE",                                                                                                     // 144
		intitule: {                                                                                                          // 144
			"FR": "image par image"                                                                                             // 144
		}                                                                                                                    // 144
	}, {                                                                                                                  // 144
		valeur: "LIVRE",                                                                                                     // 145
		intitule: {                                                                                                          // 145
			"FR": "livre"                                                                                                       // 145
		}                                                                                                                    // 145
	}],                                                                                                                   // 145
	// Genre du lieu -------------------------------------------------------                                              // 148
	"genresLieux": [{                                                                                                     // 149
		valeur: "MS",                                                                                                        // 150
		intitule: {                                                                                                          // 150
			"FR": "le"                                                                                                          // 150
		}                                                                                                                    // 150
	}, {                                                                                                                  // 150
		valeur: "FS",                                                                                                        // 151
		intitule: {                                                                                                          // 151
			"FR": "la"                                                                                                          // 151
		}                                                                                                                    // 151
	}, {                                                                                                                  // 151
		valeur: "PL",                                                                                                        // 152
		intitule: {                                                                                                          // 152
			"FR": "les"                                                                                                         // 152
		}                                                                                                                    // 152
	}, {                                                                                                                  // 152
		valeur: "ES",                                                                                                        // 153
		intitule: {                                                                                                          // 153
			"FR": "l'"                                                                                                          // 153
		}                                                                                                                    // 153
	}, {                                                                                                                  // 153
		valeur: "SS",                                                                                                        // 154
		intitule: {                                                                                                          // 154
			"FR": "-"                                                                                                           // 154
		}                                                                                                                    // 154
	}],                                                                                                                   // 154
	// Zones de points d'histoire ----------------------------------------                                                // 157
	"zonesHist": [{                                                                                                       // 158
		valeur: "HIST_MONDE",                                                                                                // 159
		intitule: {                                                                                                          // 159
			"FR": "monde"                                                                                                       // 159
		}                                                                                                                    // 159
	}, {                                                                                                                  // 159
		valeur: "HIST_EUROPE",                                                                                               // 160
		intitule: {                                                                                                          // 160
			"FR": "Europe"                                                                                                      // 160
		}                                                                                                                    // 160
	}, {                                                                                                                  // 160
		valeur: "HIST_FRANCE",                                                                                               // 161
		intitule: {                                                                                                          // 161
			"FR": "France"                                                                                                      // 161
		}                                                                                                                    // 161
	}, {                                                                                                                  // 161
		valeur: "HIST_POITOU",                                                                                               // 162
		intitule: {                                                                                                          // 162
			"FR": "Poitou"                                                                                                      // 162
		}                                                                                                                    // 162
	}, {                                                                                                                  // 162
		valeur: "HIST_VENDEE",                                                                                               // 163
		intitule: {                                                                                                          // 163
			"FR": "Vendée"                                                                                                      // 163
		}                                                                                                                    // 163
	}, {                                                                                                                  // 163
		valeur: "HIST_MARAIS",                                                                                               // 164
		intitule: {                                                                                                          // 164
			"FR": "marais"                                                                                                      // 164
		}                                                                                                                    // 164
	}, {                                                                                                                  // 164
		valeur: "HIST_COMMUNE",                                                                                              // 165
		intitule: {                                                                                                          // 165
			"FR": "paroisse, commune"                                                                                           // 165
		}                                                                                                                    // 165
	}],                                                                                                                   // 165
	// Types d'objets concernés par les tags -----------------------------                                                // 168
	"objTypesForTags": [{                                                                                                 // 169
		valeur: "PERS",                                                                                                      // 170
		intitule: {                                                                                                          // 170
			"FR": "personnes"                                                                                                   // 170
		}                                                                                                                    // 170
	}, {                                                                                                                  // 170
		valeur: "LIEU",                                                                                                      // 171
		intitule: {                                                                                                          // 171
			"FR": "lieux"                                                                                                       // 171
		}                                                                                                                    // 171
	}, {                                                                                                                  // 171
		valeur: "DOC",                                                                                                       // 172
		intitule: {                                                                                                          // 172
			"FR": "documents"                                                                                                   // 172
		}                                                                                                                    // 172
	}, {                                                                                                                  // 172
		valeur: "HIST",                                                                                                      // 173
		intitule: {                                                                                                          // 173
			"FR": "points d'histoire"                                                                                           // 173
		}                                                                                                                    // 173
	}],                                                                                                                   // 173
	// Scopes de points d'histoire ----------------------------------------                                               // 176
	"scopesHist": [{                                                                                                      // 177
		valeur: "NATIONAL",                                                                                                  // 178
		intitule: {                                                                                                          // 178
			"FR": "national"                                                                                                    // 178
		}                                                                                                                    // 178
	}, {                                                                                                                  // 178
		valeur: "REGIONAL",                                                                                                  // 179
		intitule: {                                                                                                          // 179
			"FR": "régional"                                                                                                    // 179
		}                                                                                                                    // 179
	}, {                                                                                                                  // 179
		valeur: "LOCAL",                                                                                                     // 180
		intitule: {                                                                                                          // 180
			"FR": "local"                                                                                                       // 180
		}                                                                                                                    // 180
	}],                                                                                                                   // 180
	// Thèmes de points d'histoire --------------------------------------                                                 // 183
	"themesHist": [{                                                                                                      // 184
		valeur: "HIST_GUERRES",                                                                                              // 185
		intitule: {                                                                                                          // 185
			"FR": "guerres"                                                                                                     // 185
		}                                                                                                                    // 185
	}, {                                                                                                                  // 185
		valeur: "HIST_EPIDEMIES",                                                                                            // 186
		intitule: {                                                                                                          // 186
			"FR": "épidémies"                                                                                                   // 186
		}                                                                                                                    // 186
	}, {                                                                                                                  // 186
		valeur: "HIST_NATURE",                                                                                               // 187
		intitule: {                                                                                                          // 187
			"FR": "phénomènes naturels"                                                                                         // 187
		}                                                                                                                    // 187
	}, {                                                                                                                  // 187
		valeur: "HIST_ADMINISTRATIF",                                                                                        // 188
		intitule: {                                                                                                          // 188
			"FR": "administration"                                                                                              // 188
		}                                                                                                                    // 188
	}, {                                                                                                                  // 188
		valeur: "HIST_ECONOMIE",                                                                                             // 189
		intitule: {                                                                                                          // 189
			"FR": "économie, artisanat"                                                                                         // 189
		}                                                                                                                    // 189
	}, {                                                                                                                  // 189
		valeur: "HIST_INDUSTRIE",                                                                                            // 190
		intitule: {                                                                                                          // 190
			"FR": "industrie"                                                                                                   // 190
		}                                                                                                                    // 190
	}, {                                                                                                                  // 190
		valeur: "HIST_TRANSPORTS",                                                                                           // 191
		intitule: {                                                                                                          // 191
			"FR": "transports"                                                                                                  // 191
		}                                                                                                                    // 191
	}, {                                                                                                                  // 191
		valeur: "HIST_ELEVAGE",                                                                                              // 192
		intitule: {                                                                                                          // 192
			"FR": "élevage"                                                                                                     // 192
		}                                                                                                                    // 192
	}, {                                                                                                                  // 192
		valeur: "HIST_POLITIQUE",                                                                                            // 193
		intitule: {                                                                                                          // 193
			"FR": "politique"                                                                                                   // 193
		}                                                                                                                    // 193
	}, {                                                                                                                  // 193
		valeur: "HIST_CULTURE",                                                                                              // 194
		intitule: {                                                                                                          // 194
			"FR": "culture"                                                                                                     // 194
		}                                                                                                                    // 194
	}, {                                                                                                                  // 194
		valeur: "HIST_RELIGION",                                                                                             // 195
		intitule: {                                                                                                          // 195
			"FR": "religion"                                                                                                    // 195
		}                                                                                                                    // 195
	}, {                                                                                                                  // 195
		valeur: "HIST_TECHNIQUE",                                                                                            // 196
		intitule: {                                                                                                          // 196
			"FR": "découvertes, techniques"                                                                                     // 196
		}                                                                                                                    // 196
	}, {                                                                                                                  // 196
		valeur: "HIST_NOTABLES",                                                                                             // 197
		intitule: {                                                                                                          // 197
			"FR": "notables, personnes célèbres"                                                                                // 197
		}                                                                                                                    // 197
	}, {                                                                                                                  // 197
		valeur: "HIST_AUTRES",                                                                                               // 198
		intitule: {                                                                                                          // 198
			"FR": "autre thème, à classer"                                                                                      // 198
		}                                                                                                                    // 198
	}],                                                                                                                   // 198
	// Sexes ----------------------------------------------------------------                                             // 201
	"sexes": [{                                                                                                           // 202
		valeur: "M",                                                                                                         // 203
		intitule: {                                                                                                          // 203
			"FR": "homme"                                                                                                       // 203
		}                                                                                                                    // 203
	}, {                                                                                                                  // 203
		valeur: "F",                                                                                                         // 204
		intitule: {                                                                                                          // 204
			"FR": "femme"                                                                                                       // 204
		}                                                                                                                    // 204
	}, {                                                                                                                  // 204
		valeur: "NONCONNU",                                                                                                  // 205
		intitule: {                                                                                                          // 205
			"FR": "inconnu"                                                                                                     // 205
		}                                                                                                                    // 205
	}],                                                                                                                   // 205
	// TexteXml -------------------------------------------------------------                                             // 208
	"texteXmlStatus": [{                                                                                                  // 209
		valeur: "VIVANT",                                                                                                    // 210
		intitule: {                                                                                                          // 210
			"FR": "vivant(e)"                                                                                                   // 210
		}                                                                                                                    // 210
	}, {                                                                                                                  // 210
		valeur: "DECEDE",                                                                                                    // 211
		intitule: {                                                                                                          // 211
			"FR": "décédé(e)"                                                                                                   // 211
		}                                                                                                                    // 211
	}, {                                                                                                                  // 211
		valeur: "INCONNU",                                                                                                   // 212
		intitule: {                                                                                                          // 212
			"FR": "status inconnu"                                                                                              // 212
		}                                                                                                                    // 212
	}],                                                                                                                   // 212
	"texteXmlRole": [{                                                                                                    // 215
		valeur: "ENFANT",                                                                                                    // 216
		intitule: {                                                                                                          // 216
			"FR": "enfant"                                                                                                      // 216
		}                                                                                                                    // 216
	}, {                                                                                                                  // 216
		valeur: "PERE",                                                                                                      // 217
		intitule: {                                                                                                          // 217
			"FR": "père"                                                                                                        // 217
		}                                                                                                                    // 217
	}, {                                                                                                                  // 217
		valeur: "MERE",                                                                                                      // 218
		intitule: {                                                                                                          // 218
			"FR": "mère"                                                                                                        // 218
		}                                                                                                                    // 218
	}, {                                                                                                                  // 218
		valeur: "PARRAIN",                                                                                                   // 219
		intitule: {                                                                                                          // 219
			"FR": "parrain"                                                                                                     // 219
		}                                                                                                                    // 219
	}, {                                                                                                                  // 219
		valeur: "MARRAINE",                                                                                                  // 220
		intitule: {                                                                                                          // 220
			"FR": "marraine"                                                                                                    // 220
		}                                                                                                                    // 220
	}, {                                                                                                                  // 220
		valeur: "TEMOIN",                                                                                                    // 221
		intitule: {                                                                                                          // 221
			"FR": "témoin"                                                                                                      // 221
		}                                                                                                                    // 221
	}, {                                                                                                                  // 221
		valeur: "PEREMARI",                                                                                                  // 222
		intitule: {                                                                                                          // 222
			"FR": "père du marié"                                                                                               // 222
		}                                                                                                                    // 222
	}, {                                                                                                                  // 222
		valeur: "MEREMARI",                                                                                                  // 223
		intitule: {                                                                                                          // 223
			"FR": "mère du marié"                                                                                               // 223
		}                                                                                                                    // 223
	}, {                                                                                                                  // 223
		valeur: "PEREFEMME",                                                                                                 // 224
		intitule: {                                                                                                          // 224
			"FR": "père de la mariée"                                                                                           // 224
		}                                                                                                                    // 224
	}, {                                                                                                                  // 224
		valeur: "MEREFEMME",                                                                                                 // 225
		intitule: {                                                                                                          // 225
			"FR": "mère de la mariée"                                                                                           // 225
		}                                                                                                                    // 225
	}, {                                                                                                                  // 225
		valeur: "OFFICIANT",                                                                                                 // 226
		intitule: {                                                                                                          // 226
			"FR": "officiant"                                                                                                   // 226
		}                                                                                                                    // 226
	}, {                                                                                                                  // 226
		valeur: "MORT",                                                                                                      // 227
		intitule: {                                                                                                          // 227
			"FR": "mort"                                                                                                        // 227
		}                                                                                                                    // 227
	}, {                                                                                                                  // 227
		valeur: "CONJOINT",                                                                                                  // 228
		intitule: {                                                                                                          // 228
			"FR": "conjoint"                                                                                                    // 228
		}                                                                                                                    // 228
	}, {                                                                                                                  // 228
		valeur: "AUTRE",                                                                                                     // 229
		intitule: {                                                                                                          // 229
			"FR": "autre"                                                                                                       // 229
		}                                                                                                                    // 229
	}],                                                                                                                   // 229
	"texteXmlSigne": [{                                                                                                   // 232
		valeur: "BIEN",                                                                                                      // 233
		intitule: {                                                                                                          // 233
			"FR": "signe bien"                                                                                                  // 233
		}                                                                                                                    // 233
	}, {                                                                                                                  // 233
		valeur: "MAL",                                                                                                       // 234
		intitule: {                                                                                                          // 234
			"FR": "signe mal"                                                                                                   // 234
		}                                                                                                                    // 234
	}, {                                                                                                                  // 234
		valeur: "NON",                                                                                                       // 235
		intitule: {                                                                                                          // 235
			"FR": "ne sait pas signer"                                                                                          // 235
		}                                                                                                                    // 235
	}, {                                                                                                                  // 235
		valeur: "NONPRECISE",                                                                                                // 236
		intitule: {                                                                                                          // 236
			"FR": "non précisé"                                                                                                 // 236
		}                                                                                                                    // 236
	}, {                                                                                                                  // 236
		valeur: "INCERTAIN",                                                                                                 // 237
		intitule: {                                                                                                          // 237
			"FR": "incertain"                                                                                                   // 237
		}                                                                                                                    // 237
	}, {                                                                                                                  // 237
		valeur: "N/A",                                                                                                       // 238
		intitule: {                                                                                                          // 238
			"FR": "non applicable"                                                                                              // 238
		}                                                                                                                    // 238
	}],                                                                                                                   // 238
	// Criticité des bugs --------------------------------------------------                                              // 242
	// Traduction en texte et en couleurs Bootstrap                                                                       // 243
	"criticiteBugs": [{                                                                                                   // 244
		valeur: 0,                                                                                                           // 245
		intitule: {                                                                                                          // 245
			"FR": "faible"                                                                                                      // 245
		},                                                                                                                   // 245
		bootstrapClass: "text-success"                                                                                       // 245
	}, {                                                                                                                  // 245
		valeur: 1,                                                                                                           // 246
		intitule: {                                                                                                          // 246
			"FR": "moyen"                                                                                                       // 246
		},                                                                                                                   // 246
		bootstrapClass: "text-info"                                                                                          // 246
	}, {                                                                                                                  // 246
		valeur: 2,                                                                                                           // 247
		intitule: {                                                                                                          // 247
			"FR": "fort"                                                                                                        // 247
		},                                                                                                                   // 247
		bootstrapClass: "text-warning"                                                                                       // 247
	}, {                                                                                                                  // 247
		valeur: 3,                                                                                                           // 248
		intitule: {                                                                                                          // 248
			"FR": "critique"                                                                                                    // 248
		},                                                                                                                   // 248
		bootstrapClass: "text-danger"                                                                                        // 248
	}],                                                                                                                   // 248
	// Type Etat de la recherche des actes                                                                                // 251
	"typeEtatRechActes": [{                                                                                               // 252
		valeur: "INCOMPLET_A_COMPLETER",                                                                                     // 253
		intitule: {                                                                                                          // 253
			"FR": "incomplets, recherche à effectuer"                                                                           // 253
		}                                                                                                                    // 253
	}, {                                                                                                                  // 253
		valeur: "INCOMPLET_RECH_FINIE",                                                                                      // 254
		intitule: {                                                                                                          // 254
			"FR": "incomplets, mais recherche finie"                                                                            // 254
		}                                                                                                                    // 254
	}, {                                                                                                                  // 254
		valeur: "COMPLET_A_VERIFIER",                                                                                        // 255
		intitule: {                                                                                                          // 255
			"FR": "complets mais à vérifier"                                                                                    // 255
		}                                                                                                                    // 255
	}, {                                                                                                                  // 255
		valeur: "COMPLET_VERIFIE",                                                                                           // 256
		intitule: {                                                                                                          // 256
			"FR": "complets et vérifiés"                                                                                        // 256
		}                                                                                                                    // 256
	}],                                                                                                                   // 256
	// Type Etat de la recherche des actes                                                                                // 259
	"typeEtatRechEnfants": [{                                                                                             // 260
		valeur: "INCOMPLET_A_COMPLETER",                                                                                     // 261
		intitule: {                                                                                                          // 261
			"FR": "prob. incomplets, recherche à effectuer"                                                                     // 261
		}                                                                                                                    // 261
	}, {                                                                                                                  // 261
		valeur: "INCOMPLET_RECH_FINIE",                                                                                      // 262
		intitule: {                                                                                                          // 262
			"FR": "prob. incomplets, recherche finie"                                                                           // 262
		}                                                                                                                    // 262
	}, {                                                                                                                  // 262
		valeur: "COMPLET_VERIFIE",                                                                                           // 263
		intitule: {                                                                                                          // 263
			"FR": "prob. complets"                                                                                              // 263
		}                                                                                                                    // 263
	}],                                                                                                                   // 263
	// Type bugs et améliorations                                                                                         // 266
	"typeBugs": [{                                                                                                        // 268
		valeur: "BUG",                                                                                                       // 269
		intitule: {                                                                                                          // 269
			"FR": "Bug"                                                                                                         // 269
		}                                                                                                                    // 269
	}, {                                                                                                                  // 269
		valeur: "AMELIORATION",                                                                                              // 270
		intitule: {                                                                                                          // 270
			"FR": "Amélioration"                                                                                                // 270
		}                                                                                                                    // 270
	}],                                                                                                                   // 270
	// Rotation de l'arbre circulaire en fonction du sexe et de la génération                                             // 273
	"rotationArbreCirc": [90, 45, 22.5, 11.25, 5.625, 2.8125, 1.40625, 0.703125, 0.3515625, 0.17578125, 0.087890625, 0.043945313],
	// Nombre de générations maximum                                                                                      // 288
	"arbreAscNbGenerationMax": 4,                                                                                         // 289
	// Valeur par défaut                                                                                                  // 289
	"arbreAscChoixNbGenerations": [3, 4, 5, 6, 7, 8],                                                                     // 290
	// Liste de choix                                                                                                     // 290
	"arbreAscNbPixelsParGeneration": [0, 0, 0, 160, 290, 420, 550, 680, 830],                                             // 291
	// Nb de pixels selon le nb de générations                                                                            // 291
	// Couleur attribuée par commune                                                                                      // 292
	"couleurCommune": {                                                                                                   // 293
		"WHsLJAu6oyM2ZrEb9": "#FCFF79",                                                                                      // 294
		// Beauvoir sur mer                                                                                                  // 294
		"qGoTQufvMrHyirj7t": "#BBFFFF",                                                                                      // 295
		// Challans                                                                                                          // 295
		"wwuBLnfkk7pLPZ52D": "#FFD779",                                                                                      // 296
		// Notre dame de Monts                                                                                               // 296
		"BrQE7YG2Rxi8Dhf4T": "#7EFA91",                                                                                      // 297
		// Sallertaine                                                                                                       // 297
		"Y8xw3Ea68Jwv6Txdb": "#DEFCBE",                                                                                      // 298
		// Saint Gervais                                                                                                     // 298
		"cQuv6u45kZNuuBK5d": "#FDA67B",                                                                                      // 299
		// Saint Jean de Monts                                                                                               // 299
		"Swjzw7uTvSXcSn644": "#F98080",                                                                                      // 300
		// Saint Hilaire de Riez                                                                                             // 300
		"g2wDwJoEwk5teQZzt": "#C9FA7E",                                                                                      // 301
		// Saint Urbain                                                                                                      // 301
		"yRCXwQWkSbpN8qRLW": "#FF93DD",                                                                                      // 302
		// Soullans                                                                                                          // 302
		"LkFjhEhaMpNmA9Xvw": "#8FC0D1",                                                                                      // 303
		// Le Perrier                                                                                                        // 303
		"PYiZAFkeQEuqRToZo": "#E1E82C",                                                                                      // 304
		// Bouin                                                                                                             // 304
		"Aqi58qEeXxrPneeeC": "#DBA0FF",                                                                                      // 305
		// Fenouiller                                                                                                        // 305
		"PgQuQw5LomfWE5Hhu": "#BD4E76",                                                                                      // 306
		// Croix de Vie                                                                                                      // 306
		"AUTRE": "#FFFFFF",                                                                                                  // 307
		"NONCONNUE": "#B8C0C0"                                                                                               // 308
	},                                                                                                                    // 293
	// Couleurs pour l'état recherche des actes                                                                           // 311
	"couleurEtatRechActes": {                                                                                             // 312
		"INCOMPLET_A_COMPLETER": "#FF5F00",                                                                                  // 313
		"INCOMPLET_RECH_FINIE": "#0332FF",                                                                                   // 314
		"COMPLET_A_VERIFIER": "#E8CE00",                                                                                     // 315
		"COMPLET_VERIFIE": "#00FF22"                                                                                         // 316
	},                                                                                                                    // 312
	// Couleurs pour l'état recherche des enfants                                                                         // 319
	"couleurEtatRechEnfants": {                                                                                           // 320
		"INCOMPLET_A_COMPLETER": "#FF5F00",                                                                                  // 321
		"INCOMPLET_RECH_FINIE": "#0332FF",                                                                                   // 322
		"COMPLET_VERIFIE": "#00FF22"                                                                                         // 323
	},                                                                                                                    // 320
	// ==========================================	                                                                        // 325
	// Intitulés génériques pour les différentes listes ci-dessus ------                                                  // 326
	// ==========================================	                                                                        // 327
	"intitulesGeneriques": {                                                                                              // 328
		"typesLieux": {                                                                                                      // 329
			"FR": " un type quelconque de lieu"                                                                                 // 329
		},                                                                                                                   // 329
		"typesDocs": {                                                                                                       // 330
			"FR": " un type quelconque de document"                                                                             // 330
		},                                                                                                                   // 330
		"typeActe": {                                                                                                        // 331
			"FR": " un type quelconque d'acte"                                                                                  // 331
		},                                                                                                                   // 331
		"codagesDocs": {                                                                                                     // 332
			"FR": " un codage quelconque"                                                                                       // 332
		},                                                                                                                   // 332
		"genresLieux": {                                                                                                     // 333
			"FR": " un genre quelconque"                                                                                        // 333
		},                                                                                                                   // 333
		"sexes": {                                                                                                           // 334
			"FR": " un sexe quelconque"                                                                                         // 334
		}                                                                                                                    // 334
	},                                                                                                                    // 328
	// ==========================================	                                                                        // 337
	// Gestion du zoom svg                                                                                                // 338
	// ==========================================                                                                         // 339
	// Niveau de zoom autorisés en %                                                                                      // 340
	"NiveauxDeZoom": [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 120, 130, 150, 200, 250, 300, 400, 600, 800],              // 341
	// ==========================================	                                                                        // 343
	// Divers                                                                                                             // 344
	// ==========================================                                                                         // 345
	"googleMapDefaultPosition": {                                                                                         // 346
		"lat": 46.820182,                                                                                                    // 346
		"lng": -1.994046                                                                                                     // 346
	},                                                                                                                    // 346
	// Le Perrier par défaut                                                                                              // 346
	// Longuer maximum des listes des objets déjà visités                                                                 // 347
	"visitedObjectsListMaxLength": 15,                                                                                    // 348
	// ==========================================	                                                                        // 351
	// Représentation chronologique de la famille proche                                                                  // 352
	// ==========================================                                                                         // 353
	"nbPixelsParLigne": 35,                                                                                               // 354
	// En pixels (delta entre 2 lignes de vies successives)                                                               // 354
	"nbPixelsParAn": 5,                                                                                                   // 355
	// En pixels                                                                                                          // 355
	"margeGaucheSvg": 60,                                                                                                 // 356
	// En années (inscription du nom de la personne)                                                                      // 356
	"nbAnneesViewbox": 240,                                                                                               // 357
	// En années                                                                                                          // 357
	"margeDroiteSvg": 10,                                                                                                 // 358
	// En années                                                                                                          // 358
	"margeHauteSvg": 28,                                                                                                  // 359
	// En pixels par rapport au y=0                                                                                       // 359
	"margeBasseSvg": 67,                                                                                                  // 360
	// En pixels                                                                                                          // 360
	"offsetLabelNomAvantDateMin": 55,                                                                                     // 361
	// En année                                                                                                           // 361
	"offsetLabelNomParGeneration": 10,                                                                                    // 362
	// En année                                                                                                           // 362
	"offsetDebutLignesPers": 50,                                                                                          // 363
	// En pixel Y                                                                                                         // 363
	// ==========================================	                                                                        // 366
	// ==========================================                                                                         // 367
	//			 VALEURS PAR DEFAUT                                                                                              // 368
	// 		DES PREFERENCES UTILISATEUR                                                                                      // 369
	// ==========================================                                                                         // 370
	// ==========================================                                                                         // 371
	// Couleur de fond, par génération, de l'arbre descendant développable                                                // 373
	"arbreDescCouleursGenerations": ["#D9EDF7", // Bleu clair Bootstrap                                                   // 374
	"#FFFFFF", // Blanc                                                                                                   // 376
	"#FCF8E3" // Jaune clair Bootstrap                                                                                    // 377
	]                                                                                                                     // 374
};                                                                                                                     // 4
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"parms_liens.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// common/parms_liens.js                                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// ================================================                                                                    // 1
// PARAMETRAGE                                                                                                         // 2
// ================================================                                                                    // 3
parms_liens = {                                                                                                        // 4
	/*                                                                                                                    // 6
 Ce fichier décrit les liens existants dans les différents objets vers les autres objets.                              //
                                                                                                                       //
 Les "matchType" disponibles sont :                                                                                    //
 - "id" : on recherche "_id" comme valeur du champ ou comme valeur dans un champ Array,                                //
 - "containId" : on recherche "_id" comme texte contenu dans le champ,                                                 //
 - "containOldId" : on recherche l'ancien ID ("id") comme texte contenu dans le champ,                                 //
 - "lienPour" : (UNIQUEMENT pour les LIENS et UNIQUEMENT avec "prop":"pour.id") on recherche un lien pour cet objet,   //
 - "lienVers" : (UNIQUEMENT pour les LIENS et UNIQUEMENT avec "prop":"vers.id") on recherche un lien vers cet objet.   //
 */ // Liste des propriétés des objets PERS (COMPLET)                                                                  //
	"PERS": {                                                                                                             // 18
		// Pouvant pointer vers des objets PERS                                                                              // 19
		"PERS": [{                                                                                                           // 20
			"prop": "pere",                                                                                                     // 21
			"matchType": "id",                                                                                                  // 21
			"intitule": {                                                                                                       // 21
				"FR": "Personne(s) ayant pour père cette personne"                                                                 // 21
			},                                                                                                                  // 21
			"afficherInfos": false                                                                                              // 21
		}, {                                                                                                                 // 21
			"prop": "mere",                                                                                                     // 22
			"matchType": "id",                                                                                                  // 22
			"intitule": {                                                                                                       // 22
				"FR": "Personne(s) ayant pour mère cette personne"                                                                 // 22
			},                                                                                                                  // 22
			"afficherInfos": false                                                                                              // 22
		}, {                                                                                                                 // 22
			"prop": "comment",                                                                                                  // 23
			"matchType": "containId",                                                                                           // 23
			"intitule": {                                                                                                       // 23
				"FR": "Personne(s) ayant dans ses commentaires un pointeur vers cette personne"                                    // 23
			},                                                                                                                  // 23
			"afficherInfos": true                                                                                               // 23
		}, {                                                                                                                 // 23
			"prop": "comment",                                                                                                  // 24
			"matchType": "containOldId",                                                                                        // 24
			"intitule": {                                                                                                       // 24
				"FR": "Personne(s) ayant dans ses commentaires un pointeur (ancien Id) vers cette personne"                        // 24
			},                                                                                                                  // 24
			"afficherInfos": true                                                                                               // 24
		}, {                                                                                                                 // 24
			"prop": "recherche",                                                                                                // 25
			"matchType": "containId",                                                                                           // 25
			"intitule": {                                                                                                       // 25
				"FR": "Personne(s) ayant dans ses remarques de recherche un pointeur vers cette personne"                          // 25
			},                                                                                                                  // 25
			"afficherInfos": true                                                                                               // 25
		}, {                                                                                                                 // 25
			"prop": "recherche",                                                                                                // 26
			"matchType": "containOldId",                                                                                        // 26
			"intitule": {                                                                                                       // 26
				"FR": "Personne(s) ayant dans ses remarques de recherche un pointeur (ancien Id) vers cette personne"              // 26
			},                                                                                                                  // 26
			"afficherInfos": true                                                                                               // 26
		}],                                                                                                                  // 26
		// Pouvant pointer vers des objets LIEU                                                                              // 28
		"LIEU": [{                                                                                                           // 29
			"prop": "naissance.commune",                                                                                        // 30
			"matchType": "id",                                                                                                  // 30
			"intitule": {                                                                                                       // 30
				"FR": "Personne(s) ayant pour commune de naissance ce lieu"                                                        // 30
			},                                                                                                                  // 30
			"afficherInfos": true                                                                                               // 30
		}, {                                                                                                                 // 30
			"prop": "deces.commune",                                                                                            // 31
			"matchType": "id",                                                                                                  // 31
			"intitule": {                                                                                                       // 31
				"FR": "Personne(s) ayant pour commune de décès ce lieu"                                                            // 31
			},                                                                                                                  // 31
			"afficherInfos": true                                                                                               // 31
		}, {                                                                                                                 // 31
			"prop": "naissance.lieudit",                                                                                        // 32
			"matchType": "id",                                                                                                  // 32
			"intitule": {                                                                                                       // 32
				"FR": "Personne(s) ayant pour lieu-dit de naissance ce lieu"                                                       // 32
			},                                                                                                                  // 32
			"afficherInfos": true                                                                                               // 32
		}, {                                                                                                                 // 32
			"prop": "deces.lieudit",                                                                                            // 33
			"matchType": "id",                                                                                                  // 33
			"intitule": {                                                                                                       // 33
				"FR": "Personne(s) ayant pour lieu-dit de décès ce lieu"                                                           // 33
			},                                                                                                                  // 33
			"afficherInfos": true                                                                                               // 33
		}, {                                                                                                                 // 33
			"prop": "comment",                                                                                                  // 34
			"matchType": "containId",                                                                                           // 34
			"intitule": {                                                                                                       // 34
				"FR": "Personne(s) ayant dans ses commentaires un pointeur vers ce lieu"                                           // 34
			},                                                                                                                  // 34
			"afficherInfos": true                                                                                               // 34
		}, {                                                                                                                 // 34
			"prop": "comment",                                                                                                  // 35
			"matchType": "containOldId",                                                                                        // 35
			"intitule": {                                                                                                       // 35
				"FR": "Personne(s) ayant dans ses commentaires un pointeur (ancien Id) vers ce lieu"                               // 35
			},                                                                                                                  // 35
			"afficherInfos": true                                                                                               // 35
		}, {                                                                                                                 // 35
			"prop": "recherche",                                                                                                // 36
			"matchType": "containId",                                                                                           // 36
			"intitule": {                                                                                                       // 36
				"FR": "Personne(s) ayant dans ses remarques de recherche un pointeur vers ce lieu"                                 // 36
			},                                                                                                                  // 36
			"afficherInfos": true                                                                                               // 36
		}, {                                                                                                                 // 36
			"prop": "recherche",                                                                                                // 37
			"matchType": "containOldId",                                                                                        // 37
			"intitule": {                                                                                                       // 37
				"FR": "Personne(s) ayant dans ses remarques de recherche un pointeur (ancien Id) vers ce lieu"                     // 37
			},                                                                                                                  // 37
			"afficherInfos": true                                                                                               // 37
		}],                                                                                                                  // 37
		// Pouvant pointer vers des objets HIST                                                                              // 39
		"HIST": [{                                                                                                           // 40
			"prop": "comment",                                                                                                  // 41
			"matchType": "containId",                                                                                           // 41
			"intitule": {                                                                                                       // 41
				"FR": "Personne(s) ayant dans ses commentaires un pointeur vers ce point d'histoire"                               // 41
			},                                                                                                                  // 41
			"afficherInfos": true                                                                                               // 41
		}, {                                                                                                                 // 41
			"prop": "comment",                                                                                                  // 42
			"matchType": "containOldId",                                                                                        // 42
			"intitule": {                                                                                                       // 42
				"FR": "Personne(s) ayant dans ses commentaires un pointeur (ancien Id) vers ce point d'histoire"                   // 42
			},                                                                                                                  // 42
			"afficherInfos": true                                                                                               // 42
		}, {                                                                                                                 // 42
			"prop": "recherche",                                                                                                // 43
			"matchType": "containId",                                                                                           // 43
			"intitule": {                                                                                                       // 43
				"FR": "Personne(s) ayant dans ses remarques de recherche un pointeur vers ce point d'histoire"                     // 43
			},                                                                                                                  // 43
			"afficherInfos": true                                                                                               // 43
		}, {                                                                                                                 // 43
			"prop": "recherche",                                                                                                // 44
			"matchType": "containOldId",                                                                                        // 44
			"intitule": {                                                                                                       // 44
				"FR": "Personne(s) ayant dans ses remarques de recherche un pointeur (ancien Id) vers ce point d'histoire"         // 44
			},                                                                                                                  // 44
			"afficherInfos": true                                                                                               // 44
		}],                                                                                                                  // 44
		// Pouvant pointer vers des objets DOC                                                                               // 46
		"DOC": [{                                                                                                            // 47
			"prop": "photo.docId",                                                                                              // 48
			"matchType": "id",                                                                                                  // 48
			"intitule": {                                                                                                       // 48
				"FR": "Personne(s) ayant pour photo ce document"                                                                   // 48
			},                                                                                                                  // 48
			"afficherInfos": true                                                                                               // 48
		}, {                                                                                                                 // 48
			"prop": "naissance.docs",                                                                                           // 49
			"matchType": "id",                                                                                                  // 49
			"intitule": {                                                                                                       // 49
				"FR": "Personne(s) ayant pour acte de naissance ce document"                                                       // 49
			},                                                                                                                  // 49
			"afficherInfos": true                                                                                               // 49
		}, {                                                                                                                 // 49
			"prop": "deces.docs",                                                                                               // 50
			"matchType": "id",                                                                                                  // 50
			"intitule": {                                                                                                       // 50
				"FR": "Personne(s) ayant pour acte de décès ce document"                                                           // 50
			},                                                                                                                  // 50
			"afficherInfos": true                                                                                               // 50
		}, {                                                                                                                 // 50
			"prop": "comment",                                                                                                  // 51
			"matchType": "containId",                                                                                           // 51
			"intitule": {                                                                                                       // 51
				"FR": "Personne(s) ayant dans ses commentaires un pointeur vers ce document"                                       // 51
			},                                                                                                                  // 51
			"afficherInfos": true                                                                                               // 51
		}, {                                                                                                                 // 51
			"prop": "comment",                                                                                                  // 52
			"matchType": "containOldId",                                                                                        // 52
			"intitule": {                                                                                                       // 52
				"FR": "Personne(s) ayant dans ses commentaires un pointeur (ancien Id) vers ce document"                           // 52
			},                                                                                                                  // 52
			"afficherInfos": true                                                                                               // 52
		}, {                                                                                                                 // 52
			"prop": "recherche",                                                                                                // 53
			"matchType": "containId",                                                                                           // 53
			"intitule": {                                                                                                       // 53
				"FR": "Personne(s) ayant dans ses remarques de recherche un pointeur vers ce document"                             // 53
			},                                                                                                                  // 53
			"afficherInfos": true                                                                                               // 53
		}, {                                                                                                                 // 53
			"prop": "recherche",                                                                                                // 54
			"matchType": "containOldId",                                                                                        // 54
			"intitule": {                                                                                                       // 54
				"FR": "Personne(s) ayant dans ses remarques de recherche un pointeur (ancien Id) vers ce document"                 // 54
			},                                                                                                                  // 54
			"afficherInfos": true                                                                                               // 54
		}],                                                                                                                  // 54
		// Pouvant pointer vers des objets TAG                                                                               // 56
		"TAG": [{                                                                                                            // 57
			"prop": "tags",                                                                                                     // 58
			"matchType": "id",                                                                                                  // 58
			"intitule": {                                                                                                       // 58
				"FR": "Personne(s) ayant cette étiquette"                                                                          // 58
			},                                                                                                                  // 58
			"afficherInfos": false                                                                                              // 58
		}]                                                                                                                   // 58
	},                                                                                                                    // 18
	// Liste des propriétés des objets COUPLE_EVENT (COMPLET)                                                             // 61
	"COUPLE_EVENT": {                                                                                                     // 62
		// Pouvant pointer vers des objets PERS                                                                              // 63
		"PERS": [{                                                                                                           // 64
			"prop": "persA",                                                                                                    // 65
			"matchType": "id",                                                                                                  // 65
			"intitule": {                                                                                                       // 65
				"FR": "Evènement(s) conjugal(aux) lié(s) à cette personne"                                                         // 65
			},                                                                                                                  // 65
			"afficherInfos": false                                                                                              // 65
		}, {                                                                                                                 // 65
			"prop": "persB",                                                                                                    // 66
			"matchType": "id",                                                                                                  // 66
			"intitule": {                                                                                                       // 66
				"FR": "Evènement(s) conjugal(aux) lié(s) à cette personne"                                                         // 66
			},                                                                                                                  // 66
			"afficherInfos": false                                                                                              // 66
		}],                                                                                                                  // 66
		// Pouvant pointer vers des objets LIEU                                                                              // 68
		"LIEU": [{                                                                                                           // 69
			"prop": "communeA",                                                                                                 // 70
			"matchType": "id",                                                                                                  // 70
			"intitule": {                                                                                                       // 70
				"FR": "Evènement(s) conjugal(aux) ayant ce lieu pour commune d'habitation d'au moins un des conjoints"             // 70
			},                                                                                                                  // 70
			"afficherInfos": true                                                                                               // 70
		}, {                                                                                                                 // 70
			"prop": "communeB",                                                                                                 // 71
			"matchType": "id",                                                                                                  // 71
			"intitule": {                                                                                                       // 71
				"FR": "Evènement(s) conjugal(aux) ayant ce lieu pour commune d'habitation d'au moins un des conjoints"             // 71
			},                                                                                                                  // 71
			"afficherInfos": true                                                                                               // 71
		}, {                                                                                                                 // 71
			"prop": "lieuditA",                                                                                                 // 72
			"matchType": "id",                                                                                                  // 72
			"intitule": {                                                                                                       // 72
				"FR": "Evènement(s) conjugal(aux) ayant ce lieu pour lieu-dit d'habitation d'au moins un des conjoints"            // 72
			},                                                                                                                  // 72
			"afficherInfos": true                                                                                               // 72
		}, {                                                                                                                 // 72
			"prop": "lieuditB",                                                                                                 // 73
			"matchType": "id",                                                                                                  // 73
			"intitule": {                                                                                                       // 73
				"FR": "Evènement(s) conjugal(aux) ayant ce lieu pour lieu-dit d'habitation d'au moins un des conjoints"            // 73
			},                                                                                                                  // 73
			"afficherInfos": true                                                                                               // 73
		}],                                                                                                                  // 73
		// Pouvant pointer vers des objets HIST                                                                              // 75
		"HIST": [],                                                                                                          // 76
		// Pouvant pointer vers des objets DOC                                                                               // 78
		"DOC": [{                                                                                                            // 79
			"prop": "docs",                                                                                                     // 80
			"matchType": "id",                                                                                                  // 80
			"intitule": {                                                                                                       // 80
				"FR": "Evènement(s) conjugal(aux) lié(s) à ce ce document"                                                         // 80
			},                                                                                                                  // 80
			"afficherInfos": true                                                                                               // 80
		}]                                                                                                                   // 80
	},                                                                                                                    // 62
	// Liste des propriétés des objets LIEU (Gestion des familles toponymiques à rajouter)                                // 83
	"LIEU": {                                                                                                             // 84
		// Pouvant pointer vers des objets PERS                                                                              // 85
		"PERS": [{                                                                                                           // 86
			"prop": "comment",                                                                                                  // 87
			"matchType": "containId",                                                                                           // 87
			"intitule": {                                                                                                       // 87
				"FR": "Lieu(x) ayant dans ses commentaires un pointeur vers cette personne"                                        // 87
			},                                                                                                                  // 87
			"afficherInfos": true                                                                                               // 87
		}, {                                                                                                                 // 87
			"prop": "comment",                                                                                                  // 88
			"matchType": "containOldId",                                                                                        // 88
			"intitule": {                                                                                                       // 88
				"FR": "Lieu(x) ayant dans ses commentaires un pointeur (ancien Id) vers cette personne"                            // 88
			},                                                                                                                  // 88
			"afficherInfos": true                                                                                               // 88
		}, {                                                                                                                 // 88
			"prop": "recherche",                                                                                                // 89
			"matchType": "containId",                                                                                           // 89
			"intitule": {                                                                                                       // 89
				"FR": "Lieu(x) ayant dans ses remarques de recherche un pointeur vers cette personne"                              // 89
			},                                                                                                                  // 89
			"afficherInfos": true                                                                                               // 89
		}, {                                                                                                                 // 89
			"prop": "recherche",                                                                                                // 90
			"matchType": "containOldId",                                                                                        // 90
			"intitule": {                                                                                                       // 90
				"FR": "Lieu(x) ayant dans ses remarques de recherche un pointeur (ancien Id) vers cette personne"                  // 90
			},                                                                                                                  // 90
			"afficherInfos": true                                                                                               // 90
		}, {                                                                                                                 // 90
			"prop": "topoComment",                                                                                              // 91
			"matchType": "containId",                                                                                           // 91
			"intitule": {                                                                                                       // 91
				"FR": "Lieu(x) ayant dans ses commentaires de toponymie un pointeur vers cette personne"                           // 91
			},                                                                                                                  // 91
			"afficherInfos": true                                                                                               // 91
		}, {                                                                                                                 // 91
			"prop": "topoComment",                                                                                              // 92
			"matchType": "containOldId",                                                                                        // 92
			"intitule": {                                                                                                       // 92
				"FR": "Lieu(x) ayant dans ses commentaires de toponymie un pointeur (ancien Id) vers cette personne"               // 92
			},                                                                                                                  // 92
			"afficherInfos": true                                                                                               // 92
		}],                                                                                                                  // 92
		// Pouvant pointer vers des objets LIEU                                                                              // 94
		"LIEU": [{                                                                                                           // 95
			"prop": "inclusDans",                                                                                               // 96
			"matchType": "id",                                                                                                  // 96
			"intitule": {                                                                                                       // 96
				"FR": "Lieu(x) inclus dans ce lieu"                                                                                // 96
			},                                                                                                                  // 96
			"afficherInfos": false                                                                                              // 96
		}, {                                                                                                                 // 96
			"prop": "comment",                                                                                                  // 97
			"matchType": "containId",                                                                                           // 97
			"intitule": {                                                                                                       // 97
				"FR": "Lieu(x) ayant dans ses commentaires un pointeur vers ce lieu"                                               // 97
			},                                                                                                                  // 97
			"afficherInfos": true                                                                                               // 97
		}, {                                                                                                                 // 97
			"prop": "comment",                                                                                                  // 98
			"matchType": "containOldId",                                                                                        // 98
			"intitule": {                                                                                                       // 98
				"FR": "Lieu(x) ayant dans ses commentaires un pointeur (ancien Id) vers ce lieu"                                   // 98
			},                                                                                                                  // 98
			"afficherInfos": true                                                                                               // 98
		}, {                                                                                                                 // 98
			"prop": "recherche",                                                                                                // 99
			"matchType": "containId",                                                                                           // 99
			"intitule": {                                                                                                       // 99
				"FR": "Lieu(x) ayant dans ses remarques de recherche un pointeur vers ce lieu"                                     // 99
			},                                                                                                                  // 99
			"afficherInfos": true                                                                                               // 99
		}, {                                                                                                                 // 99
			"prop": "recherche",                                                                                                // 100
			"matchType": "containOldId",                                                                                        // 100
			"intitule": {                                                                                                       // 100
				"FR": "Lieu(x) ayant dans ses remarques de recherche un pointeur (ancien Id) vers ce lieu"                         // 100
			}                                                                                                                   // 100
		}, {                                                                                                                 // 100
			"prop": "topoComment",                                                                                              // 101
			"matchType": "containId",                                                                                           // 101
			"intitule": {                                                                                                       // 101
				"FR": "Lieu(x) ayant dans ses commentaires de toponymie un pointeur vers ce lieu"                                  // 101
			},                                                                                                                  // 101
			"afficherInfos": true                                                                                               // 101
		}, {                                                                                                                 // 101
			"prop": "topoComment",                                                                                              // 102
			"matchType": "containOldId",                                                                                        // 102
			"intitule": {                                                                                                       // 102
				"FR": "Lieu(x) ayant dans ses commentaires de toponymie un pointeur (ancien Id) vers ce lieu"                      // 102
			},                                                                                                                  // 102
			"afficherInfos": true                                                                                               // 102
		}],                                                                                                                  // 102
		// Pouvant pointer vers des objets HIST                                                                              // 104
		"HIST": [{                                                                                                           // 105
			"prop": "comment",                                                                                                  // 106
			"matchType": "containId",                                                                                           // 106
			"intitule": {                                                                                                       // 106
				"FR": "Lieu(x) ayant dans ses commentaires un pointeur vers ce point d'histoire"                                   // 106
			},                                                                                                                  // 106
			"afficherInfos": true                                                                                               // 106
		}, {                                                                                                                 // 106
			"prop": "comment",                                                                                                  // 107
			"matchType": "containOldId",                                                                                        // 107
			"intitule": {                                                                                                       // 107
				"FR": "Lieu(x) ayant dans ses commentaires un pointeur (ancien Id) vers ce point d'histoire"                       // 107
			},                                                                                                                  // 107
			"afficherInfos": true                                                                                               // 107
		}, {                                                                                                                 // 107
			"prop": "recherche",                                                                                                // 108
			"matchType": "containId",                                                                                           // 108
			"intitule": {                                                                                                       // 108
				"FR": "Lieu(x) ayant dans ses remarques de recherche un pointeur vers ce point d'histoire"                         // 108
			},                                                                                                                  // 108
			"afficherInfos": true                                                                                               // 108
		}, {                                                                                                                 // 108
			"prop": "recherche",                                                                                                // 109
			"matchType": "containOldId",                                                                                        // 109
			"intitule": {                                                                                                       // 109
				"FR": "Lieu(x) ayant dans ses remarques de recherche un pointeur (ancien Id) vers ce point d'histoire"             // 109
			},                                                                                                                  // 109
			"afficherInfos": true                                                                                               // 109
		}, {                                                                                                                 // 109
			"prop": "topoComment",                                                                                              // 110
			"matchType": "containId",                                                                                           // 110
			"intitule": {                                                                                                       // 110
				"FR": "Lieu(x) ayant dans ses commentaires de toponymie un pointeur vers ce point d'histoire"                      // 110
			},                                                                                                                  // 110
			"afficherInfos": true                                                                                               // 110
		}, {                                                                                                                 // 110
			"prop": "topoComment",                                                                                              // 111
			"matchType": "containOldId",                                                                                        // 111
			"intitule": {                                                                                                       // 111
				"FR": "Lieu(x) ayant dans ses commentaires de toponymie un pointeur (ancien Id) vers ce point d'histoire"          // 111
			},                                                                                                                  // 111
			"afficherInfos": true                                                                                               // 111
		}],                                                                                                                  // 111
		// Pouvant pointer vers des objets DOC                                                                               // 113
		"DOC": [{                                                                                                            // 114
			"prop": "comment",                                                                                                  // 115
			"matchType": "containId",                                                                                           // 115
			"intitule": {                                                                                                       // 115
				"FR": "Lieu(x) ayant dans ses commentaires un pointeur vers ce document"                                           // 115
			},                                                                                                                  // 115
			"afficherInfos": true                                                                                               // 115
		}, {                                                                                                                 // 115
			"prop": "comment",                                                                                                  // 116
			"matchType": "containOldId",                                                                                        // 116
			"intitule": {                                                                                                       // 116
				"FR": "Lieu(x) ayant dans ses commentaires un pointeur (ancien Id) vers ce document"                               // 116
			},                                                                                                                  // 116
			"afficherInfos": true                                                                                               // 116
		}, {                                                                                                                 // 116
			"prop": "recherche",                                                                                                // 117
			"matchType": "containId",                                                                                           // 117
			"intitule": {                                                                                                       // 117
				"FR": "Lieu(x) ayant dans ses remarques de recherche un pointeur vers ce document"                                 // 117
			},                                                                                                                  // 117
			"afficherInfos": true                                                                                               // 117
		}, {                                                                                                                 // 117
			"prop": "recherche",                                                                                                // 118
			"matchType": "containOldId",                                                                                        // 118
			"intitule": {                                                                                                       // 118
				"FR": "Lieu(x) ayant dans ses remarques de recherche un pointeur (ancien Id) vers ce document"                     // 118
			},                                                                                                                  // 118
			"afficherInfos": true                                                                                               // 118
		}, {                                                                                                                 // 118
			"prop": "topoComment",                                                                                              // 119
			"matchType": "containId",                                                                                           // 119
			"intitule": {                                                                                                       // 119
				"FR": "Lieu(x) ayant dans ses commentaires de toponymie un pointeur vers ce document"                              // 119
			},                                                                                                                  // 119
			"afficherInfos": true                                                                                               // 119
		}, {                                                                                                                 // 119
			"prop": "topoComment",                                                                                              // 120
			"matchType": "containOldId",                                                                                        // 120
			"intitule": {                                                                                                       // 120
				"FR": "Lieu(x) ayant dans ses commentaires de toponymie un pointeur (ancien Id) vers ce document"                  // 120
			},                                                                                                                  // 120
			"afficherInfos": true                                                                                               // 120
		}, {                                                                                                                 // 120
			"prop": "positionSurCartes.id",                                                                                     // 121
			"matchType": "id",                                                                                                  // 121
			"intitule": {                                                                                                       // 121
				"FR": "Lieu(x) visible sur cette carte"                                                                            // 121
			},                                                                                                                  // 121
			"afficherInfos": true                                                                                               // 121
		}],                                                                                                                  // 121
		// Pouvant pointer vers des objets TAG                                                                               // 123
		"TAG": [{                                                                                                            // 124
			"prop": "tags",                                                                                                     // 125
			"matchType": "id",                                                                                                  // 125
			"intitule": {                                                                                                       // 125
				"FR": "Lieu(x) ayant cette étiquette"                                                                              // 125
			},                                                                                                                  // 125
			"afficherInfos": false                                                                                              // 125
		}]                                                                                                                   // 125
	},                                                                                                                    // 84
	// Liste des propriétés des objets HIST (Supprimer les liens PERS, LIEU, HIST, DOC après transformation en liens)     // 128
	"HIST": {                                                                                                             // 129
		// Pouvant pointer vers des objets PERS                                                                              // 130
		"PERS": [{                                                                                                           // 131
			"prop": "comment",                                                                                                  // 132
			"matchType": "containId",                                                                                           // 132
			"intitule": {                                                                                                       // 132
				"FR": "Point(s) d'histoire ayant dans ses commentaires un pointeur vers cette personne"                            // 132
			},                                                                                                                  // 132
			"afficherInfos": true                                                                                               // 132
		}, {                                                                                                                 // 132
			"prop": "comment",                                                                                                  // 133
			"matchType": "containOldId",                                                                                        // 133
			"intitule": {                                                                                                       // 133
				"FR": "Point(s) d'histoire ayant dans ses commentaires un pointeur (ancien Id) vers cette personne"                // 133
			},                                                                                                                  // 133
			"afficherInfos": true                                                                                               // 133
		}, {                                                                                                                 // 133
			"prop": "recherche",                                                                                                // 134
			"matchType": "containId",                                                                                           // 134
			"intitule": {                                                                                                       // 134
				"FR": "Point(s) d'histoire ayant dans ses remarques de recherche un pointeur vers cette personne"                  // 134
			},                                                                                                                  // 134
			"afficherInfos": true                                                                                               // 134
		}, {                                                                                                                 // 134
			"prop": "recherche",                                                                                                // 135
			"matchType": "containOldId",                                                                                        // 135
			"intitule": {                                                                                                       // 135
				"FR": "Point(s) d'histoire ayant dans ses remarques de recherche un pointeur (ancien Id) vers cette personne"      // 135
			},                                                                                                                  // 135
			"afficherInfos": true                                                                                               // 135
		}],                                                                                                                  // 135
		// Pouvant pointer vers des objets LIEU                                                                              // 137
		"LIEU": [{                                                                                                           // 138
			"prop": "comment",                                                                                                  // 139
			"matchType": "containId",                                                                                           // 139
			"intitule": {                                                                                                       // 139
				"FR": "Point(s) d'histoire ayant dans ses commentaires un pointeur vers ce lieu"                                   // 139
			},                                                                                                                  // 139
			"afficherInfos": true                                                                                               // 139
		}, {                                                                                                                 // 139
			"prop": "comment",                                                                                                  // 140
			"matchType": "containOldId",                                                                                        // 140
			"intitule": {                                                                                                       // 140
				"FR": "Point(s) d'histoire ayant dans ses commentaires un pointeur (ancien Id) vers ce lieu"                       // 140
			},                                                                                                                  // 140
			"afficherInfos": true                                                                                               // 140
		}, {                                                                                                                 // 140
			"prop": "recherche",                                                                                                // 141
			"matchType": "containId",                                                                                           // 141
			"intitule": {                                                                                                       // 141
				"FR": "Point(s) d'histoire ayant dans ses remarques de recherche un pointeur vers ce lieu"                         // 141
			},                                                                                                                  // 141
			"afficherInfos": true                                                                                               // 141
		}, {                                                                                                                 // 141
			"prop": "recherche",                                                                                                // 142
			"matchType": "containOldId",                                                                                        // 142
			"intitule": {                                                                                                       // 142
				"FR": "Point(s) d'histoire ayant dans ses remarques de recherche un pointeur (ancien Id) vers ce lieu"             // 142
			},                                                                                                                  // 142
			"afficherInfos": true                                                                                               // 142
		}],                                                                                                                  // 142
		// Pouvant pointer vers des objets HIST                                                                              // 144
		"HIST": [{                                                                                                           // 145
			"prop": "comment",                                                                                                  // 146
			"matchType": "containId",                                                                                           // 146
			"intitule": {                                                                                                       // 146
				"FR": "Point(s) d'histoire ayant dans ses commentaires un pointeur vers ce point d'histoire"                       // 146
			},                                                                                                                  // 146
			"afficherInfos": true                                                                                               // 146
		}, {                                                                                                                 // 146
			"prop": "comment",                                                                                                  // 147
			"matchType": "containOldId",                                                                                        // 147
			"intitule": {                                                                                                       // 147
				"FR": "Point(s) d'histoire ayant dans ses commentaires un pointeur (ancien Id) vers ce point d'histoire"           // 147
			},                                                                                                                  // 147
			"afficherInfos": true                                                                                               // 147
		}, {                                                                                                                 // 147
			"prop": "recherche",                                                                                                // 148
			"matchType": "containId",                                                                                           // 148
			"intitule": {                                                                                                       // 148
				"FR": "Point(s) d'histoire ayant dans ses remarques de recherche un pointeur vers ce point d'histoire"             // 148
			},                                                                                                                  // 148
			"afficherInfos": true                                                                                               // 148
		}, {                                                                                                                 // 148
			"prop": "recherche",                                                                                                // 149
			"matchType": "containOldId",                                                                                        // 149
			"intitule": {                                                                                                       // 149
				"FR": "Point(s) d'histoire ayant dans ses remarques de recherche un pointeur (ancien Id) vers ce point d'histoire"
			},                                                                                                                  // 149
			"afficherInfos": true                                                                                               // 149
		}],                                                                                                                  // 149
		// Pouvant pointer vers des objets DOC                                                                               // 151
		"DOC": [{                                                                                                            // 152
			"prop": "comment",                                                                                                  // 153
			"matchType": "containId",                                                                                           // 153
			"intitule": {                                                                                                       // 153
				"FR": "Point(s) d'histoire ayant dans ses commentaires un pointeur vers ce document"                               // 153
			},                                                                                                                  // 153
			"afficherInfos": true                                                                                               // 153
		}, {                                                                                                                 // 153
			"prop": "comment",                                                                                                  // 154
			"matchType": "containOldId",                                                                                        // 154
			"intitule": {                                                                                                       // 154
				"FR": "Point(s) d'histoire ayant dans ses commentaires un pointeur (ancien Id) vers ce document"                   // 154
			},                                                                                                                  // 154
			"afficherInfos": true                                                                                               // 154
		}, {                                                                                                                 // 154
			"prop": "recherche",                                                                                                // 155
			"matchType": "containId",                                                                                           // 155
			"intitule": {                                                                                                       // 155
				"FR": "Point(s) d'histoire ayant dans ses remarques de recherche un pointeur vers ce document"                     // 155
			},                                                                                                                  // 155
			"afficherInfos": true                                                                                               // 155
		}, {                                                                                                                 // 155
			"prop": "recherche",                                                                                                // 156
			"matchType": "containOldId",                                                                                        // 156
			"intitule": {                                                                                                       // 156
				"FR": "Point(s) d'histoire ayant dans ses remarques de recherche un pointeur (ancien Id) vers ce document"         // 156
			},                                                                                                                  // 156
			"afficherInfos": true                                                                                               // 156
		}],                                                                                                                  // 156
		// Pouvant pointer vers des objets TAG                                                                               // 158
		"TAG": [{                                                                                                            // 159
			"prop": "tags",                                                                                                     // 160
			"matchType": "id",                                                                                                  // 160
			"intitule": {                                                                                                       // 160
				"FR": "Point(s) d'histoire ayant cette étiquette"                                                                  // 160
			},                                                                                                                  // 160
			"afficherInfos": false                                                                                              // 160
		}]                                                                                                                   // 160
	},                                                                                                                    // 129
	// Liste des propriétés des objets DOC (COMPLET°)                                                                     // 163
	"DOC": {                                                                                                              // 164
		// Pouvant pointer vers des objets PERS                                                                              // 165
		"PERS": [{                                                                                                           // 166
			"prop": "comment",                                                                                                  // 167
			"matchType": "containId",                                                                                           // 167
			"intitule": {                                                                                                       // 167
				"FR": "Document(s) ayant dans ses commentaires un pointeur vers cette personne"                                    // 167
			},                                                                                                                  // 167
			"afficherInfos": true                                                                                               // 167
		}, {                                                                                                                 // 167
			"prop": "comment",                                                                                                  // 168
			"matchType": "containOldId",                                                                                        // 168
			"intitule": {                                                                                                       // 168
				"FR": "Document(s) ayant dans ses commentaires un pointeur (ancien Id) vers cette personne"                        // 168
			},                                                                                                                  // 168
			"afficherInfos": true                                                                                               // 168
		}, {                                                                                                                 // 168
			"prop": "recherche",                                                                                                // 169
			"matchType": "containId",                                                                                           // 169
			"intitule": {                                                                                                       // 169
				"FR": "Document(s) ayant dans ses remarques de recherche un pointeur vers cette personne"                          // 169
			},                                                                                                                  // 169
			"afficherInfos": true                                                                                               // 169
		}, {                                                                                                                 // 169
			"prop": "recherche",                                                                                                // 170
			"matchType": "containOldId",                                                                                        // 170
			"intitule": {                                                                                                       // 170
				"FR": "Document(s) ayant dans ses remarques de recherche un pointeur (ancien Id) vers cette personne"              // 170
			},                                                                                                                  // 170
			"afficherInfos": true                                                                                               // 170
		}, {                                                                                                                 // 170
			"prop": "specif.ACTE_transcription",                                                                                // 171
			"matchType": "containId",                                                                                           // 171
			"intitule": {                                                                                                       // 171
				"FR": "Document(s) acte ayant dans sa transcription un pointeur vers cette personne"                               // 171
			},                                                                                                                  // 171
			"afficherInfos": true                                                                                               // 171
		}, {                                                                                                                 // 171
			"prop": "specif.ACTE_transcription",                                                                                // 172
			"matchType": "containOldId",                                                                                        // 172
			"intitule": {                                                                                                       // 172
				"FR": "Document(s) acte ayant dans sa transcription un pointeur (ancien Id) vers cette personne"                   // 172
			},                                                                                                                  // 172
			"afficherInfos": true                                                                                               // 172
		}],                                                                                                                  // 172
		// Pouvant pointer vers des objets LIEU                                                                              // 174
		"LIEU": [{                                                                                                           // 175
			"prop": "specif.ACTE_commune",                                                                                      // 176
			"matchType": "id",                                                                                                  // 176
			"intitule": {                                                                                                       // 176
				"FR": "Document(s) acte ayant pour commune ce lieu"                                                                // 176
			},                                                                                                                  // 176
			"afficherInfos": true                                                                                               // 176
		}, {                                                                                                                 // 176
			"prop": "comment",                                                                                                  // 177
			"matchType": "containId",                                                                                           // 177
			"intitule": {                                                                                                       // 177
				"FR": "Document(s) ayant dans ses commentaires un pointeur vers ce lieu"                                           // 177
			},                                                                                                                  // 177
			"afficherInfos": true                                                                                               // 177
		}, {                                                                                                                 // 177
			"prop": "comment",                                                                                                  // 178
			"matchType": "containOldId",                                                                                        // 178
			"intitule": {                                                                                                       // 178
				"FR": "Document(s) ayant dans ses commentaires un pointeur (ancien Id) vers ce lieu"                               // 178
			},                                                                                                                  // 178
			"afficherInfos": true                                                                                               // 178
		}, {                                                                                                                 // 178
			"prop": "recherche",                                                                                                // 179
			"matchType": "containId",                                                                                           // 179
			"intitule": {                                                                                                       // 179
				"FR": "Document(s) ayant dans ses remarques de recherche un pointeur vers ce lieu"                                 // 179
			},                                                                                                                  // 179
			"afficherInfos": true                                                                                               // 179
		}, {                                                                                                                 // 179
			"prop": "recherche",                                                                                                // 180
			"matchType": "containOldId",                                                                                        // 180
			"intitule": {                                                                                                       // 180
				"FR": "Document(s) ayant dans ses remarques de recherche un pointeur (ancien Id) vers ce lieu"                     // 180
			},                                                                                                                  // 180
			"afficherInfos": true                                                                                               // 180
		}, {                                                                                                                 // 180
			"prop": "specif.ACTE_transcription",                                                                                // 181
			"matchType": "containId",                                                                                           // 181
			"intitule": {                                                                                                       // 181
				"FR": "Document(s) acte ayant dans sa transcription un pointeur vers ce lieu"                                      // 181
			},                                                                                                                  // 181
			"afficherInfos": true                                                                                               // 181
		}, {                                                                                                                 // 181
			"prop": "specif.ACTE_transcription",                                                                                // 182
			"matchType": "containOldId",                                                                                        // 182
			"intitule": {                                                                                                       // 182
				"FR": "Document(s) acte ayant dans sa transcription un pointeur (ancien Id) vers ce lieu"                          // 182
			},                                                                                                                  // 182
			"afficherInfos": true                                                                                               // 182
		}],                                                                                                                  // 182
		// Pouvant pointer vers des objets HIST                                                                              // 184
		"HIST": [{                                                                                                           // 185
			"prop": "comment",                                                                                                  // 186
			"matchType": "containId",                                                                                           // 186
			"intitule": {                                                                                                       // 186
				"FR": "Document(s) ayant dans ses commentaires un pointeur vers ce point d'histoire"                               // 186
			},                                                                                                                  // 186
			"afficherInfos": true                                                                                               // 186
		}, {                                                                                                                 // 186
			"prop": "comment",                                                                                                  // 187
			"matchType": "containOldId",                                                                                        // 187
			"intitule": {                                                                                                       // 187
				"FR": "Document(s) ayant dans ses commentaires un pointeur (ancien Id) vers ce point d'histoire"                   // 187
			},                                                                                                                  // 187
			"afficherInfos": true                                                                                               // 187
		}, {                                                                                                                 // 187
			"prop": "recherche",                                                                                                // 188
			"matchType": "containId",                                                                                           // 188
			"intitule": {                                                                                                       // 188
				"FR": "Document(s) ayant dans ses remarques de recherche un pointeur vers ce point d'histoire"                     // 188
			},                                                                                                                  // 188
			"afficherInfos": true                                                                                               // 188
		}, {                                                                                                                 // 188
			"prop": "recherche",                                                                                                // 189
			"matchType": "containOldId",                                                                                        // 189
			"intitule": {                                                                                                       // 189
				"FR": "Document(s) ayant dans ses remarques de recherche un pointeur (ancien Id) vers ce point d'histoire"         // 189
			},                                                                                                                  // 189
			"afficherInfos": true                                                                                               // 189
		}, {                                                                                                                 // 189
			"prop": "specif.ACTE_transcription",                                                                                // 190
			"matchType": "containId",                                                                                           // 190
			"intitule": {                                                                                                       // 190
				"FR": "Document(s) acte ayant dans sa transcription un pointeur vers ce point d'histoire"                          // 190
			},                                                                                                                  // 190
			"afficherInfos": true                                                                                               // 190
		}, {                                                                                                                 // 190
			"prop": "specif.ACTE_transcription",                                                                                // 191
			"matchType": "containOldId",                                                                                        // 191
			"intitule": {                                                                                                       // 191
				"FR": "Document(s) acte ayant dans sa transcription un pointeur (ancien Id) vers ce point d'histoire"              // 191
			},                                                                                                                  // 191
			"afficherInfos": true                                                                                               // 191
		}],                                                                                                                  // 191
		// Pouvant pointer vers des objets DOC                                                                               // 193
		"DOC": [{                                                                                                            // 194
			"prop": "comment",                                                                                                  // 195
			"matchType": "containId",                                                                                           // 195
			"intitule": {                                                                                                       // 195
				"FR": "Document(s) ayant dans ses commentaires un pointeur vers ce document"                                       // 195
			},                                                                                                                  // 195
			"afficherInfos": true                                                                                               // 195
		}, {                                                                                                                 // 195
			"prop": "comment",                                                                                                  // 196
			"matchType": "containOldId",                                                                                        // 196
			"intitule": {                                                                                                       // 196
				"FR": "Document(s) ayant dans ses commentaires un pointeur (ancien Id) vers ce document"                           // 196
			},                                                                                                                  // 196
			"afficherInfos": true                                                                                               // 196
		}, {                                                                                                                 // 196
			"prop": "recherche",                                                                                                // 197
			"matchType": "containId",                                                                                           // 197
			"intitule": {                                                                                                       // 197
				"FR": "Document(s) ayant dans ses remarques de recherche un pointeur vers ce document"                             // 197
			},                                                                                                                  // 197
			"afficherInfos": true                                                                                               // 197
		}, {                                                                                                                 // 197
			"prop": "recherche",                                                                                                // 198
			"matchType": "containOldId",                                                                                        // 198
			"intitule": {                                                                                                       // 198
				"FR": "Document(s) ayant dans ses remarques de recherche un pointeur (ancien Id) vers ce document"                 // 198
			},                                                                                                                  // 198
			"afficherInfos": true                                                                                               // 198
		}, {                                                                                                                 // 198
			"prop": "specif.ACTE_transcription",                                                                                // 199
			"matchType": "containId",                                                                                           // 199
			"intitule": {                                                                                                       // 199
				"FR": "Document(s) acte ayant dans sa transcription un pointeur vers ce document"                                  // 199
			},                                                                                                                  // 199
			"afficherInfos": true                                                                                               // 199
		}, {                                                                                                                 // 199
			"prop": "specif.ACTE_transcription",                                                                                // 200
			"matchType": "containOldId",                                                                                        // 200
			"intitule": {                                                                                                       // 200
				"FR": "Document(s) acte ayant dans sa transcription un pointeur (ancien Id) vers ce document"                      // 200
			},                                                                                                                  // 200
			"afficherInfos": true                                                                                               // 200
		}],                                                                                                                  // 200
		// Pouvant pointer vers des objets REGISTRE                                                                          // 202
		"REGISTRE": [{                                                                                                       // 203
			"prop": "specif.ACTE_registre",                                                                                     // 204
			"matchType": "id",                                                                                                  // 204
			"intitule": {                                                                                                       // 204
				"FR": "Document(s) acte ayant pour registre ce registre"                                                           // 204
			},                                                                                                                  // 204
			"afficherInfos": true                                                                                               // 204
		}],                                                                                                                  // 204
		// Pouvant pointer vers des objets TAG                                                                               // 206
		"TAG": [{                                                                                                            // 207
			"prop": "tags",                                                                                                     // 208
			"matchType": "id",                                                                                                  // 208
			"intitule": {                                                                                                       // 208
				"FR": "Document(s) ayant cette étiquette"                                                                          // 208
			},                                                                                                                  // 208
			"afficherInfos": false                                                                                              // 208
		}]                                                                                                                   // 208
	},                                                                                                                    // 164
	// Liste des propriétés des objets LIEN (COMPLET)                                                                     // 211
	// ============================================================                                                       // 213
	// ATENTION	la propriété "afficherInfos" est toujours FALSE !!!                                                       // 214
	// ============================================================                                                       // 215
	"LIEN": {                                                                                                             // 217
		// Pouvant pointer vers des objets PERS                                                                              // 218
		"PERS": [{                                                                                                           // 219
			"prop": "comment",                                                                                                  // 220
			"matchType": "containId",                                                                                           // 220
			"intitule": {                                                                                                       // 220
				"FR": "Lien(s) ayant dans ses commentaires un pointeur vers cette personne"                                        // 220
			},                                                                                                                  // 220
			"afficherInfos": false                                                                                              // 220
		}, {                                                                                                                 // 220
			"prop": "comment",                                                                                                  // 221
			"matchType": "containOldId",                                                                                        // 221
			"intitule": {                                                                                                       // 221
				"FR": "Lien(s) ayant dans ses commentaires un pointeur (ancien Id) vers cette personne"                            // 221
			},                                                                                                                  // 221
			"afficherInfos": false                                                                                              // 221
		}, {                                                                                                                 // 221
			"prop": "pour.id",                                                                                                  // 222
			"matchType": "lienPour",                                                                                            // 222
			"intitule": {                                                                                                       // 222
				"FR": "Lien(s) existant pour cette personne"                                                                       // 222
			},                                                                                                                  // 222
			"afficherInfos": true                                                                                               // 222
		}, {                                                                                                                 // 222
			"prop": "vers.id",                                                                                                  // 223
			"matchType": "lienVers",                                                                                            // 223
			"intitule": {                                                                                                       // 223
				"FR": "Lien(s) existant vers cette personne"                                                                       // 223
			},                                                                                                                  // 223
			"afficherInfos": true                                                                                               // 223
		}],                                                                                                                  // 223
		// Pouvant pointer vers des objets LIEU                                                                              // 225
		"LIEU": [{                                                                                                           // 226
			"prop": "comment",                                                                                                  // 227
			"matchType": "containId",                                                                                           // 227
			"intitule": {                                                                                                       // 227
				"FR": "Lien(s) ayant dans ses commentaires un pointeur vers ce lieu"                                               // 227
			},                                                                                                                  // 227
			"afficherInfos": false                                                                                              // 227
		}, {                                                                                                                 // 227
			"prop": "comment",                                                                                                  // 228
			"matchType": "containOldId",                                                                                        // 228
			"intitule": {                                                                                                       // 228
				"FR": "Lien(s) ayant dans ses commentaires un pointeur (ancien Id) vers ce lieu"                                   // 228
			},                                                                                                                  // 228
			"afficherInfos": false                                                                                              // 228
		}, {                                                                                                                 // 228
			"prop": "pour.id",                                                                                                  // 229
			"matchType": "lienPour",                                                                                            // 229
			"intitule": {                                                                                                       // 229
				"FR": "Lien(s) existant pour ce lieu"                                                                              // 229
			},                                                                                                                  // 229
			"afficherInfos": true                                                                                               // 229
		}, {                                                                                                                 // 229
			"prop": "vers.id",                                                                                                  // 230
			"matchType": "lienVers",                                                                                            // 230
			"intitule": {                                                                                                       // 230
				"FR": "Lien(s) existant vers ce lieu"                                                                              // 230
			},                                                                                                                  // 230
			"afficherInfos": true                                                                                               // 230
		}],                                                                                                                  // 230
		// Pouvant pointer vers des objets HIST                                                                              // 232
		"HIST": [{                                                                                                           // 233
			"prop": "comment",                                                                                                  // 234
			"matchType": "containId",                                                                                           // 234
			"intitule": {                                                                                                       // 234
				"FR": "Lien(s) ayant dans ses commentaires un pointeur vers ce point d'histoire"                                   // 234
			},                                                                                                                  // 234
			"afficherInfos": false                                                                                              // 234
		}, {                                                                                                                 // 234
			"prop": "comment",                                                                                                  // 235
			"matchType": "containOldId",                                                                                        // 235
			"intitule": {                                                                                                       // 235
				"FR": "Lien(s) ayant dans ses commentaires un pointeur (ancien Id) vers ce point d'histoire"                       // 235
			},                                                                                                                  // 235
			"afficherInfos": false                                                                                              // 235
		}, {                                                                                                                 // 235
			"prop": "pour.id",                                                                                                  // 236
			"matchType": "lienPour",                                                                                            // 236
			"intitule": {                                                                                                       // 236
				"FR": "Lien(s) existant pour ce point d'histoire"                                                                  // 236
			},                                                                                                                  // 236
			"afficherInfos": true                                                                                               // 236
		}, {                                                                                                                 // 236
			"prop": "vers.id",                                                                                                  // 237
			"matchType": "lienVers",                                                                                            // 237
			"intitule": {                                                                                                       // 237
				"FR": "Lien(s) existant vers ce point d'histoire"                                                                  // 237
			},                                                                                                                  // 237
			"afficherInfos": true                                                                                               // 237
		}],                                                                                                                  // 237
		// Pouvant pointer vers des objets DOC                                                                               // 239
		"DOC": [{                                                                                                            // 240
			"prop": "comment",                                                                                                  // 241
			"matchType": "containId",                                                                                           // 241
			"intitule": {                                                                                                       // 241
				"FR": "Lien(s) ayant dans ses commentaires un pointeur vers ce document"                                           // 241
			},                                                                                                                  // 241
			"afficherInfos": false                                                                                              // 241
		}, {                                                                                                                 // 241
			"prop": "comment",                                                                                                  // 242
			"matchType": "containOldId",                                                                                        // 242
			"intitule": {                                                                                                       // 242
				"FR": "Lien(s) ayant dans ses commentaires un pointeur (ancien Id) vers ce document"                               // 242
			},                                                                                                                  // 242
			"afficherInfos": false                                                                                              // 242
		}, {                                                                                                                 // 242
			"prop": "pour.id",                                                                                                  // 243
			"matchType": "lienPour",                                                                                            // 243
			"intitule": {                                                                                                       // 243
				"FR": "Lien(s) existant pour ce document"                                                                          // 243
			},                                                                                                                  // 243
			"afficherInfos": true                                                                                               // 243
		}, {                                                                                                                 // 243
			"prop": "vers.id",                                                                                                  // 244
			"matchType": "lienVers",                                                                                            // 244
			"intitule": {                                                                                                       // 244
				"FR": "Lien(s) existant vers ce document"                                                                          // 244
			},                                                                                                                  // 244
			"afficherInfos": true                                                                                               // 244
		}]                                                                                                                   // 244
	},                                                                                                                    // 217
	// Liste des propriétés des objets REGISTRE (COMPLET),                                                                // 247
	// ============================================================                                                       // 249
	// ATENTION	la propriété "afficherInfos" est toujours FALSE !!!                                                       // 250
	// ============================================================                                                       // 251
	"REGISTRE": {                                                                                                         // 253
		// Pouvant pointer vers des objets LIEU                                                                              // 254
		"LIEU": [{                                                                                                           // 255
			"prop": "commune",                                                                                                  // 256
			"matchType": "id",                                                                                                  // 256
			"intitule": {                                                                                                       // 256
				"FR": "Registre(s) ayant pour commune ce lieu"                                                                     // 256
			},                                                                                                                  // 256
			"afficherInfos": false                                                                                              // 256
		}]                                                                                                                   // 256
	},                                                                                                                    // 253
	// Liste des propriétés des objets REGISTRE (A FAIRE)                                                                 // 259
	// ============================================================                                                       // 261
	// ATENTION	la propriété "afficherInfos" est toujours FALSE !!!                                                       // 262
	// ============================================================                                                       // 263
	"ACTE_ARCHIVES": {}                                                                                                   // 265
};                                                                                                                     // 4
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"periodesHist.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// common/periodesHist.js                                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
periodesHist = [{                                                                                                      // 1
	"date": {                                                                                                             // 4
		"type": "ENTRE",                                                                                                     // 7
		"j1": "",                                                                                                            // 8
		"m1": "",                                                                                                            // 9
		"a1": "1958",                                                                                                        // 10
		"rep1": "",                                                                                                          // 11
		"j2": "",                                                                                                            // 12
		"m2": "",                                                                                                            // 13
		"a2": "2200",                                                                                                        // 14
		"rep2": ""                                                                                                           // 15
	},                                                                                                                    // 6
	"intitule": "Cinquième République"                                                                                    // 18
}, {                                                                                                                   // 3
	"date": {                                                                                                             // 21
		"type": "ENTRE",                                                                                                     // 24
		"j1": "",                                                                                                            // 25
		"m1": "",                                                                                                            // 26
		"a1": "1945",                                                                                                        // 27
		"rep1": "",                                                                                                          // 28
		"j2": "",                                                                                                            // 29
		"m2": "",                                                                                                            // 30
		"a2": "1958",                                                                                                        // 31
		"rep2": ""                                                                                                           // 32
	},                                                                                                                    // 23
	"intitule": "Quatrième République"                                                                                    // 35
}, {                                                                                                                   // 20
	"date": {                                                                                                             // 38
		"type": "ENTRE",                                                                                                     // 41
		"j1": "",                                                                                                            // 42
		"m1": "",                                                                                                            // 43
		"a1": "1939",                                                                                                        // 44
		"rep1": "",                                                                                                          // 45
		"j2": "",                                                                                                            // 46
		"m2": "",                                                                                                            // 47
		"a2": "1945",                                                                                                        // 48
		"rep2": ""                                                                                                           // 49
	},                                                                                                                    // 40
	"intitule": "2ème guerre mondiale"                                                                                    // 52
}, {                                                                                                                   // 37
	"date": {                                                                                                             // 55
		"type": "ENTRE",                                                                                                     // 58
		"j1": "",                                                                                                            // 59
		"m1": "",                                                                                                            // 60
		"a1": "1918",                                                                                                        // 61
		"rep1": "",                                                                                                          // 62
		"j2": "",                                                                                                            // 63
		"m2": "",                                                                                                            // 64
		"a2": "1939",                                                                                                        // 65
		"rep2": ""                                                                                                           // 66
	},                                                                                                                    // 57
	"intitule": "Entre-deux guerres"                                                                                      // 69
}, {                                                                                                                   // 54
	"date": {                                                                                                             // 72
		"type": "ENTRE",                                                                                                     // 75
		"j1": "",                                                                                                            // 76
		"m1": "",                                                                                                            // 77
		"a1": "1914",                                                                                                        // 78
		"rep1": "",                                                                                                          // 79
		"j2": "",                                                                                                            // 80
		"m2": "",                                                                                                            // 81
		"a2": "1918",                                                                                                        // 82
		"rep2": ""                                                                                                           // 83
	},                                                                                                                    // 74
	"intitule": "1ère guerre mondiale"                                                                                    // 86
}, {                                                                                                                   // 71
	"date": {                                                                                                             // 89
		"type": "ENTRE",                                                                                                     // 92
		"j1": "",                                                                                                            // 93
		"m1": "",                                                                                                            // 94
		"a1": "1870",                                                                                                        // 95
		"rep1": "",                                                                                                          // 96
		"j2": "",                                                                                                            // 97
		"m2": "",                                                                                                            // 98
		"a2": "1914",                                                                                                        // 99
		"rep2": ""                                                                                                           // 100
	},                                                                                                                    // 91
	"intitule": "Troisième République"                                                                                    // 103
}, {                                                                                                                   // 88
	"date": {                                                                                                             // 106
		"type": "ENTRE",                                                                                                     // 109
		"j1": "",                                                                                                            // 110
		"m1": "",                                                                                                            // 111
		"a1": "1852",                                                                                                        // 112
		"rep1": "",                                                                                                          // 113
		"j2": "",                                                                                                            // 114
		"m2": "",                                                                                                            // 115
		"a2": "1870",                                                                                                        // 116
		"rep2": ""                                                                                                           // 117
	},                                                                                                                    // 108
	"intitule": "Second Empire"                                                                                           // 120
}, {                                                                                                                   // 105
	"date": {                                                                                                             // 123
		"type": "ENTRE",                                                                                                     // 126
		"j1": "",                                                                                                            // 127
		"m1": "",                                                                                                            // 128
		"a1": "1848",                                                                                                        // 129
		"rep1": "",                                                                                                          // 130
		"j2": "",                                                                                                            // 131
		"m2": "",                                                                                                            // 132
		"a2": "1852",                                                                                                        // 133
		"rep2": ""                                                                                                           // 134
	},                                                                                                                    // 125
	"intitule": "Seconde République"                                                                                      // 137
}, {                                                                                                                   // 122
	"date": {                                                                                                             // 140
		"type": "ENTRE",                                                                                                     // 143
		"j1": "",                                                                                                            // 144
		"m1": "",                                                                                                            // 145
		"a1": "1830",                                                                                                        // 146
		"rep1": "",                                                                                                          // 147
		"j2": "",                                                                                                            // 148
		"m2": "",                                                                                                            // 149
		"a2": "1848",                                                                                                        // 150
		"rep2": ""                                                                                                           // 151
	},                                                                                                                    // 142
	"intitule": "Monarchie de Juillet"                                                                                    // 154
}, {                                                                                                                   // 139
	"date": {                                                                                                             // 157
		"type": "ENTRE",                                                                                                     // 160
		"j1": "",                                                                                                            // 161
		"m1": "",                                                                                                            // 162
		"a1": "1815",                                                                                                        // 163
		"rep1": "",                                                                                                          // 164
		"j2": "",                                                                                                            // 165
		"m2": "",                                                                                                            // 166
		"a2": "1830",                                                                                                        // 167
		"rep2": ""                                                                                                           // 168
	},                                                                                                                    // 159
	"intitule": "Restauration"                                                                                            // 171
}, {                                                                                                                   // 156
	"date": {                                                                                                             // 174
		"type": "ENTRE",                                                                                                     // 177
		"j1": "",                                                                                                            // 178
		"m1": "",                                                                                                            // 179
		"a1": "1799",                                                                                                        // 180
		"rep1": "",                                                                                                          // 181
		"j2": "",                                                                                                            // 182
		"m2": "",                                                                                                            // 183
		"a2": "1815",                                                                                                        // 184
		"rep2": ""                                                                                                           // 185
	},                                                                                                                    // 176
	"intitule": "Consulat et Empire"                                                                                      // 188
}, {                                                                                                                   // 173
	"date": {                                                                                                             // 191
		"type": "ENTRE",                                                                                                     // 194
		"j1": "",                                                                                                            // 195
		"m1": "",                                                                                                            // 196
		"a1": "1789",                                                                                                        // 197
		"rep1": "",                                                                                                          // 198
		"j2": "",                                                                                                            // 199
		"m2": "",                                                                                                            // 200
		"a2": "1799",                                                                                                        // 201
		"rep2": ""                                                                                                           // 202
	},                                                                                                                    // 193
	"intitule": "Révolution"                                                                                              // 205
}, {                                                                                                                   // 190
	"date": {                                                                                                             // 208
		"type": "ENTRE",                                                                                                     // 211
		"j1": "",                                                                                                            // 212
		"m1": "",                                                                                                            // 213
		"a1": "1774",                                                                                                        // 214
		"rep1": "",                                                                                                          // 215
		"j2": "",                                                                                                            // 216
		"m2": "",                                                                                                            // 217
		"a2": "1789",                                                                                                        // 218
		"rep2": ""                                                                                                           // 219
	},                                                                                                                    // 210
	"intitule": "Louis XVI"                                                                                               // 222
}, {                                                                                                                   // 207
	"date": {                                                                                                             // 225
		"type": "ENTRE",                                                                                                     // 228
		"j1": "",                                                                                                            // 229
		"m1": "",                                                                                                            // 230
		"a1": "1715",                                                                                                        // 231
		"rep1": "",                                                                                                          // 232
		"j2": "",                                                                                                            // 233
		"m2": "",                                                                                                            // 234
		"a2": "1774",                                                                                                        // 235
		"rep2": ""                                                                                                           // 236
	},                                                                                                                    // 227
	"intitule": "Louis XV"                                                                                                // 239
}, {                                                                                                                   // 224
	"date": {                                                                                                             // 242
		"type": "ENTRE",                                                                                                     // 245
		"j1": "",                                                                                                            // 246
		"m1": "",                                                                                                            // 247
		"a1": "1643",                                                                                                        // 248
		"rep1": "",                                                                                                          // 249
		"j2": "",                                                                                                            // 250
		"m2": "",                                                                                                            // 251
		"a2": "1715",                                                                                                        // 252
		"rep2": ""                                                                                                           // 253
	},                                                                                                                    // 244
	"intitule": "Louis XIV"                                                                                               // 256
}, {                                                                                                                   // 241
	"date": {                                                                                                             // 259
		"type": "ENTRE",                                                                                                     // 262
		"j1": "",                                                                                                            // 263
		"m1": "",                                                                                                            // 264
		"a1": "1610",                                                                                                        // 265
		"rep1": "",                                                                                                          // 266
		"j2": "",                                                                                                            // 267
		"m2": "",                                                                                                            // 268
		"a2": "1643",                                                                                                        // 269
		"rep2": ""                                                                                                           // 270
	},                                                                                                                    // 261
	"intitule": "Louis XIII"                                                                                              // 273
}, {                                                                                                                   // 258
	"date": {                                                                                                             // 276
		"type": "ENTRE",                                                                                                     // 279
		"j1": "",                                                                                                            // 280
		"m1": "",                                                                                                            // 281
		"a1": "1589",                                                                                                        // 282
		"rep1": "",                                                                                                          // 283
		"j2": "",                                                                                                            // 284
		"m2": "",                                                                                                            // 285
		"a2": "1610",                                                                                                        // 286
		"rep2": ""                                                                                                           // 287
	},                                                                                                                    // 278
	"intitule": "Henri IV"                                                                                                // 290
}, {                                                                                                                   // 275
	"date": {                                                                                                             // 293
		"type": "ENTRE",                                                                                                     // 296
		"j1": "",                                                                                                            // 297
		"m1": "",                                                                                                            // 298
		"a1": "1574",                                                                                                        // 299
		"rep1": "",                                                                                                          // 300
		"j2": "",                                                                                                            // 301
		"m2": "",                                                                                                            // 302
		"a2": "1589",                                                                                                        // 303
		"rep2": ""                                                                                                           // 304
	},                                                                                                                    // 295
	"intitule": "Henri III"                                                                                               // 307
}, {                                                                                                                   // 292
	"date": {                                                                                                             // 310
		"type": "ENTRE",                                                                                                     // 313
		"j1": "",                                                                                                            // 314
		"m1": "",                                                                                                            // 315
		"a1": "1560",                                                                                                        // 316
		"rep1": "",                                                                                                          // 317
		"j2": "",                                                                                                            // 318
		"m2": "",                                                                                                            // 319
		"a2": "1574",                                                                                                        // 320
		"rep2": ""                                                                                                           // 321
	},                                                                                                                    // 312
	"intitule": "Charles I"                                                                                               // 324
}, {                                                                                                                   // 309
	"date": {                                                                                                             // 327
		"type": "ENTRE",                                                                                                     // 330
		"j1": "",                                                                                                            // 331
		"m1": "",                                                                                                            // 332
		"a1": "1559",                                                                                                        // 333
		"rep1": "",                                                                                                          // 334
		"j2": "",                                                                                                            // 335
		"m2": "",                                                                                                            // 336
		"a2": "1560",                                                                                                        // 337
		"rep2": ""                                                                                                           // 338
	},                                                                                                                    // 329
	"intitule": "François II"                                                                                             // 341
}, {                                                                                                                   // 326
	"date": {                                                                                                             // 344
		"type": "ENTRE",                                                                                                     // 347
		"j1": "",                                                                                                            // 348
		"m1": "",                                                                                                            // 349
		"a1": "1547",                                                                                                        // 350
		"rep1": "",                                                                                                          // 351
		"j2": "",                                                                                                            // 352
		"m2": "",                                                                                                            // 353
		"a2": "1559",                                                                                                        // 354
		"rep2": ""                                                                                                           // 355
	},                                                                                                                    // 346
	"intitule": "Henri II"                                                                                                // 358
}, {                                                                                                                   // 343
	"date": {                                                                                                             // 361
		"type": "ENTRE",                                                                                                     // 364
		"j1": "",                                                                                                            // 365
		"m1": "",                                                                                                            // 366
		"a1": "1515",                                                                                                        // 367
		"rep1": "",                                                                                                          // 368
		"j2": "",                                                                                                            // 369
		"m2": "",                                                                                                            // 370
		"a2": "1547",                                                                                                        // 371
		"rep2": ""                                                                                                           // 372
	},                                                                                                                    // 363
	"intitule": "François Ier"                                                                                            // 375
}, {                                                                                                                   // 360
	"date": {                                                                                                             // 378
		"type": "ENTRE",                                                                                                     // 381
		"j1": "",                                                                                                            // 382
		"m1": "",                                                                                                            // 383
		"a1": "1498",                                                                                                        // 384
		"rep1": "",                                                                                                          // 385
		"j2": "",                                                                                                            // 386
		"m2": "",                                                                                                            // 387
		"a2": "1515",                                                                                                        // 388
		"rep2": ""                                                                                                           // 389
	},                                                                                                                    // 380
	"intitule": "Louis XII"                                                                                               // 392
}, {                                                                                                                   // 377
	"date": {                                                                                                             // 395
		"type": "ENTRE",                                                                                                     // 398
		"j1": "",                                                                                                            // 399
		"m1": "",                                                                                                            // 400
		"a1": "1483",                                                                                                        // 401
		"rep1": "",                                                                                                          // 402
		"j2": "",                                                                                                            // 403
		"m2": "",                                                                                                            // 404
		"a2": "1498",                                                                                                        // 405
		"rep2": ""                                                                                                           // 406
	},                                                                                                                    // 397
	"intitule": "Charles VIII"                                                                                            // 409
}, {                                                                                                                   // 394
	"date": {                                                                                                             // 412
		"type": "ENTRE",                                                                                                     // 415
		"j1": "",                                                                                                            // 416
		"m1": "",                                                                                                            // 417
		"a1": "1461",                                                                                                        // 418
		"rep1": "",                                                                                                          // 419
		"j2": "",                                                                                                            // 420
		"m2": "",                                                                                                            // 421
		"a2": "1483",                                                                                                        // 422
		"rep2": ""                                                                                                           // 423
	},                                                                                                                    // 414
	"intitule": "Louis XI"                                                                                                // 426
}, {                                                                                                                   // 411
	"date": {                                                                                                             // 429
		"type": "ENTRE",                                                                                                     // 432
		"j1": "",                                                                                                            // 433
		"m1": "",                                                                                                            // 434
		"a1": "1428",                                                                                                        // 435
		"rep1": "",                                                                                                          // 436
		"j2": "",                                                                                                            // 437
		"m2": "",                                                                                                            // 438
		"a2": "1461",                                                                                                        // 439
		"rep2": ""                                                                                                           // 440
	},                                                                                                                    // 431
	"intitule": "Charles VII"                                                                                             // 443
}, {                                                                                                                   // 428
	"date": {                                                                                                             // 446
		"type": "ENTRE",                                                                                                     // 449
		"j1": "",                                                                                                            // 450
		"m1": "",                                                                                                            // 451
		"a1": "1380",                                                                                                        // 452
		"rep1": "",                                                                                                          // 453
		"j2": "",                                                                                                            // 454
		"m2": "",                                                                                                            // 455
		"a2": "1422",                                                                                                        // 456
		"rep2": ""                                                                                                           // 457
	},                                                                                                                    // 448
	"intitule": "Charles VI le Fou"                                                                                       // 460
}, {                                                                                                                   // 445
	"date": {                                                                                                             // 463
		"type": "ENTRE",                                                                                                     // 466
		"j1": "",                                                                                                            // 467
		"m1": "",                                                                                                            // 468
		"a1": "1364",                                                                                                        // 469
		"rep1": "",                                                                                                          // 470
		"j2": "",                                                                                                            // 471
		"m2": "",                                                                                                            // 472
		"a2": "1380",                                                                                                        // 473
		"rep2": ""                                                                                                           // 474
	},                                                                                                                    // 465
	"intitule": "Charles V le Sage"                                                                                       // 477
}, {                                                                                                                   // 462
	"date": {                                                                                                             // 480
		"type": "ENTRE",                                                                                                     // 483
		"j1": "",                                                                                                            // 484
		"m1": "",                                                                                                            // 485
		"a1": "1350",                                                                                                        // 486
		"rep1": "",                                                                                                          // 487
		"j2": "",                                                                                                            // 488
		"m2": "",                                                                                                            // 489
		"a2": "1364",                                                                                                        // 490
		"rep2": ""                                                                                                           // 491
	},                                                                                                                    // 482
	"intitule": "Jean II le Bon"                                                                                          // 494
}, {                                                                                                                   // 479
	"date": {                                                                                                             // 497
		"type": "ENTRE",                                                                                                     // 500
		"j1": "",                                                                                                            // 501
		"m1": "",                                                                                                            // 502
		"a1": "1328",                                                                                                        // 503
		"rep1": "",                                                                                                          // 504
		"j2": "",                                                                                                            // 505
		"m2": "",                                                                                                            // 506
		"a2": "1350",                                                                                                        // 507
		"rep2": ""                                                                                                           // 508
	},                                                                                                                    // 499
	"intitule": "Philippe VI"                                                                                             // 511
}, {                                                                                                                   // 496
	"date": {                                                                                                             // 514
		"type": "ENTRE",                                                                                                     // 517
		"j1": "",                                                                                                            // 518
		"m1": "",                                                                                                            // 519
		"a1": "1322",                                                                                                        // 520
		"rep1": "",                                                                                                          // 521
		"j2": "",                                                                                                            // 522
		"m2": "",                                                                                                            // 523
		"a2": "1328",                                                                                                        // 524
		"rep2": ""                                                                                                           // 525
	},                                                                                                                    // 516
	"intitule": "Charles IV le Bel"                                                                                       // 528
}, {                                                                                                                   // 513
	"date": {                                                                                                             // 531
		"type": "ENTRE",                                                                                                     // 534
		"j1": "",                                                                                                            // 535
		"m1": "",                                                                                                            // 536
		"a1": "1316",                                                                                                        // 537
		"rep1": "",                                                                                                          // 538
		"j2": "",                                                                                                            // 539
		"m2": "",                                                                                                            // 540
		"a2": "1322",                                                                                                        // 541
		"rep2": ""                                                                                                           // 542
	},                                                                                                                    // 533
	"intitule": "Philippe V le Long"                                                                                      // 545
}, {                                                                                                                   // 530
	"date": {                                                                                                             // 548
		"type": "ENTRE",                                                                                                     // 551
		"j1": "",                                                                                                            // 552
		"m1": "",                                                                                                            // 553
		"a1": "1314",                                                                                                        // 554
		"rep1": "",                                                                                                          // 555
		"j2": "",                                                                                                            // 556
		"m2": "",                                                                                                            // 557
		"a2": "1316",                                                                                                        // 558
		"rep2": ""                                                                                                           // 559
	},                                                                                                                    // 550
	"intitule": "Louis X le Hutin"                                                                                        // 562
}, {                                                                                                                   // 547
	"date": {                                                                                                             // 565
		"type": "ENTRE",                                                                                                     // 568
		"j1": "",                                                                                                            // 569
		"m1": "",                                                                                                            // 570
		"a1": "1285",                                                                                                        // 571
		"rep1": "",                                                                                                          // 572
		"j2": "",                                                                                                            // 573
		"m2": "",                                                                                                            // 574
		"a2": "1314",                                                                                                        // 575
		"rep2": ""                                                                                                           // 576
	},                                                                                                                    // 567
	"intitule": "Philippe IV le Bel"                                                                                      // 579
}, {                                                                                                                   // 564
	"date": {                                                                                                             // 582
		"type": "ENTRE",                                                                                                     // 585
		"j1": "",                                                                                                            // 586
		"m1": "",                                                                                                            // 587
		"a1": "1270",                                                                                                        // 588
		"rep1": "",                                                                                                          // 589
		"j2": "",                                                                                                            // 590
		"m2": "",                                                                                                            // 591
		"a2": "1285",                                                                                                        // 592
		"rep2": ""                                                                                                           // 593
	},                                                                                                                    // 584
	"intitule": "Philippe III le Hardi"                                                                                   // 596
}, {                                                                                                                   // 581
	"date": {                                                                                                             // 599
		"type": "ENTRE",                                                                                                     // 602
		"j1": "",                                                                                                            // 603
		"m1": "",                                                                                                            // 604
		"a1": "1226",                                                                                                        // 605
		"rep1": "",                                                                                                          // 606
		"j2": "",                                                                                                            // 607
		"m2": "",                                                                                                            // 608
		"a2": "1270",                                                                                                        // 609
		"rep2": ""                                                                                                           // 610
	},                                                                                                                    // 601
	"intitule": "Louis IX le Saint"                                                                                       // 613
}, {                                                                                                                   // 598
	"date": {                                                                                                             // 616
		"type": "ENTRE",                                                                                                     // 619
		"j1": "",                                                                                                            // 620
		"m1": "",                                                                                                            // 621
		"a1": "1223",                                                                                                        // 622
		"rep1": "",                                                                                                          // 623
		"j2": "",                                                                                                            // 624
		"m2": "",                                                                                                            // 625
		"a2": "1226",                                                                                                        // 626
		"rep2": ""                                                                                                           // 627
	},                                                                                                                    // 618
	"intitule": "Louis VIII le Lion"                                                                                      // 630
}, {                                                                                                                   // 615
	"date": {                                                                                                             // 633
		"type": "ENTRE",                                                                                                     // 636
		"j1": "",                                                                                                            // 637
		"m1": "",                                                                                                            // 638
		"a1": "1180",                                                                                                        // 639
		"rep1": "",                                                                                                          // 640
		"j2": "",                                                                                                            // 641
		"m2": "",                                                                                                            // 642
		"a2": "1223",                                                                                                        // 643
		"rep2": ""                                                                                                           // 644
	},                                                                                                                    // 635
	"intitule": "Philippe II Auguste"                                                                                     // 647
}, {                                                                                                                   // 632
	"date": {                                                                                                             // 650
		"type": "ENTRE",                                                                                                     // 653
		"j1": "",                                                                                                            // 654
		"m1": "",                                                                                                            // 655
		"a1": "1137",                                                                                                        // 656
		"rep1": "",                                                                                                          // 657
		"j2": "",                                                                                                            // 658
		"m2": "",                                                                                                            // 659
		"a2": "1180",                                                                                                        // 660
		"rep2": ""                                                                                                           // 661
	},                                                                                                                    // 652
	"intitule": "Louis VII"                                                                                               // 664
}, {                                                                                                                   // 649
	"date": {                                                                                                             // 667
		"type": "ENTRE",                                                                                                     // 670
		"j1": "",                                                                                                            // 671
		"m1": "",                                                                                                            // 672
		"a1": "1108",                                                                                                        // 673
		"rep1": "",                                                                                                          // 674
		"j2": "",                                                                                                            // 675
		"m2": "",                                                                                                            // 676
		"a2": "1137",                                                                                                        // 677
		"rep2": ""                                                                                                           // 678
	},                                                                                                                    // 669
	"intitule": "Louis VI le Gros"                                                                                        // 681
}, {                                                                                                                   // 666
	"date": {                                                                                                             // 684
		"type": "ENTRE",                                                                                                     // 687
		"j1": "",                                                                                                            // 688
		"m1": "",                                                                                                            // 689
		"a1": "1060",                                                                                                        // 690
		"rep1": "",                                                                                                          // 691
		"j2": "",                                                                                                            // 692
		"m2": "",                                                                                                            // 693
		"a2": "1108",                                                                                                        // 694
		"rep2": ""                                                                                                           // 695
	},                                                                                                                    // 686
	"intitule": "Philippe Ier"                                                                                            // 698
}, {                                                                                                                   // 683
	"date": {                                                                                                             // 701
		"type": "ENTRE",                                                                                                     // 704
		"j1": "",                                                                                                            // 705
		"m1": "",                                                                                                            // 706
		"a1": "1031",                                                                                                        // 707
		"rep1": "",                                                                                                          // 708
		"j2": "",                                                                                                            // 709
		"m2": "",                                                                                                            // 710
		"a2": "1060",                                                                                                        // 711
		"rep2": ""                                                                                                           // 712
	},                                                                                                                    // 703
	"intitule": "Henri Ier"                                                                                               // 715
}, {                                                                                                                   // 700
	"date": {                                                                                                             // 718
		"type": "ENTRE",                                                                                                     // 721
		"j1": "",                                                                                                            // 722
		"m1": "",                                                                                                            // 723
		"a1": "996",                                                                                                         // 724
		"rep1": "",                                                                                                          // 725
		"j2": "",                                                                                                            // 726
		"m2": "",                                                                                                            // 727
		"a2": "1031",                                                                                                        // 728
		"rep2": ""                                                                                                           // 729
	},                                                                                                                    // 720
	"intitule": "Robert II le Pieux"                                                                                      // 732
}, {                                                                                                                   // 717
	"date": {                                                                                                             // 735
		"type": "ENTRE",                                                                                                     // 738
		"j1": "",                                                                                                            // 739
		"m1": "",                                                                                                            // 740
		"a1": "987",                                                                                                         // 741
		"rep1": "",                                                                                                          // 742
		"j2": "",                                                                                                            // 743
		"m2": "",                                                                                                            // 744
		"a2": "996",                                                                                                         // 745
		"rep2": ""                                                                                                           // 746
	},                                                                                                                    // 737
	"intitule": "Hugues Capet"                                                                                            // 749
}, {                                                                                                                   // 734
	"date": {                                                                                                             // 752
		"type": "ENTRE",                                                                                                     // 755
		"j1": "",                                                                                                            // 756
		"m1": "",                                                                                                            // 757
		"a1": "793",                                                                                                         // 758
		"rep1": "",                                                                                                          // 759
		"j2": "",                                                                                                            // 760
		"m2": "",                                                                                                            // 761
		"a2": "984",                                                                                                         // 762
		"rep2": ""                                                                                                           // 763
	},                                                                                                                    // 754
	"intitule": "Les invasions normandes"                                                                                 // 766
}];                                                                                                                    // 751
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"schemas.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// common/schemas.js                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var module1 = module;                                                                                                  // 1
var SimpleSchema = void 0;                                                                                             // 1
module1.watch(require("simpl-schema"), {                                                                               // 1
	"default": function (v) {                                                                                             // 1
		SimpleSchema = v;                                                                                                    // 1
	}                                                                                                                     // 1
}, 0);                                                                                                                 // 1
var Tracker = void 0;                                                                                                  // 1
module1.watch(require("meteor/tracker"), {                                                                             // 1
	Tracker: function (v) {                                                                                               // 1
		Tracker = v;                                                                                                         // 1
	}                                                                                                                     // 1
}, 1);                                                                                                                 // 1
SimpleSchema.extendOptions(['autoform']);                                                                              // 12
SimpleSchema.extendOptions(['doc']);                                                                                   // 13
                                                                                                                       //
SCHEMA_allowedValues = function (parametre) {                                                                          // 16
	// allowedValue(genresLieux) renvoie par exemple :                                                                    // 17
	// ["MS","FS","PL","ES","SS"]                                                                                         // 18
	return _.map(parametreCommuns[parametre], function (ligne) {                                                          // 19
		return ligne.valeur;                                                                                                 // 22
	});                                                                                                                   // 23
};                                                                                                                     // 25
                                                                                                                       //
SCHEMA_options = function (parametre) {                                                                                // 27
	// options(genresLieux) renvoie par exemple :                                                                         // 28
	// [                                                                                                                  // 29
	//	{value : "MS", 	label : "le"},                                                                                     // 30
	//	{value : "FS",	label : "la"},                                                                                      // 31
	//	{value : "PL", 	label : "les"},                                                                                    // 32
	//	{value : "ES", 	label : "l'"},                                                                                     // 33
	//	{value : "SS", 	label : "-"},                                                                                      // 34
	// ]                                                                                                                  // 35
	return _.map(parametreCommuns[parametre], function (ligne) {                                                          // 36
		return {                                                                                                             // 39
			value: ligne.valeur,                                                                                                // 39
			label: ligne.intitule["FR"]                                                                                         // 39
		};                                                                                                                   // 39
	});                                                                                                                   // 40
}; // ==============================================                                                                   // 42
// messages de validation multilingues                                                                                 // 45
// ==============================================                                                                      // 46
                                                                                                                       //
                                                                                                                       //
var regExpMessages = [{                                                                                                // 48
	exp: /^\?$|^[A-Z\s\\?']*$/,                                                                                           // 49
	msg: "Lettres majuscules, blanc, ? et ' sont les seuls caractères autorisés"                                          // 49
}, {                                                                                                                   // 49
	exp: /[0-9a-zA-Z]{17}$/,                                                                                              // 50
	msg: "Ce champ doit-être un ID valide"                                                                                // 50
}];                                                                                                                    // 50
SimpleSchema.setDefaultMessages({                                                                                      // 53
	initialLanguage: 'fr',                                                                                                // 54
	messages: {                                                                                                           // 55
		fr: {                                                                                                                // 56
			required: 'Ce champ est obligatoire',                                                                               // 57
			minString: 'Ce champ doit faire au moins {{min}} caractères',                                                       // 58
			maxString: 'Ce champ doit faire au plus {{max}} characters',                                                        // 59
			minNumber: 'Ce champ doit-être supérieur à {{min}}',                                                                // 60
			maxNumber: 'Ce champ doit-être inférieur à {{max}}',                                                                // 61
			minNumberExclusive: 'Ce champ doit-être strictement supérieur à {{min}}',                                           // 62
			maxNumberExclusive: 'Ce champ doit-être strictement inférieur à {{max}}',                                           // 63
			minDate: 'Ce champ ne doit pas être antérieur à {{min}}',                                                           // 64
			maxDate: 'Ce champ de doit pas être postérieur à {{max}}',                                                          // 65
			badDate: 'Ce champ n\'est pas une date valide',                                                                     // 66
			minCount: 'Vous devez préciser au moins {{minCount}} valeurs',                                                      // 67
			maxCount: 'Il ne peut y avoir plus de {{maxCount}} valeurs',                                                        // 68
			noDecimal: 'Ce champ doit être un entier',                                                                          // 69
			notAllowed: 'Valeur non autorisée pour ce champ',                                                                   // 70
			expectedType: 'Ce champ doit être un type {{dataType}}',                                                            // 71
			regEx: function (_ref) {                                                                                            // 72
				var label = _ref.label,                                                                                            // 72
				    regExp = _ref.regExp;                                                                                          // 72
				// On recherche dans l'array regExpMessages si un message spécifique existe pour cette regex                       // 73
				var msgObj = void 0;                                                                                               // 74
				if (regExp) msgObj = _.find(regExpMessages, function (o) {                                                         // 75
					return o.exp && o.exp.toString() === regExp;                                                                      // 75
				});                                                                                                                // 75
				var regExpMessage = msgObj ? msgObj.msg : 'Erreur de validation de reGex';                                         // 76
				return "" + regExpMessage;                                                                                         // 77
			},                                                                                                                  // 78
			keyNotInSchema: '{{name}} n\'est pas une valeur autorisée'                                                          // 79
		}                                                                                                                    // 56
	}                                                                                                                     // 55
}); // ==============================================                                                                  // 53
// 					SCHEMAS                                                                                                        // 85
// ==============================================                                                                      // 86
                                                                                                                       //
SCHEMA = {}; // ==============================================                                                         // 88
// googleMap                                                                                                           // 91
// ==============================================                                                                      // 92
                                                                                                                       //
SCHEMA._googleMap = new SimpleSchema({                                                                                 // 93
	"lat": {                                                                                                              // 94
		type: Number,                                                                                                        // 95
		label: "Latitude",                                                                                                   // 96
		optional: true,                                                                                                      // 97
		min: -90,                                                                                                            // 98
		max: 90,                                                                                                             // 99
		// To allow decimal input with a dot (instead of comma) on french machines                                           // 100
		autoform: {                                                                                                          // 101
			afFieldInput: {                                                                                                     // 102
				type: "text"                                                                                                       // 103
			}                                                                                                                   // 102
		}                                                                                                                    // 101
	},                                                                                                                    // 94
	"lng": {                                                                                                              // 107
		type: Number,                                                                                                        // 108
		label: "Longitude",                                                                                                  // 109
		optional: true,                                                                                                      // 110
		min: -180,                                                                                                           // 111
		max: 180,                                                                                                            // 112
		// To allow decimal input with a dot (instead of comma) on french machines                                           // 113
		autoform: {                                                                                                          // 114
			afFieldInput: {                                                                                                     // 115
				type: "text"                                                                                                       // 116
			}                                                                                                                   // 115
		}                                                                                                                    // 114
	}                                                                                                                     // 107
}, {                                                                                                                   // 93
	tracker: Tracker                                                                                                      // 120
}); // ==============================================                                                                  // 120
// positionCarte                                                                                                       // 123
// ==============================================                                                                      // 124
                                                                                                                       //
SCHEMA._positionCarte = new SimpleSchema({                                                                             // 125
	"id": {                                                                                                               // 126
		type: String,                                                                                                        // 127
		label: "id",                                                                                                         // 128
		optional: false                                                                                                      // 129
	},                                                                                                                    // 126
	"x": {                                                                                                                // 131
		type: String,                                                                                                        // 132
		label: "X",                                                                                                          // 133
		optional: false                                                                                                      // 134
	},                                                                                                                    // 131
	"y": {                                                                                                                // 136
		type: String,                                                                                                        // 137
		label: "Y",                                                                                                          // 138
		optional: false                                                                                                      // 139
	},                                                                                                                    // 136
	"px": {                                                                                                               // 141
		type: String,                                                                                                        // 142
		label: "px",                                                                                                         // 143
		optional: false                                                                                                      // 144
	},                                                                                                                    // 141
	"py": {                                                                                                               // 146
		type: String,                                                                                                        // 147
		label: "py",                                                                                                         // 148
		optional: false                                                                                                      // 149
	}                                                                                                                     // 146
}, {                                                                                                                   // 125
	tracker: Tracker                                                                                                      // 151
}); // ==============================================                                                                  // 151
// date                                                                                                                // 154
// ==============================================                                                                      // 155
                                                                                                                       //
SCHEMA._date = new SimpleSchema({                                                                                      // 156
	"type": {                                                                                                             // 157
		type: String,                                                                                                        // 158
		label: "Type",                                                                                                       // 159
		allowedValues: SCHEMA_allowedValues("typesDates"),                                                                   // 160
		autoform: {                                                                                                          // 161
			options: SCHEMA_options("typesDates"),                                                                              // 162
			afFieldInput: {                                                                                                     // 163
				firstOption: "- choisir un type" // Nécessaire sinon, l'objet est toujours créé                                    // 164
                                                                                                                       //
			},                                                                                                                  // 163
			label: false                                                                                                        // 166
		},                                                                                                                   // 161
		optional: true                                                                                                       // 168
	},                                                                                                                    // 157
	"j1": {                                                                                                               // 170
		type: SimpleSchema.Integer,                                                                                          // 171
		label: "Jour",                                                                                                       // 172
		min: 1,                                                                                                              // 173
		max: 31,                                                                                                             // 174
		autoform: {                                                                                                          // 175
			placeholder: "jour",                                                                                                // 176
			label: false                                                                                                        // 177
		},                                                                                                                   // 175
		optional: true                                                                                                       // 179
	},                                                                                                                    // 170
	"m1": {                                                                                                               // 181
		type: SimpleSchema.Integer,                                                                                          // 182
		label: "Mois",                                                                                                       // 183
		min: 1,                                                                                                              // 184
		max: 12,                                                                                                             // 185
		autoform: {                                                                                                          // 186
			placeholder: "mois",                                                                                                // 187
			label: false                                                                                                        // 188
		},                                                                                                                   // 186
		optional: true                                                                                                       // 190
	},                                                                                                                    // 181
	"a1": {                                                                                                               // 192
		type: SimpleSchema.Integer,                                                                                          // 193
		label: "Année",                                                                                                      // 194
		min: 0,                                                                                                              // 195
		max: 2500,                                                                                                           // 196
		autoform: {                                                                                                          // 197
			placeholder: "année",                                                                                               // 198
			label: false                                                                                                        // 199
		},                                                                                                                   // 197
		optional: true                                                                                                       // 201
	},                                                                                                                    // 192
	"j2": {                                                                                                               // 203
		type: SimpleSchema.Integer,                                                                                          // 204
		label: "Et jour",                                                                                                    // 205
		min: 1,                                                                                                              // 206
		max: 31,                                                                                                             // 207
		autoform: {                                                                                                          // 208
			placeholder: "et jour",                                                                                             // 209
			label: false                                                                                                        // 210
		},                                                                                                                   // 208
		optional: true                                                                                                       // 212
	},                                                                                                                    // 203
	"m2": {                                                                                                               // 214
		type: SimpleSchema.Integer,                                                                                          // 215
		label: "Mois",                                                                                                       // 216
		min: 1,                                                                                                              // 217
		max: 12,                                                                                                             // 218
		autoform: {                                                                                                          // 219
			placeholder: "mois",                                                                                                // 220
			label: false                                                                                                        // 221
		},                                                                                                                   // 219
		optional: true                                                                                                       // 223
	},                                                                                                                    // 214
	"a2": {                                                                                                               // 225
		type: SimpleSchema.Integer,                                                                                          // 226
		label: "Année",                                                                                                      // 227
		min: 0,                                                                                                              // 228
		max: 2500,                                                                                                           // 229
		autoform: {                                                                                                          // 230
			placeholder: "annee",                                                                                               // 231
			label: false                                                                                                        // 232
		},                                                                                                                   // 230
		optional: true                                                                                                       // 234
	}                                                                                                                     // 225
}, {                                                                                                                   // 156
	tracker: Tracker                                                                                                      // 236
}); // ==============================================                                                                  // 236
// acte                                                                                                                // 239
// ==============================================                                                                      // 240
                                                                                                                       //
SCHEMA._acte = new SimpleSchema({                                                                                      // 241
	"incertain": {                                                                                                        // 242
		type: Boolean,                                                                                                       // 243
		label: "Acte et/ou date incertains",                                                                                 // 244
		optional: true                                                                                                       // 245
	},                                                                                                                    // 242
	"date": {                                                                                                             // 247
		type: SCHEMA._date,                                                                                                  // 248
		// Nom du schema visé                                                                                                // 249
		doc: "_date",                                                                                                        // 250
		label: "Date de l'évènement",                                                                                        // 251
		optional: true                                                                                                       // 252
	},                                                                                                                    // 247
	"commune": {                                                                                                          // 254
		type: String,                                                                                                        // 255
		label: "Commune d'habitation",                                                                                       // 256
		regEx: /[0-9a-zA-Z]{17}$/,                                                                                           // 257
		optional: true                                                                                                       // 258
	},                                                                                                                    // 254
	"lieudit": {                                                                                                          // 260
		type: String,                                                                                                        // 261
		label: "Lieu-dit d'habitation",                                                                                      // 262
		regEx: /[0-9a-zA-Z]{17}$/,                                                                                           // 263
		optional: true                                                                                                       // 264
	},                                                                                                                    // 260
	"docs": {                                                                                                             // 266
		type: Array,                                                                                                         // 267
		label: "Référence des actes",                                                                                        // 268
		optional: true                                                                                                       // 269
	},                                                                                                                    // 266
	"docs.$": {                                                                                                           // 271
		type: String,                                                                                                        // 272
		regEx: /[0-9a-zA-Z]{17}$/                                                                                            // 273
	},                                                                                                                    // 271
	"permaLiens": {                                                                                                       // 275
		type: Array,                                                                                                         // 276
		label: "Permaliens",                                                                                                 // 277
		optional: true                                                                                                       // 278
	},                                                                                                                    // 275
	"permaLiens.$": {                                                                                                     // 280
		type: String,                                                                                                        // 281
		label: "Permaliens"                                                                                                  // 282
	}                                                                                                                     // 280
}, {                                                                                                                   // 241
	tracker: Tracker                                                                                                      // 284
}); // ==============================================                                                                  // 284
// decoupe (de document de codage IMAGE)                                                                               // 287
// ==============================================                                                                      // 288
                                                                                                                       //
SCHEMA._decoupe = new SimpleSchema({                                                                                   // 289
	"docId": {                                                                                                            // 290
		type: String,                                                                                                        // 291
		label: "ID du document à découper",                                                                                  // 292
		regEx: /[0-9a-zA-Z]{17}$/,                                                                                           // 293
		optional: false                                                                                                      // 294
	},                                                                                                                    // 290
	"docPage": {                                                                                                          // 296
		type: SimpleSchema.Integer,                                                                                          // 297
		label: "Page du document à découper",                                                                                // 298
		optional: false                                                                                                      // 299
	},                                                                                                                    // 296
	"ratioWidthOverHeight": {                                                                                             // 301
		type: Number,                                                                                                        // 302
		label: "Ration largeur/hauteur de la découpe",                                                                       // 303
		optional: false                                                                                                      // 304
	},                                                                                                                    // 301
	"targetWidth": {                                                                                                      // 306
		type: Number,                                                                                                        // 307
		label: "Nombre de pixels de l'image rendue",                                                                         // 308
		optional: false                                                                                                      // 309
	},                                                                                                                    // 306
	"x": {                                                                                                                // 311
		type: Number,                                                                                                        // 312
		label: "Position x du début de la découpe",                                                                          // 313
		optional: false                                                                                                      // 314
	},                                                                                                                    // 311
	"y": {                                                                                                                // 316
		type: Number,                                                                                                        // 317
		label: "Position y du début de la découpe",                                                                          // 318
		optional: false                                                                                                      // 319
	},                                                                                                                    // 316
	"width": {                                                                                                            // 321
		type: Number,                                                                                                        // 322
		label: "Largeur de la découpe",                                                                                      // 323
		optional: false                                                                                                      // 324
	}                                                                                                                     // 321
}, {                                                                                                                   // 289
	tracker: Tracker                                                                                                      // 326
}); // ==============================================                                                                  // 326
// registre                                                                                                            // 329
// ==============================================                                                                      // 330
                                                                                                                       //
SCHEMA.registre = new SimpleSchema({                                                                                   // 331
	"id": {                                                                                                               // 332
		type: String,                                                                                                        // 333
		label: "Ancien ID",                                                                                                  // 334
		optional: true                                                                                                       // 335
	},                                                                                                                    // 332
	"type": {                                                                                                             // 337
		type: String,                                                                                                        // 338
		label: "Type",                                                                                                       // 339
		allowedValues: SCHEMA_allowedValues("typesRegistres"),                                                               // 340
		autoform: {                                                                                                          // 341
			options: SCHEMA_options("typesRegistres"),                                                                          // 342
			afFieldInput: {                                                                                                     // 343
				firstOption: "- choisir un type"                                                                                   // 344
			}                                                                                                                   // 343
		},                                                                                                                   // 341
		optional: false                                                                                                      // 347
	},                                                                                                                    // 337
	"contenu": {                                                                                                          // 349
		type: String,                                                                                                        // 350
		label: "Types d'actes contenus",                                                                                     // 351
		optional: false                                                                                                      // 352
	},                                                                                                                    // 349
	"periode": {                                                                                                          // 354
		type: String,                                                                                                        // 355
		label: "Années de début-fin",                                                                                        // 356
		optional: false                                                                                                      // 357
	},                                                                                                                    // 354
	"commune": {                                                                                                          // 359
		type: String,                                                                                                        // 360
		label: "Référence de la commune",                                                                                    // 361
		optional: false                                                                                                      // 362
	},                                                                                                                    // 359
	"nbPages": {                                                                                                          // 364
		type: SimpleSchema.Integer,                                                                                          // 365
		label: "Nombre de pages",                                                                                            // 366
		optional: true                                                                                                       // 367
	},                                                                                                                    // 364
	"ordreParCommune": {                                                                                                  // 369
		type: SimpleSchema.Integer,                                                                                          // 370
		label: "Ordre du registre dans la commune",                                                                          // 371
		optional: false                                                                                                      // 372
	},                                                                                                                    // 369
	"createdBy": {                                                                                                        // 374
		type: String,                                                                                                        // 375
		label: "Créé par",                                                                                                   // 376
		optional: true,                                                                                                      // 377
		// Force value to the creator id at creation, not modified after                                                     // 378
		autoValue: function () {                                                                                             // 379
			if (this.isInsert) return this.userId || idAdministrateurAppli;else this.unset();                                   // 380
		}                                                                                                                    // 382
	},                                                                                                                    // 374
	"createdAt": {                                                                                                        // 384
		type: Date,                                                                                                          // 385
		label: "Créé le",                                                                                                    // 386
		optional: false,                                                                                                     // 387
		// Force value to be current date (on server) upon insert                                                            // 388
		autoValue: function () {                                                                                             // 389
			if (this.isInsert) return new Date();else this.unset();                                                             // 390
		}                                                                                                                    // 392
	},                                                                                                                    // 384
	"lastUpdateAt": {                                                                                                     // 394
		type: Date,                                                                                                          // 395
		label: "Dernière modif. le",                                                                                         // 396
		optional: false,                                                                                                     // 397
		// Force value to be current date (on server) upon insert                                                            // 398
		autoValue: function () {                                                                                             // 399
			if (this.isInsert) return new Date();                                                                               // 400
			if (this.isUpdate) return new Date();                                                                               // 401
		}                                                                                                                    // 402
	}                                                                                                                     // 394
}, {                                                                                                                   // 331
	tracker: Tracker                                                                                                      // 404
}); // ==============================================                                                                  // 404
// objetGen                                                                                                            // 407
// ==============================================                                                                      // 408
                                                                                                                       //
SCHEMA._objetGen = new SimpleSchema({                                                                                  // 409
	"id": {                                                                                                               // 410
		type: String,                                                                                                        // 411
		label: "ID de l'objet Gen",                                                                                          // 412
		regEx: /[0-9a-zA-Z]{17}$/,                                                                                           // 413
		optional: false                                                                                                      // 414
	},                                                                                                                    // 410
	"type": {                                                                                                             // 416
		type: String,                                                                                                        // 417
		label: "Type de l'objet Gen",                                                                                        // 418
		allowedValues: SCHEMA_allowedValues("typesObjetsGen"),                                                               // 419
		autoform: {                                                                                                          // 420
			options: SCHEMA_options("typesObjetsGen"),                                                                          // 421
			afFieldInput: {                                                                                                     // 422
				firstOption: "- choisir un type"                                                                                   // 423
			}                                                                                                                   // 422
		},                                                                                                                   // 420
		optional: false                                                                                                      // 426
	}                                                                                                                     // 416
}, {                                                                                                                   // 409
	tracker: Tracker                                                                                                      // 428
}); // ==============================================                                                                  // 428
// lien                                                                                                                // 431
// ==============================================                                                                      // 432
                                                                                                                       //
SCHEMA.lien = new SimpleSchema({                                                                                       // 433
	"pour": {                                                                                                             // 434
		type: SCHEMA._objetGen,                                                                                              // 435
		// Nom du schema visé                                                                                                // 436
		doc: "_objetGen",                                                                                                    // 437
		label: "Objet depuis lequel il y a un lien",                                                                         // 438
		optional: false                                                                                                      // 439
	},                                                                                                                    // 434
	"vers": {                                                                                                             // 441
		type: SCHEMA._objetGen,                                                                                              // 442
		// Nom du schema visé                                                                                                // 443
		doc: "_objetGen",                                                                                                    // 444
		label: "Objets vers lesquels il y a un lien",                                                                        // 445
		optional: true                                                                                                       // 446
	},                                                                                                                    // 441
	"zone": {                                                                                                             // 448
		type: String,                                                                                                        // 449
		label: "type de zone",                                                                                               // 450
		allowedValues: SCHEMA_allowedValues("typesZonesLien"),                                                               // 451
		autoform: {                                                                                                          // 452
			options: SCHEMA_options("typesZonesLien"),                                                                          // 453
			afFieldInput: {                                                                                                     // 454
				firstOption: false                                                                                                 // 455
			}                                                                                                                   // 454
		},                                                                                                                   // 452
		optional: false                                                                                                      // 458
	},                                                                                                                    // 448
	"comment": {                                                                                                          // 460
		type: String,                                                                                                        // 461
		label: "Commentaire",                                                                                                // 462
		optional: true                                                                                                       // 463
	},                                                                                                                    // 460
	"createdBy": {                                                                                                        // 465
		type: String,                                                                                                        // 466
		label: "Créé par",                                                                                                   // 467
		optional: true,                                                                                                      // 468
		// Force value to the creator id at creation, not modified after                                                     // 469
		autoValue: function () {                                                                                             // 470
			if (this.isInsert) return this.userId || idAdministrateurAppli;else this.unset();                                   // 471
		}                                                                                                                    // 473
	},                                                                                                                    // 465
	"createdAt": {                                                                                                        // 475
		type: Date,                                                                                                          // 476
		label: "Créé le",                                                                                                    // 477
		optional: false,                                                                                                     // 478
		// Force value to be current date (on server) upon insert                                                            // 479
		autoValue: function () {                                                                                             // 480
			if (this.isInsert) return new Date();else this.unset();                                                             // 481
		}                                                                                                                    // 483
	},                                                                                                                    // 475
	"lastUpdateAt": {                                                                                                     // 485
		type: Date,                                                                                                          // 486
		label: "Dernière modif. le",                                                                                         // 487
		optional: false,                                                                                                     // 488
		// Force value to be current date (on server) upon insert                                                            // 489
		autoValue: function () {                                                                                             // 490
			if (this.isInsert) return new Date();                                                                               // 491
			if (this.isUpdate) return new Date();                                                                               // 492
		}                                                                                                                    // 493
	},                                                                                                                    // 485
	// Optionnel selon type de zone ---------------------                                                                 // 495
	// CERCLE                                                                                                             // 496
	"CIRCLE_centreX": {                                                                                                   // 497
		type: Number,                                                                                                        // 498
		label: "X centre",                                                                                                   // 499
		optional: true                                                                                                       // 500
	},                                                                                                                    // 497
	"CIRCLE_centreY": {                                                                                                   // 502
		type: Number,                                                                                                        // 503
		label: "Y centre",                                                                                                   // 504
		optional: true                                                                                                       // 505
	},                                                                                                                    // 502
	"CIRCLE_rayon": {                                                                                                     // 507
		type: Number,                                                                                                        // 508
		label: "rayon",                                                                                                      // 509
		optional: true                                                                                                       // 510
	},                                                                                                                    // 507
	"CIRCLE_page": {                                                                                                      // 512
		type: SimpleSchema.Integer,                                                                                          // 513
		label: "Page",                                                                                                       // 514
		optional: true                                                                                                       // 515
	},                                                                                                                    // 512
	// RECT                                                                                                               // 517
	"RECT_x": {                                                                                                           // 518
		type: Number,                                                                                                        // 519
		label: "X",                                                                                                          // 520
		optional: true                                                                                                       // 521
	},                                                                                                                    // 518
	"RECT_y": {                                                                                                           // 523
		type: Number,                                                                                                        // 524
		label: "Y",                                                                                                          // 525
		optional: true                                                                                                       // 526
	},                                                                                                                    // 523
	"RECT_width": {                                                                                                       // 528
		type: Number,                                                                                                        // 529
		label: "Largeur",                                                                                                    // 530
		optional: true                                                                                                       // 531
	},                                                                                                                    // 528
	"RECT_height": {                                                                                                      // 533
		type: Number,                                                                                                        // 534
		label: "Hauteur",                                                                                                    // 535
		optional: true                                                                                                       // 536
	},                                                                                                                    // 533
	"RECT_page": {                                                                                                        // 538
		type: SimpleSchema.Integer,                                                                                          // 539
		label: "Page",                                                                                                       // 540
		optional: true                                                                                                       // 541
	},                                                                                                                    // 538
	// POINT                                                                                                              // 543
	"POINT_x": {                                                                                                          // 544
		type: SimpleSchema.Integer,                                                                                          // 545
		label: "X",                                                                                                          // 546
		optional: true                                                                                                       // 547
	},                                                                                                                    // 544
	"POINT_y": {                                                                                                          // 549
		type: SimpleSchema.Integer,                                                                                          // 550
		label: "Y",                                                                                                          // 551
		optional: true                                                                                                       // 552
	},                                                                                                                    // 549
	"POINT_px": {                                                                                                         // 554
		type: Number,                                                                                                        // 555
		label: "pixels en X",                                                                                                // 556
		optional: true                                                                                                       // 557
	},                                                                                                                    // 554
	"POINT_py": {                                                                                                         // 559
		type: Number,                                                                                                        // 560
		label: "pixels en Y",                                                                                                // 561
		optional: true                                                                                                       // 562
	},                                                                                                                    // 559
	// PDF                                                                                                                // 564
	"PDF_page": {                                                                                                         // 565
		type: SimpleSchema.Integer,                                                                                          // 566
		label: "Page",                                                                                                       // 567
		optional: true                                                                                                       // 568
	},                                                                                                                    // 565
	// Extrait                                                                                                            // 570
	"RECORDING_startTS": {                                                                                                // 571
		type: SimpleSchema.Integer,                                                                                          // 572
		label: "TS de début",                                                                                                // 573
		optional: true                                                                                                       // 574
	},                                                                                                                    // 571
	"RECORDING_endTS": {                                                                                                  // 576
		type: SimpleSchema.Integer,                                                                                          // 577
		label: "TS de fin",                                                                                                  // 578
		optional: true                                                                                                       // 579
	} // --------------------------------------------------------                                                         // 576
	/*                                                                                                                    // 583
                                                                                                                       //
 // Attributs selon codage (aucun attribut pour "TOUT")                                                                //
 CERCLE_centreX                                                                                                        //
 CERCLE_centreY                                                                                                        //
 CERCLE_rayon                                                                                                          //
 EXTRAIT_tsDebut                                                                                                       //
 EXTRAIT_tsFin                                                                                                         //
 PDF_page                                                                                                              //
 */                                                                                                                    //
}, {                                                                                                                   // 433
	tracker: Tracker                                                                                                      // 594
}); // ==============================================                                                                  // 594
// pers                                                                                                                // 597
// ==============================================                                                                      // 598
                                                                                                                       //
SCHEMA.pers = new SimpleSchema({                                                                                       // 599
	"id": {                                                                                                               // 600
		type: String,                                                                                                        // 601
		label: "Ancien ID de la personne",                                                                                   // 602
		optional: true                                                                                                       // 603
	},                                                                                                                    // 600
	"tags": {                                                                                                             // 605
		type: Array,                                                                                                         // 606
		label: "Référence des étiquettes",                                                                                   // 607
		optional: true                                                                                                       // 608
	},                                                                                                                    // 605
	"tags.$": {                                                                                                           // 610
		type: String,                                                                                                        // 611
		label: "Etiquettes",                                                                                                 // 612
		autoform: {                                                                                                          // 613
			options: function () {                                                                                              // 614
				return Tags.find({                                                                                                 // 615
					objTypes: "PERS"                                                                                                  // 615
				}, {                                                                                                               // 615
					sort: {                                                                                                           // 615
						label: 1                                                                                                         // 615
					}                                                                                                                 // 615
				}).map(function (obj) {                                                                                            // 615
					return {                                                                                                          // 616
						label: obj.label,                                                                                                // 616
						value: obj._id                                                                                                   // 616
					};                                                                                                                // 616
				});                                                                                                                // 617
			},                                                                                                                  // 618
			afFieldInput: {                                                                                                     // 619
				firstOption: "- choisir une étiquette"                                                                             // 620
			}                                                                                                                   // 619
		}                                                                                                                    // 613
	},                                                                                                                    // 610
	"sexe": {                                                                                                             // 624
		type: String,                                                                                                        // 625
		label: "Sexe (*)",                                                                                                   // 626
		allowedValues: SCHEMA_allowedValues("sexes"),                                                                        // 627
		autoform: {                                                                                                          // 628
			options: SCHEMA_options("sexes"),                                                                                   // 629
			afFieldInput: {                                                                                                     // 630
				firstOption: "- choisir un sexe"                                                                                   // 631
			}                                                                                                                   // 630
		},                                                                                                                   // 628
		optional: false                                                                                                      // 634
	},                                                                                                                    // 624
	"photo": {                                                                                                            // 636
		type: SCHEMA._decoupe,                                                                                               // 637
		// Nom du schema visé                                                                                                // 638
		doc: "_decoupe",                                                                                                     // 639
		label: "Découpe de la photo",                                                                                        // 640
		optional: true                                                                                                       // 641
	},                                                                                                                    // 636
	"nom": {                                                                                                              // 643
		type: String,                                                                                                        // 644
		label: "Nom (*)",                                                                                                    // 645
		regEx: /^\?$|^[A-Z\s\\?']*$/,                                                                                        // 646
		// caractères autorisés : lettre, ?, ', " "                                                                          // 646
		optional: false                                                                                                      // 647
	},                                                                                                                    // 643
	"prenoms": {                                                                                                          // 649
		type: Array,                                                                                                         // 650
		label: "Prénoms (selon ordre naissance) (*)",                                                                        // 651
		optional: false                                                                                                      // 652
	},                                                                                                                    // 649
	"prenoms.$": {                                                                                                        // 654
		type: String                                                                                                         // 655
	},                                                                                                                    // 654
	"prenomUsuel": {                                                                                                      // 657
		type: SimpleSchema.Integer,                                                                                          // 658
		label: "Index du prénom usuel (0=1er, 1=2nd...) (*)",                                                                // 659
		optional: false,                                                                                                     // 660
		autoform: {                                                                                                          // 661
			defaultValue: 0                                                                                                     // 662
		}                                                                                                                    // 661
	},                                                                                                                    // 657
	"prenomUsuelEstNonOfficiel": {                                                                                        // 665
		type: Boolean,                                                                                                       // 666
		label: "Le prénom usuel est non officiel",                                                                           // 667
		optional: false                                                                                                      // 668
	},                                                                                                                    // 665
	"estVivant": {                                                                                                        // 670
		type: Boolean,                                                                                                       // 671
		label: "Est vivant",                                                                                                 // 672
		optional: true                                                                                                       // 673
	},                                                                                                                    // 670
	"estCelibataire": {                                                                                                   // 675
		type: Boolean,                                                                                                       // 676
		label: "Est célibataire",                                                                                            // 677
		optional: true                                                                                                       // 678
	},                                                                                                                    // 675
	"pere": {                                                                                                             // 680
		type: String,                                                                                                        // 681
		label: "Référence du père",                                                                                          // 682
		regEx: /[0-9a-zA-Z]{17}$/,                                                                                           // 683
		optional: true                                                                                                       // 684
	},                                                                                                                    // 680
	"pereIncertain": {                                                                                                    // 686
		type: Boolean,                                                                                                       // 687
		label: "Père incertain",                                                                                             // 688
		optional: true                                                                                                       // 689
	},                                                                                                                    // 686
	"mere": {                                                                                                             // 691
		type: String,                                                                                                        // 692
		label: "Référence de la mère",                                                                                       // 693
		regEx: /[0-9a-zA-Z]{17}$/,                                                                                           // 694
		optional: true                                                                                                       // 695
	},                                                                                                                    // 691
	"mereIncertain": {                                                                                                    // 697
		type: Boolean,                                                                                                       // 698
		label: "Mère incertaine",                                                                                            // 699
		optional: true                                                                                                       // 700
	},                                                                                                                    // 697
	"naissance": {                                                                                                        // 702
		type: SCHEMA._acte,                                                                                                  // 703
		// Nom du schema visé                                                                                                // 704
		doc: "_acte",                                                                                                        // 705
		label: "Naissance",                                                                                                  // 706
		optional: true                                                                                                       // 707
	},                                                                                                                    // 702
	"deces": {                                                                                                            // 709
		type: SCHEMA._acte,                                                                                                  // 710
		// Nom du schema visé                                                                                                // 711
		doc: "_acte",                                                                                                        // 712
		label: "Décès",                                                                                                      // 713
		optional: true                                                                                                       // 714
	},                                                                                                                    // 709
	"comment": {                                                                                                          // 716
		type: String,                                                                                                        // 717
		label: "Commentaires",                                                                                               // 718
		optional: true                                                                                                       // 719
	},                                                                                                                    // 716
	"recherche": {                                                                                                        // 721
		type: String,                                                                                                        // 722
		label: "Commentaires de recherche",                                                                                  // 723
		optional: true                                                                                                       // 724
	},                                                                                                                    // 721
	"etatRechActes": {                                                                                                    // 726
		type: String,                                                                                                        // 727
		label: "Etat de recherche des actes",                                                                                // 728
		allowedValues: SCHEMA_allowedValues("typeEtatRechActes"),                                                            // 729
		autoform: {                                                                                                          // 730
			options: SCHEMA_options("typeEtatRechActes"),                                                                       // 731
			afFieldInput: {                                                                                                     // 732
				firstOption: false                                                                                                 // 733
			}                                                                                                                   // 732
		},                                                                                                                   // 730
		optional: false                                                                                                      // 736
	},                                                                                                                    // 726
	"createdBy": {                                                                                                        // 738
		type: String,                                                                                                        // 739
		label: "Créé par",                                                                                                   // 740
		optional: true,                                                                                                      // 741
		// Force value to the creator id at creation, not modified after                                                     // 742
		autoValue: function () {                                                                                             // 743
			if (this.isInsert) return this.userId || idAdministrateurAppli;else this.unset();                                   // 744
		}                                                                                                                    // 746
	},                                                                                                                    // 738
	"createdAt": {                                                                                                        // 748
		type: Date,                                                                                                          // 749
		label: "Créé le",                                                                                                    // 750
		optional: false,                                                                                                     // 751
		// Force value to be current date (on server) upon insert                                                            // 752
		autoValue: function () {                                                                                             // 753
			if (this.isInsert) return new Date();else this.unset();                                                             // 754
		}                                                                                                                    // 756
	},                                                                                                                    // 748
	"lastUpdateAt": {                                                                                                     // 758
		type: Date,                                                                                                          // 759
		label: "Dernière modif. le",                                                                                         // 760
		optional: false,                                                                                                     // 761
		// Force value to be current date (on server) upon insert                                                            // 762
		autoValue: function () {                                                                                             // 763
			if (this.isInsert) return new Date();                                                                               // 764
			if (this.isUpdate) return new Date();                                                                               // 765
		} // A rajouter : "probable" !                                                                                       // 766
                                                                                                                       //
	}                                                                                                                     // 758
}, {                                                                                                                   // 599
	tracker: Tracker                                                                                                      // 770
}); // ==============================================                                                                  // 770
// couple (Mariage, divorce, pacs...)                                                                                  // 773
// ==============================================                                                                      // 774
                                                                                                                       //
SCHEMA.coupleEvent = new SimpleSchema({                                                                                // 775
	"type": {                                                                                                             // 776
		type: String,                                                                                                        // 777
		label: "Type de l'évènement",                                                                                        // 778
		allowedValues: SCHEMA_allowedValues("coupleEventType"),                                                              // 779
		autoform: {                                                                                                          // 780
			options: SCHEMA_options("coupleEventType"),                                                                         // 781
			afFieldInput: {                                                                                                     // 782
				firstOption: false                                                                                                 // 783
			}                                                                                                                   // 782
		},                                                                                                                   // 780
		optional: false                                                                                                      // 786
	},                                                                                                                    // 776
	"date": {                                                                                                             // 788
		type: SCHEMA._date,                                                                                                  // 789
		// Nom du schema visé                                                                                                // 790
		doc: "_date",                                                                                                        // 791
		label: "Date de l'évènement",                                                                                        // 792
		optional: true                                                                                                       // 793
	},                                                                                                                    // 788
	"persA": {                                                                                                            // 795
		type: String,                                                                                                        // 796
		label: "Entre personne A",                                                                                           // 797
		regEx: /[0-9a-zA-Z]{17}$/,                                                                                           // 798
		optional: false                                                                                                      // 799
	},                                                                                                                    // 795
	"communeA": {                                                                                                         // 801
		type: String,                                                                                                        // 802
		label: "Habitant commune A",                                                                                         // 803
		regEx: /[0-9a-zA-Z]{17}$/,                                                                                           // 804
		optional: true                                                                                                       // 805
	},                                                                                                                    // 801
	"lieuditA": {                                                                                                         // 807
		type: String,                                                                                                        // 808
		label: "Habitant lieu-dit A",                                                                                        // 809
		regEx: /[0-9a-zA-Z]{17}$/,                                                                                           // 810
		optional: true                                                                                                       // 811
	},                                                                                                                    // 807
	"incertainA": {                                                                                                       // 813
		type: Boolean,                                                                                                       // 814
		label: "Données incertaines",                                                                                        // 815
		optional: true                                                                                                       // 816
	},                                                                                                                    // 813
	"persB": {                                                                                                            // 818
		type: String,                                                                                                        // 819
		label: "Et personne B",                                                                                              // 820
		regEx: /[0-9a-zA-Z]{17}$/,                                                                                           // 821
		optional: false                                                                                                      // 822
	},                                                                                                                    // 818
	"communeB": {                                                                                                         // 824
		type: String,                                                                                                        // 825
		label: "Habitant commune B",                                                                                         // 826
		regEx: /[0-9a-zA-Z]{17}$/,                                                                                           // 827
		optional: true                                                                                                       // 828
	},                                                                                                                    // 824
	"lieuditB": {                                                                                                         // 830
		type: String,                                                                                                        // 831
		label: "Habitant lieu-dit B",                                                                                        // 832
		regEx: /[0-9a-zA-Z]{17}$/,                                                                                           // 833
		optional: true                                                                                                       // 834
	},                                                                                                                    // 830
	"incertainB": {                                                                                                       // 836
		type: Boolean,                                                                                                       // 837
		label: "Données incertaines",                                                                                        // 838
		optional: true                                                                                                       // 839
	},                                                                                                                    // 836
	"docs": {                                                                                                             // 841
		type: Array,                                                                                                         // 842
		label: "Référence des actes",                                                                                        // 843
		optional: true                                                                                                       // 844
	},                                                                                                                    // 841
	"docs.$": {                                                                                                           // 846
		type: String,                                                                                                        // 847
		regEx: /[0-9a-zA-Z]{17}$/                                                                                            // 848
	},                                                                                                                    // 846
	"permaLiens": {                                                                                                       // 850
		type: Array,                                                                                                         // 851
		label: "Permaliens",                                                                                                 // 852
		optional: true                                                                                                       // 853
	},                                                                                                                    // 850
	"permaLiens.$": {                                                                                                     // 855
		type: String,                                                                                                        // 856
		label: "Permaliens"                                                                                                  // 857
	},                                                                                                                    // 855
	"comment": {                                                                                                          // 859
		type: String,                                                                                                        // 860
		label: "Commentaires",                                                                                               // 861
		optional: true                                                                                                       // 862
	},                                                                                                                    // 859
	"recherche": {                                                                                                        // 864
		type: String,                                                                                                        // 865
		label: "Commentaires de recherche",                                                                                  // 866
		optional: true                                                                                                       // 867
	},                                                                                                                    // 864
	"etatRechEnfants": {                                                                                                  // 869
		type: String,                                                                                                        // 870
		label: "Etat de recherche des enfants",                                                                              // 871
		allowedValues: SCHEMA_allowedValues("typeEtatRechEnfants"),                                                          // 872
		autoform: {                                                                                                          // 873
			options: SCHEMA_options("typeEtatRechEnfants"),                                                                     // 874
			afFieldInput: {                                                                                                     // 875
				firstOption: false                                                                                                 // 876
			}                                                                                                                   // 875
		},                                                                                                                   // 873
		optional: false                                                                                                      // 879
	},                                                                                                                    // 869
	"createdBy": {                                                                                                        // 881
		type: String,                                                                                                        // 882
		label: "Créé par",                                                                                                   // 883
		optional: true,                                                                                                      // 884
		// Force value to the creator id at creation, not modified after                                                     // 885
		autoValue: function () {                                                                                             // 886
			if (this.isInsert) return this.userId || idAdministrateurAppli;else this.unset();                                   // 887
		}                                                                                                                    // 889
	},                                                                                                                    // 881
	"createdAt": {                                                                                                        // 891
		type: Date,                                                                                                          // 892
		label: "Créé le",                                                                                                    // 893
		optional: false,                                                                                                     // 894
		// Force value to be current date (on server) upon insert                                                            // 895
		autoValue: function () {                                                                                             // 896
			if (this.isInsert) return new Date();else this.unset();                                                             // 897
		}                                                                                                                    // 899
	},                                                                                                                    // 891
	"lastUpdateAt": {                                                                                                     // 901
		type: Date,                                                                                                          // 902
		label: "Dernière modif. le",                                                                                         // 903
		optional: false,                                                                                                     // 904
		// Force value to be current date (on server) upon insert                                                            // 905
		autoValue: function () {                                                                                             // 906
			if (this.isInsert) return new Date();                                                                               // 907
			if (this.isUpdate) return new Date();                                                                               // 908
		}                                                                                                                    // 909
	}                                                                                                                     // 901
}, {                                                                                                                   // 775
	tracker: Tracker                                                                                                      // 911
}); // ==============================================                                                                  // 911
// lieu                                                                                                                // 914
// ==============================================                                                                      // 915
                                                                                                                       //
SCHEMA.lieu = new SimpleSchema({                                                                                       // 916
	"id": {                                                                                                               // 917
		type: String,                                                                                                        // 918
		label: "Id",                                                                                                         // 919
		optional: true // présent uniquement sur le légacy                                                                   // 920
                                                                                                                       //
	},                                                                                                                    // 917
	"tags": {                                                                                                             // 922
		type: Array,                                                                                                         // 923
		label: "Référence des étiquettes",                                                                                   // 924
		optional: true                                                                                                       // 925
	},                                                                                                                    // 922
	"tags.$": {                                                                                                           // 927
		type: String,                                                                                                        // 928
		label: "Etiquettes",                                                                                                 // 929
		autoform: {                                                                                                          // 930
			options: function () {                                                                                              // 931
				return Tags.find({                                                                                                 // 932
					objTypes: "LIEU"                                                                                                  // 932
				}, {                                                                                                               // 932
					sort: {                                                                                                           // 932
						label: 1                                                                                                         // 932
					}                                                                                                                 // 932
				}).map(function (obj) {                                                                                            // 932
					return {                                                                                                          // 933
						label: obj.label,                                                                                                // 933
						value: obj._id                                                                                                   // 933
					};                                                                                                                // 933
				});                                                                                                                // 934
			},                                                                                                                  // 935
			afFieldInput: {                                                                                                     // 936
				firstOption: "- choisir une étiquette"                                                                             // 937
			}                                                                                                                   // 936
		}                                                                                                                    // 930
	},                                                                                                                    // 927
	"nature": {                                                                                                           // 941
		type: String,                                                                                                        // 942
		label: "Nature",                                                                                                     // 943
		allowedValues: SCHEMA_allowedValues("typesLieux"),                                                                   // 944
		autoform: {                                                                                                          // 945
			options: SCHEMA_options("typesLieux"),                                                                              // 946
			afFieldInput: {                                                                                                     // 947
				firstOption: "- choisir un type"                                                                                   // 948
			}                                                                                                                   // 947
		},                                                                                                                   // 945
		optional: false                                                                                                      // 951
	},                                                                                                                    // 941
	"genre": {                                                                                                            // 953
		type: String,                                                                                                        // 954
		label: "Genre",                                                                                                      // 955
		allowedValues: SCHEMA_allowedValues("genresLieux"),                                                                  // 956
		autoform: {                                                                                                          // 957
			options: SCHEMA_options("genresLieux"),                                                                             // 958
			afFieldInput: {                                                                                                     // 959
				firstOption: "- choisir un genre"                                                                                  // 960
			}                                                                                                                   // 959
		},                                                                                                                   // 957
		optional: false                                                                                                      // 963
	},                                                                                                                    // 953
	"nom": {                                                                                                              // 965
		type: String,                                                                                                        // 966
		label: "Nom",                                                                                                        // 967
		optional: false                                                                                                      // 968
	},                                                                                                                    // 965
	"complement": {                                                                                                       // 970
		type: String,                                                                                                        // 971
		label: "Information complémentaire discriminante",                                                                   // 972
		optional: true                                                                                                       // 973
	},                                                                                                                    // 970
	"code": {                                                                                                             // 975
		type: String,                                                                                                        // 976
		label: "Code administratif",                                                                                         // 977
		optional: true                                                                                                       // 978
	},                                                                                                                    // 975
	"topoComment": {                                                                                                      // 980
		type: String,                                                                                                        // 981
		label: "Commentaire de toponymie",                                                                                   // 982
		optional: true                                                                                                       // 983
	},                                                                                                                    // 980
	"topoFamille": {                                                                                                      // 985
		type: String,                                                                                                        // 986
		label: "Famille de toponymie",                                                                                       // 987
		optional: true                                                                                                       // 988
	},                                                                                                                    // 985
	"inclusDans": {                                                                                                       // 990
		type: String,                                                                                                        // 991
		label: "Lieu parent",                                                                                                // 992
		regEx: /[0-9a-zA-Z]{17}$/,                                                                                           // 993
		optional: false // Pour vérifier la compatibilité lieu/surlieu                                                       // 994
		// ?????????????????????????????????????????????                                                                     // 997
		/* DESACTIVE : poser problème à l'initialisation                                                                     // 998
  // ?????????????????????????????????????????????                                                                     //
                                                                                                                       //
  custom: function () {                                                                                                //
  	//??????????????????????????                                                                                        //
  	// Condition à compléter                                                                                            //
  	//??????????????????????????                                                                                        //
  	var lieuParent = Lieux.findOne({_id:this.value});                                                                   //
  	// Erreur si les deux types sont identiques, à tester l'inclusion possible d'un lieu dans un autre                  //
  	if (this.field('nature').value === lieuParent.nature) 	return "invalidParentPlace";                                 //
  }                                                                                                                    //
  */                                                                                                                   //
	},                                                                                                                    // 990
	"latLng": {                                                                                                           // 1012
		type: SCHEMA._googleMap,                                                                                             // 1013
		// Nom du schema visé                                                                                                // 1014
		doc: "_googleMap",                                                                                                   // 1015
		label: "Positions Google Map",                                                                                       // 1016
		optional: true                                                                                                       // 1017
	},                                                                                                                    // 1012
	"positionSurCartes": {                                                                                                // 1019
		type: Array,                                                                                                         // 1020
		label: "Positions sur cartes",                                                                                       // 1021
		optional: true                                                                                                       // 1022
	},                                                                                                                    // 1019
	"positionSurCartes.$": {                                                                                              // 1024
		type: SCHEMA._positionCarte,                                                                                         // 1025
		// Nom du schema visé                                                                                                // 1026
		doc: "_positionCarte"                                                                                                // 1027
	},                                                                                                                    // 1024
	"comment": {                                                                                                          // 1029
		type: String,                                                                                                        // 1030
		label: "Commentaires",                                                                                               // 1031
		optional: true                                                                                                       // 1032
	},                                                                                                                    // 1029
	"recherche": {                                                                                                        // 1034
		type: String,                                                                                                        // 1035
		label: "Commentaires de recherche",                                                                                  // 1036
		optional: true                                                                                                       // 1037
	},                                                                                                                    // 1034
	"createdBy": {                                                                                                        // 1039
		type: String,                                                                                                        // 1040
		label: "Créé par",                                                                                                   // 1041
		optional: true,                                                                                                      // 1042
		// Force value to the creator id at creation, not modified after                                                     // 1043
		autoValue: function () {                                                                                             // 1044
			if (this.isInsert) return this.userId || idAdministrateurAppli;else this.unset();                                   // 1045
		}                                                                                                                    // 1047
	},                                                                                                                    // 1039
	"createdAt": {                                                                                                        // 1049
		type: Date,                                                                                                          // 1050
		label: "Créé le",                                                                                                    // 1051
		optional: false,                                                                                                     // 1052
		// Force value to be current date (on server) upon insert                                                            // 1053
		autoValue: function () {                                                                                             // 1054
			if (this.isInsert) return new Date();else this.unset();                                                             // 1055
		}                                                                                                                    // 1057
	},                                                                                                                    // 1049
	"lastUpdateAt": {                                                                                                     // 1059
		type: Date,                                                                                                          // 1060
		label: "Dernière modif. le",                                                                                         // 1061
		optional: false,                                                                                                     // 1062
		// Force value to be current date (on server) upon insert                                                            // 1063
		autoValue: function () {                                                                                             // 1064
			if (this.isInsert) return new Date();                                                                               // 1065
			if (this.isUpdate) return new Date();                                                                               // 1066
		}                                                                                                                    // 1067
	}                                                                                                                     // 1059
}, {                                                                                                                   // 916
	tracker: Tracker                                                                                                      // 1069
}); // ==============================================                                                                  // 1069
// hist                                                                                                                // 1072
// ==============================================                                                                      // 1073
                                                                                                                       //
SCHEMA.hist = new SimpleSchema({                                                                                       // 1074
	"id": {                                                                                                               // 1075
		type: String,                                                                                                        // 1076
		label: "Id ancienne version",                                                                                        // 1077
		optional: true // présent uniquement sur le légacy                                                                   // 1078
                                                                                                                       //
	},                                                                                                                    // 1075
	"tags": {                                                                                                             // 1080
		type: Array,                                                                                                         // 1081
		label: "Référence des étiquettes",                                                                                   // 1082
		optional: true                                                                                                       // 1083
	},                                                                                                                    // 1080
	"tags.$": {                                                                                                           // 1085
		type: String,                                                                                                        // 1086
		label: "Etiquettes",                                                                                                 // 1087
		autoform: {                                                                                                          // 1088
			options: function () {                                                                                              // 1089
				return Tags.find({                                                                                                 // 1090
					objTypes: "HIST"                                                                                                  // 1090
				}, {                                                                                                               // 1090
					sort: {                                                                                                           // 1090
						label: 1                                                                                                         // 1090
					}                                                                                                                 // 1090
				}).map(function (obj) {                                                                                            // 1090
					return {                                                                                                          // 1091
						label: obj.label,                                                                                                // 1091
						value: obj._id                                                                                                   // 1091
					};                                                                                                                // 1091
				});                                                                                                                // 1092
			},                                                                                                                  // 1093
			afFieldInput: {                                                                                                     // 1094
				firstOption: "- choisir une étiquette"                                                                             // 1095
			}                                                                                                                   // 1094
		}                                                                                                                    // 1088
	},                                                                                                                    // 1085
	"source": {                                                                                                           // 1099
		type: String,                                                                                                        // 1100
		label: "Source de l'information",                                                                                    // 1101
		optional: true                                                                                                       // 1102
	},                                                                                                                    // 1099
	"titre": {                                                                                                            // 1104
		type: String,                                                                                                        // 1105
		label: "Description courte du point d'histoire",                                                                     // 1106
		optional: false                                                                                                      // 1107
	},                                                                                                                    // 1104
	"date": {                                                                                                             // 1109
		type: SCHEMA._date,                                                                                                  // 1110
		// Nom du schema visé                                                                                                // 1111
		doc: "_date",                                                                                                        // 1112
		label: "Date du point d'histoire",                                                                                   // 1113
		optional: false                                                                                                      // 1114
	},                                                                                                                    // 1109
	"impacteAncetres": {                                                                                                  // 1116
		type: Boolean,                                                                                                       // 1117
		label: "Point d'histoire ayant probablement impacté mes ancêtres",                                                   // 1118
		optional: false                                                                                                      // 1119
	},                                                                                                                    // 1116
	// Obsolete : to be deleted when HISTS migrated                                                                       // 1121
	"zones": {                                                                                                            // 1122
		type: Array,                                                                                                         // 1123
		label: "Zones concernées par le point d'histoire",                                                                   // 1124
		allowedValues: SCHEMA_allowedValues("zonesHist"),                                                                    // 1125
		autoform: {                                                                                                          // 1126
			options: SCHEMA_options("zonesHist")                                                                                // 1127
		},                                                                                                                   // 1126
		optional: true                                                                                                       // 1129
	},                                                                                                                    // 1122
	"zones.$": {                                                                                                          // 1131
		type: String                                                                                                         // 1132
	},                                                                                                                    // 1131
	"scope": {                                                                                                            // 1134
		type: String,                                                                                                        // 1135
		label: "Impact de ce point d'histoire",                                                                              // 1136
		allowedValues: SCHEMA_allowedValues("scopesHist"),                                                                   // 1137
		autoform: {                                                                                                          // 1138
			options: SCHEMA_options("scopesHist"),                                                                              // 1139
			afFieldInput: {                                                                                                     // 1140
				firstOption: "- choisir l'impact"                                                                                  // 1141
			}                                                                                                                   // 1140
		},                                                                                                                   // 1138
		optional: false                                                                                                      // 1144
	},                                                                                                                    // 1134
	"themes": {                                                                                                           // 1146
		type: Array,                                                                                                         // 1147
		label: "Thèmes concernés par le point d'histoire",                                                                   // 1148
		allowedValues: SCHEMA_allowedValues("themesHist"),                                                                   // 1149
		autoform: {                                                                                                          // 1150
			options: SCHEMA_options("themesHist")                                                                               // 1151
		},                                                                                                                   // 1150
		optional: false                                                                                                      // 1153
	},                                                                                                                    // 1146
	"themes.$": {                                                                                                         // 1155
		type: String                                                                                                         // 1156
	},                                                                                                                    // 1155
	"comment": {                                                                                                          // 1158
		type: String,                                                                                                        // 1159
		label: "Commentaires sur le point d'histoire",                                                                       // 1160
		optional: true                                                                                                       // 1161
	},                                                                                                                    // 1158
	"recherche": {                                                                                                        // 1163
		type: String,                                                                                                        // 1164
		label: "Commentaires de recherche",                                                                                  // 1165
		optional: true                                                                                                       // 1166
	},                                                                                                                    // 1163
	"createdBy": {                                                                                                        // 1168
		type: String,                                                                                                        // 1169
		label: "Créé par",                                                                                                   // 1170
		optional: true,                                                                                                      // 1171
		// Force value to the creator id at creation, not modified after                                                     // 1172
		autoValue: function () {                                                                                             // 1173
			if (this.isInsert) return this.userId || idAdministrateurAppli;else this.unset();                                   // 1174
		}                                                                                                                    // 1176
	},                                                                                                                    // 1168
	"createdAt": {                                                                                                        // 1178
		type: Date,                                                                                                          // 1179
		label: "Créé le",                                                                                                    // 1180
		optional: false,                                                                                                     // 1181
		// Force value to be current date (on server) upon insert                                                            // 1182
		autoValue: function () {                                                                                             // 1183
			if (this.isInsert) return new Date();else this.unset();                                                             // 1184
		}                                                                                                                    // 1186
	},                                                                                                                    // 1178
	"lastUpdateAt": {                                                                                                     // 1188
		type: Date,                                                                                                          // 1189
		label: "Dernière modif. le",                                                                                         // 1190
		optional: false,                                                                                                     // 1191
		// Force value to be current date (on server) upon insert                                                            // 1192
		autoValue: function () {                                                                                             // 1193
			if (this.isInsert) return new Date();                                                                               // 1194
			if (this.isUpdate) return new Date();                                                                               // 1195
		}                                                                                                                    // 1196
	}                                                                                                                     // 1188
}, {                                                                                                                   // 1074
	tracker: Tracker                                                                                                      // 1198
}); // ==============================================                                                                  // 1198
// sourceDoc                                                                                                           // 1201
// ==============================================                                                                      // 1202
                                                                                                                       //
SCHEMA._sourceDoc = new SimpleSchema({                                                                                 // 1203
	"intitule": {                                                                                                         // 1204
		type: String,                                                                                                        // 1205
		label: "Intitulé",                                                                                                   // 1206
		optional: true,                                                                                                      // 1207
		autoform: {                                                                                                          // 1208
			defaultValue: "Archives départementales 85"                                                                         // 1209
		}                                                                                                                    // 1208
	},                                                                                                                    // 1204
	"id": {                                                                                                               // 1212
		type: String,                                                                                                        // 1213
		label: "Id de la source",                                                                                            // 1214
		optional: true                                                                                                       // 1215
	},                                                                                                                    // 1212
	"libreDeDroits": {                                                                                                    // 1217
		type: Boolean,                                                                                                       // 1218
		label: "Libre de droit",                                                                                             // 1219
		optional: true                                                                                                       // 1220
	}                                                                                                                     // 1217
}, {                                                                                                                   // 1203
	tracker: Tracker                                                                                                      // 1222
}); // ==============================================                                                                  // 1222
// tag                                                                                                                 // 1225
// ==============================================                                                                      // 1226
                                                                                                                       //
SCHEMA.tag = new SimpleSchema({                                                                                        // 1227
	"label": {                                                                                                            // 1228
		type: String,                                                                                                        // 1229
		label: "Etiquette",                                                                                                  // 1230
		optional: false                                                                                                      // 1231
	},                                                                                                                    // 1228
	"summary": {                                                                                                          // 1233
		type: String,                                                                                                        // 1234
		label: "Signification du tag",                                                                                       // 1235
		optional: false                                                                                                      // 1236
	},                                                                                                                    // 1233
	"imgFileName": {                                                                                                      // 1238
		type: String,                                                                                                        // 1239
		label: "Nom du fichier image associé au tag",                                                                        // 1240
		optional: true                                                                                                       // 1241
	},                                                                                                                    // 1238
	"objTypes": {                                                                                                         // 1243
		type: Array,                                                                                                         // 1244
		label: "Objets concernés",                                                                                           // 1245
		optional: false                                                                                                      // 1246
	},                                                                                                                    // 1243
	"objTypes.$": {                                                                                                       // 1248
		type: String,                                                                                                        // 1249
		label: "Objet concerné",                                                                                             // 1250
		allowedValues: SCHEMA_allowedValues("objTypesForTags"),                                                              // 1251
		autoform: {                                                                                                          // 1252
			options: SCHEMA_options("objTypesForTags"),                                                                         // 1253
			afFieldInput: {                                                                                                     // 1254
				firstOption: "- choisir l'objet concerné"                                                                          // 1255
			}                                                                                                                   // 1254
		}                                                                                                                    // 1252
	},                                                                                                                    // 1248
	"createdBy": {                                                                                                        // 1259
		type: String,                                                                                                        // 1260
		label: "Créé par",                                                                                                   // 1261
		optional: true,                                                                                                      // 1262
		// Force value to the creator id at creation, not modified after                                                     // 1263
		autoValue: function () {                                                                                             // 1264
			if (this.isInsert) return this.userId || idAdministrateurAppli;else this.unset();                                   // 1265
		}                                                                                                                    // 1267
	},                                                                                                                    // 1259
	"createdAt": {                                                                                                        // 1269
		type: Date,                                                                                                          // 1270
		label: "Créé le",                                                                                                    // 1271
		optional: false,                                                                                                     // 1272
		// Force value to be current date (on server) upon insert                                                            // 1273
		autoValue: function () {                                                                                             // 1274
			if (this.isInsert) return new Date();else this.unset();                                                             // 1275
		}                                                                                                                    // 1277
	},                                                                                                                    // 1269
	"lastUpdateAt": {                                                                                                     // 1279
		type: Date,                                                                                                          // 1280
		label: "Dernière modif. le",                                                                                         // 1281
		optional: false,                                                                                                     // 1282
		// Force value to be current date (on server) upon insert                                                            // 1283
		autoValue: function () {                                                                                             // 1284
			if (this.isInsert) return new Date();                                                                               // 1285
			if (this.isUpdate) return new Date();                                                                               // 1286
		}                                                                                                                    // 1287
	}                                                                                                                     // 1279
}, {                                                                                                                   // 1227
	tracker: Tracker                                                                                                      // 1289
}); // ==============================================                                                                  // 1289
// bug                                                                                                                 // 1292
// ==============================================                                                                      // 1293
                                                                                                                       //
SCHEMA.bug = new SimpleSchema({                                                                                        // 1294
	"type": {                                                                                                             // 1295
		type: String,                                                                                                        // 1296
		label: "Type",                                                                                                       // 1297
		optional: false,                                                                                                     // 1298
		autoform: {                                                                                                          // 1299
			options: SCHEMA_options("typeBugs"),                                                                                // 1300
			afFieldInput: {                                                                                                     // 1301
				firstOption: false                                                                                                 // 1302
			}                                                                                                                   // 1301
		}                                                                                                                    // 1299
	},                                                                                                                    // 1295
	"description": {                                                                                                      // 1306
		type: String,                                                                                                        // 1307
		label: "Description",                                                                                                // 1308
		optional: false                                                                                                      // 1309
	},                                                                                                                    // 1306
	"criticite": {                                                                                                        // 1311
		type: SimpleSchema.Integer,                                                                                          // 1312
		label: "Criticité",                                                                                                  // 1313
		optional: false,                                                                                                     // 1314
		min: 0,                                                                                                              // 1315
		max: 3,                                                                                                              // 1316
		autoform: {                                                                                                          // 1317
			options: SCHEMA_options("criticiteBugs"),                                                                           // 1318
			afFieldInput: {                                                                                                     // 1319
				firstOption: false                                                                                                 // 1320
			}                                                                                                                   // 1319
		}                                                                                                                    // 1317
	},                                                                                                                    // 1311
	"module": {                                                                                                           // 1324
		type: String,                                                                                                        // 1325
		label: "Module concerné",                                                                                            // 1326
		optional: true                                                                                                       // 1327
	},                                                                                                                    // 1324
	"estResolu": {                                                                                                        // 1329
		type: Boolean,                                                                                                       // 1330
		label: "Est résolu",                                                                                                 // 1331
		optional: false,                                                                                                     // 1332
		// Force value to be false (on server) upon insert                                                                   // 1333
		autoValue: function () {                                                                                             // 1334
			if (this.isInsert) return false;                                                                                    // 1335
		}                                                                                                                    // 1336
	},                                                                                                                    // 1329
	"dateCreation": {                                                                                                     // 1338
		type: Date,                                                                                                          // 1339
		label: "Date de création",                                                                                           // 1340
		optional: false,                                                                                                     // 1341
		// Force value to be current date (on server) upon insert                                                            // 1342
		autoValue: function () {                                                                                             // 1343
			if (this.isInsert) return new Date();else this.unset();                                                             // 1344
		}                                                                                                                    // 1346
	},                                                                                                                    // 1338
	"dateModification": {                                                                                                 // 1348
		type: Date,                                                                                                          // 1349
		label: "Date de la dernière modification",                                                                           // 1350
		optional: false,                                                                                                     // 1351
		// Force value to be current date (on server) upon insert                                                            // 1352
		autoValue: function () {                                                                                             // 1353
			if (this.isInsert) return new Date();                                                                               // 1354
			if (this.isUpdate) return new Date();                                                                               // 1355
		}                                                                                                                    // 1356
	}                                                                                                                     // 1348
}, {                                                                                                                   // 1294
	tracker: Tracker                                                                                                      // 1358
}); // ==============================================                                                                  // 1358
// specifiqueCodageDoc                                                                                                 // 1360
// ==============================================                                                                      // 1361
                                                                                                                       //
SCHEMA._specifiqueCodageDoc = new SimpleSchema({                                                                       // 1362
	// Pour les codages ACTE --------------------------------------------                                                 // 1363
	"ACTE_type": {                                                                                                        // 1364
		type: String,                                                                                                        // 1365
		label: "ACTE : Type de l'acte",                                                                                      // 1366
		allowedValues: SCHEMA_allowedValues("typeActe"),                                                                     // 1367
		autoform: {                                                                                                          // 1368
			options: SCHEMA_options("typeActe"),                                                                                // 1369
			afFieldInput: {                                                                                                     // 1370
				firstOption: "- choisir un type d'acte"                                                                            // 1371
			}                                                                                                                   // 1370
		},                                                                                                                   // 1368
		optional: true                                                                                                       // 1374
	},                                                                                                                    // 1364
	"ACTE_commune": {                                                                                                     // 1376
		type: String,                                                                                                        // 1377
		label: "ACTE : Commune de l'acte",                                                                                   // 1378
		regEx: /[0-9a-zA-Z]{17}$/,                                                                                           // 1379
		optional: true                                                                                                       // 1380
	},                                                                                                                    // 1376
	"ACTE_registre": {                                                                                                    // 1382
		type: String,                                                                                                        // 1383
		label: "ACTE : Registre de l'acte",                                                                                  // 1384
		regEx: /[0-9a-zA-Z]{17}$/,                                                                                           // 1385
		optional: true                                                                                                       // 1386
	},                                                                                                                    // 1382
	"ACTE_page": {                                                                                                        // 1388
		type: SimpleSchema.Integer,                                                                                          // 1389
		label: "ACTE : Page de l'acte",                                                                                      // 1390
		optional: true                                                                                                       // 1391
	},                                                                                                                    // 1388
	"ACTE_transcription": {                                                                                               // 1393
		type: String,                                                                                                        // 1394
		label: "ACTE : Transcription de l'acte",                                                                             // 1395
		optional: true                                                                                                       // 1396
	},                                                                                                                    // 1393
	// Pour le codage IMAGE --------------------------------------------                                                  // 1399
	"IMAGE_mode": {                                                                                                       // 1400
		type: String,                                                                                                        // 1401
		label: "IMAGE : Mode de l'image",                                                                                    // 1402
		allowedValues: SCHEMA_allowedValues("modeIMAGE"),                                                                    // 1403
		autoform: {                                                                                                          // 1404
			options: SCHEMA_options("modeIMAGE"),                                                                               // 1405
			afFieldInput: {                                                                                                     // 1406
				firstOption: "- choisir le mode d'affichage"                                                                       // 1407
			}                                                                                                                   // 1406
		},                                                                                                                   // 1404
		optional: true                                                                                                       // 1410
	},                                                                                                                    // 1400
	"IMAGE_px": {                                                                                                         // 1412
		type: String,                                                                                                        // 1413
		label: "IMAGE : nb de pixels en X de l'image",                                                                       // 1414
		optional: true                                                                                                       // 1415
	},                                                                                                                    // 1412
	"IMAGE_py": {                                                                                                         // 1417
		type: SimpleSchema.Integer,                                                                                          // 1418
		label: "IMAGE : Nb de pixels en Y de l'image",                                                                       // 1419
		optional: true                                                                                                       // 1420
	},                                                                                                                    // 1417
	"IMAGE_nbPages": {                                                                                                    // 1422
		type: String,                                                                                                        // 1423
		label: "IMAGE : Nb de pages de l'image",                                                                             // 1424
		optional: true                                                                                                       // 1425
	},                                                                                                                    // 1422
	// Pour le codage CARTE --------------------------------------------                                                  // 1428
	"CARTE_defX": {                                                                                                       // 1429
		type: SimpleSchema.Integer,                                                                                          // 1430
		label: "CARTE : Nb de pixels en largeur de chaque pavé",                                                             // 1431
		optional: true                                                                                                       // 1432
	},                                                                                                                    // 1429
	"CARTE_defY": {                                                                                                       // 1434
		type: SimpleSchema.Integer,                                                                                          // 1435
		label: "CARTE : Nb de pixels en hauteur de chaque pavé",                                                             // 1436
		optional: true                                                                                                       // 1437
	},                                                                                                                    // 1434
	"CARTE_xMin": {                                                                                                       // 1439
		type: SimpleSchema.Integer,                                                                                          // 1440
		label: "CARTE : coordonnée X minimum d'un pavé",                                                                     // 1441
		optional: true                                                                                                       // 1442
	},                                                                                                                    // 1439
	"CARTE_xMax": {                                                                                                       // 1444
		type: SimpleSchema.Integer,                                                                                          // 1445
		label: "CARTE : coordonnée X maximum d'un pavé",                                                                     // 1446
		optional: true                                                                                                       // 1447
	},                                                                                                                    // 1444
	"CARTE_yMin": {                                                                                                       // 1449
		type: SimpleSchema.Integer,                                                                                          // 1450
		label: "CARTE : coordonnée Y minimum d'un pavé",                                                                     // 1451
		optional: true                                                                                                       // 1452
	},                                                                                                                    // 1449
	"CARTE_yMax": {                                                                                                       // 1454
		type: SimpleSchema.Integer,                                                                                          // 1455
		label: "CARTE : coordonnée Y maximum d'un pavé",                                                                     // 1456
		optional: true                                                                                                       // 1457
	},                                                                                                                    // 1454
	"CARTE_urlLegende": {                                                                                                 // 1459
		type: String,                                                                                                        // 1460
		label: "CARTE : URL de la légende",                                                                                  // 1461
		optional: true                                                                                                       // 1462
	},                                                                                                                    // 1459
	// Pour le codage GEO_REF --------------------------------------------                                                // 1465
	"GEO_REF_coordPoint1": {                                                                                              // 1466
		type: SCHEMA._googleMap,                                                                                             // 1467
		label: "Coordonnées géographique point 1",                                                                           // 1468
		optional: true                                                                                                       // 1469
	},                                                                                                                    // 1466
	"GEO_REF_coordPoint2": {                                                                                              // 1471
		type: SCHEMA._googleMap,                                                                                             // 1472
		label: "Coordonnées géographique point 2",                                                                           // 1473
		optional: true                                                                                                       // 1474
	},                                                                                                                    // 1471
	"GEO_REF_tilesUrl": {                                                                                                 // 1476
		type: String,                                                                                                        // 1477
		label: "URL des tuiles",                                                                                             // 1478
		autoform: {                                                                                                          // 1479
			placeholder: "/marais/fondCartes/cartes_IGN/{z}/{x}/{y}.jpg"                                                        // 1480
		},                                                                                                                   // 1479
		optional: true                                                                                                       // 1482
	}                                                                                                                     // 1476
}, {                                                                                                                   // 1362
	tracker: Tracker                                                                                                      // 1484
}); // ==============================================                                                                  // 1484
// doc                                                                                                                 // 1491
// ==============================================                                                                      // 1492
                                                                                                                       //
SCHEMA.doc = new SimpleSchema({                                                                                        // 1493
	"id": {                                                                                                               // 1494
		type: String,                                                                                                        // 1495
		label: "Id",                                                                                                         // 1496
		optional: true // Présent uniquement sur le légacy                                                                   // 1497
                                                                                                                       //
	},                                                                                                                    // 1494
	"tags": {                                                                                                             // 1499
		type: Array,                                                                                                         // 1500
		label: "Référence des étiquettes",                                                                                   // 1501
		optional: true                                                                                                       // 1502
	},                                                                                                                    // 1499
	"tags.$": {                                                                                                           // 1504
		type: String,                                                                                                        // 1505
		label: "Etiquettes",                                                                                                 // 1506
		autoform: {                                                                                                          // 1507
			options: function () {                                                                                              // 1508
				return Tags.find({                                                                                                 // 1509
					objTypes: "DOC"                                                                                                   // 1509
				}, {                                                                                                               // 1509
					sort: {                                                                                                           // 1509
						label: 1                                                                                                         // 1509
					}                                                                                                                 // 1509
				}).map(function (obj) {                                                                                            // 1509
					return {                                                                                                          // 1510
						label: obj.label,                                                                                                // 1510
						value: obj._id                                                                                                   // 1510
					};                                                                                                                // 1510
				});                                                                                                                // 1511
			},                                                                                                                  // 1512
			afFieldInput: {                                                                                                     // 1513
				firstOption: "- choisir une étiquette"                                                                             // 1514
			}                                                                                                                   // 1513
		}                                                                                                                    // 1507
	},                                                                                                                    // 1504
	"titre": {                                                                                                            // 1518
		type: String,                                                                                                        // 1519
		label: "Titre court du document",                                                                                    // 1520
		optional: true,                                                                                                      // 1521
		// Absent pour les types ACTE                                                                                        // 1521
		autoform: {                                                                                                          // 1522
			placeholder: "ne rien mettre pour les actes"                                                                        // 1523
		}                                                                                                                    // 1522
	},                                                                                                                    // 1518
	"type": {                                                                                                             // 1526
		type: String,                                                                                                        // 1527
		label: "Type (selon nature du doc) (*)",                                                                             // 1528
		allowedValues: SCHEMA_allowedValues("typesDocs"),                                                                    // 1529
		autoform: {                                                                                                          // 1530
			options: SCHEMA_options("typesDocs"),                                                                               // 1531
			afFieldInput: {                                                                                                     // 1532
				firstOption: "- choisir un type"                                                                                   // 1533
			}                                                                                                                   // 1532
		},                                                                                                                   // 1530
		optional: false                                                                                                      // 1536
	},                                                                                                                    // 1526
	"codage": {                                                                                                           // 1538
		type: String,                                                                                                        // 1539
		label: "Codage (selon viewer) (*)",                                                                                  // 1540
		allowedValues: SCHEMA_allowedValues("codagesDocs"),                                                                  // 1541
		autoform: {                                                                                                          // 1542
			options: SCHEMA_options("codagesDocs"),                                                                             // 1543
			afFieldInput: {                                                                                                     // 1544
				firstOption: "- choisir un codage"                                                                                 // 1545
			}                                                                                                                   // 1544
		},                                                                                                                   // 1542
		optional: false                                                                                                      // 1548
	},                                                                                                                    // 1538
	"urlDocument": {                                                                                                      // 1550
		type: String,                                                                                                        // 1551
		label: "URL du document",                                                                                            // 1552
		optional: true,                                                                                                      // 1553
		// Absent pour les GROUPE                                                                                            // 1553
		autoform: {                                                                                                          // 1554
			defaultValue: function () {                                                                                         // 1555
				var codage = AutoForm.getFieldValue("codage");                                                                     // 1556
                                                                                                                       //
				switch (codage) {                                                                                                  // 1557
					case "IMAGE":                                                                                                     // 1558
						return "/arch/dvd_2013/2048x1536/";                                                                              // 1559
						break;                                                                                                           // 1560
                                                                                                                       //
					case "CARTE":                                                                                                     // 1561
						return "/cartes/";                                                                                               // 1562
						break;                                                                                                           // 1563
                                                                                                                       //
					case "GEO_REF":                                                                                                   // 1564
						return "/geo_refs/";                                                                                             // 1565
						break;                                                                                                           // 1566
                                                                                                                       //
					case "ACTE":                                                                                                      // 1567
						return "/arch/actes_0003/hd/";                                                                                   // 1568
						break;                                                                                                           // 1569
                                                                                                                       //
					case "VIDEO":                                                                                                     // 1570
						return "/arch/video_0001/video/";                                                                                // 1571
						break;                                                                                                           // 1572
                                                                                                                       //
					case "PDF":                                                                                                       // 1573
						return "/arch/pdf_0001/pdf/";                                                                                    // 1574
						break;                                                                                                           // 1575
                                                                                                                       //
					default:                                                                                                          // 1576
						return "";                                                                                                       // 1577
						break;                                                                                                           // 1578
				}                                                                                                                  // 1557
			}                                                                                                                   // 1580
		}                                                                                                                    // 1554
	},                                                                                                                    // 1550
	"urlIcone": {                                                                                                         // 1583
		type: String,                                                                                                        // 1584
		label: "URL de l'icône",                                                                                             // 1585
		optional: true,                                                                                                      // 1586
		// Absent pour les ACTE                                                                                              // 1586
		autoform: {                                                                                                          // 1587
			defaultValue: function () {                                                                                         // 1588
				var codage = AutoForm.getFieldValue("codage");                                                                     // 1589
                                                                                                                       //
				switch (codage) {                                                                                                  // 1590
					case "IMAGE":                                                                                                     // 1591
						return "/arch/dvd_2013/100x75/";                                                                                 // 1592
						break;                                                                                                           // 1593
                                                                                                                       //
					case "CARTE":                                                                                                     // 1594
						return "/cartes/";                                                                                               // 1595
						break;                                                                                                           // 1596
                                                                                                                       //
					case "GEO_REF":                                                                                                   // 1597
						return "/geo_refs/";                                                                                             // 1598
						break;                                                                                                           // 1599
                                                                                                                       //
					case "VIDEO":                                                                                                     // 1600
						return "/arch/video_0001/100x75/";                                                                               // 1601
						break;                                                                                                           // 1602
                                                                                                                       //
					case "PDF":                                                                                                       // 1603
						return "/arch/pdf_0001/100x75/";                                                                                 // 1604
						break;                                                                                                           // 1605
                                                                                                                       //
					default:                                                                                                          // 1606
						return "";                                                                                                       // 1607
						break;                                                                                                           // 1608
				}                                                                                                                  // 1590
			}                                                                                                                   // 1610
		}                                                                                                                    // 1587
	},                                                                                                                    // 1583
	"date": {                                                                                                             // 1613
		type: SCHEMA._date,                                                                                                  // 1614
		// Nom du schema visé                                                                                                // 1615
		doc: "_date",                                                                                                        // 1616
		label: "Date du document (*)",                                                                                       // 1617
		optional: false                                                                                                      // 1618
	},                                                                                                                    // 1613
	"source": {                                                                                                           // 1620
		type: SCHEMA._sourceDoc,                                                                                             // 1621
		// Nom du schema visé                                                                                                // 1622
		doc: "_sourceDoc",                                                                                                   // 1623
		label: "Source du document",                                                                                         // 1624
		optional: true                                                                                                       // 1625
	},                                                                                                                    // 1620
	"hauteur": {                                                                                                          // 1627
		type: SimpleSchema.Integer,                                                                                          // 1628
		label: "Hauteur de l'original (mm)",                                                                                 // 1629
		optional: true                                                                                                       // 1630
	},                                                                                                                    // 1627
	"largeur": {                                                                                                          // 1632
		type: SimpleSchema.Integer,                                                                                          // 1633
		label: "Hargeur de l'original (mm)",                                                                                 // 1634
		optional: true                                                                                                       // 1635
	},                                                                                                                    // 1632
	"comment": {                                                                                                          // 1637
		type: String,                                                                                                        // 1638
		label: "Commentaires sur le document",                                                                               // 1639
		optional: true                                                                                                       // 1640
	},                                                                                                                    // 1637
	"recherche": {                                                                                                        // 1642
		type: String,                                                                                                        // 1643
		label: "Commentaires de recherche",                                                                                  // 1644
		optional: true                                                                                                       // 1645
	},                                                                                                                    // 1642
	// ??????????????????????????????                                                                                     // 1651
	// A supprimer une fois les cartes et docs migrées et nettoyage des données                                           // 1652
	// ??????????????????????????????                                                                                     // 1653
	"titreLong": {                                                                                                        // 1654
		type: String,                                                                                                        // 1655
		label: "Titre long du document",                                                                                     // 1656
		optional: true                                                                                                       // 1657
	},                                                                                                                    // 1654
	"auteur": {                                                                                                           // 1659
		type: String,                                                                                                        // 1660
		label: "Auteur du document",                                                                                         // 1661
		optional: true                                                                                                       // 1662
	},                                                                                                                    // 1659
	// ??????????????????????????????                                                                                     // 1665
	"specif": {                                                                                                           // 1671
		type: SCHEMA._specifiqueCodageDoc,                                                                                   // 1672
		// Nom du schema visé                                                                                                // 1673
		doc: "_specifiqueCodageDoc",                                                                                         // 1674
		label: "Spécifique selon codage",                                                                                    // 1675
		optional: true                                                                                                       // 1676
	},                                                                                                                    // 1671
	"createdBy": {                                                                                                        // 1678
		type: String,                                                                                                        // 1679
		label: "Créé par",                                                                                                   // 1680
		optional: true,                                                                                                      // 1681
		// Force value to the creator id at creation, not modified after                                                     // 1682
		autoValue: function () {                                                                                             // 1683
			if (this.isInsert) return this.userId || idAdministrateurAppli;else this.unset();                                   // 1684
		}                                                                                                                    // 1686
	},                                                                                                                    // 1678
	"createdAt": {                                                                                                        // 1688
		type: Date,                                                                                                          // 1689
		label: "Créé le",                                                                                                    // 1690
		optional: false,                                                                                                     // 1691
		// Force value to be current date (on server) upon insert                                                            // 1692
		autoValue: function () {                                                                                             // 1693
			if (this.isInsert) return new Date();else this.unset();                                                             // 1694
		}                                                                                                                    // 1696
	},                                                                                                                    // 1688
	"lastUpdateAt": {                                                                                                     // 1698
		type: Date,                                                                                                          // 1699
		label: "Dernière modif. le",                                                                                         // 1700
		optional: false,                                                                                                     // 1701
		// Force value to be current date (on server) upon insert                                                            // 1702
		autoValue: function () {                                                                                             // 1703
			if (this.isInsert) return new Date();                                                                               // 1704
			if (this.isUpdate) return new Date();                                                                               // 1705
		}                                                                                                                    // 1706
	}                                                                                                                     // 1698
}, {                                                                                                                   // 1493
	tracker: Tracker                                                                                                      // 1708
}); // ==============================================                                                                  // 1708
// prof                                                                                                                // 1711
// ==============================================                                                                      // 1712
                                                                                                                       //
SCHEMA.prof = new SimpleSchema({                                                                                       // 1713
	"id": {                                                                                                               // 1714
		type: String,                                                                                                        // 1715
		label: "Id légacy",                                                                                                  // 1716
		optional: true // présent uniquement sur le légacy                                                                   // 1717
                                                                                                                       //
	},                                                                                                                    // 1714
	"M": {                                                                                                                // 1719
		type: String,                                                                                                        // 1720
		label: "Intitulé masculin (en minuscule)",                                                                           // 1721
		optional: true                                                                                                       // 1722
	},                                                                                                                    // 1719
	"F": {                                                                                                                // 1724
		type: String,                                                                                                        // 1725
		label: "Intitulé féminin (en minuscule)",                                                                            // 1726
		optional: true                                                                                                       // 1727
	}                                                                                                                     // 1724
}, {                                                                                                                   // 1713
	tracker: Tracker                                                                                                      // 1729
}); // ==============================================                                                                  // 1729
// acteArchive                                                                                                         // 1732
// ==============================================                                                                      // 1733
                                                                                                                       //
SCHEMA.acteArchives = new SimpleSchema({                                                                               // 1734
	"id": {                                                                                                               // 1735
		type: String,                                                                                                        // 1736
		label: "Id",                                                                                                         // 1737
		optional: true // Présent uniquement sur le légacy                                                                   // 1738
                                                                                                                       //
	},                                                                                                                    // 1735
	"commune": {                                                                                                          // 1740
		type: String,                                                                                                        // 1741
		label: "Commune",                                                                                                    // 1742
		regEx: /[0-9a-zA-Z]{17}$/,                                                                                           // 1743
		optional: false,                                                                                                     // 1744
		autoform: {                                                                                                          // 1745
			placeholder: "ID de la commune" // Placeholder                                                                      // 1746
                                                                                                                       //
		}                                                                                                                    // 1745
	},                                                                                                                    // 1740
	"registre": {                                                                                                         // 1749
		type: String,                                                                                                        // 1750
		label: "Registre",                                                                                                   // 1751
		regEx: /[0-9a-zA-Z]{17}$/,                                                                                           // 1752
		optional: false,                                                                                                     // 1753
		autoform: {                                                                                                          // 1754
			placeholder: "ID du registre" // Placeholder                                                                        // 1755
                                                                                                                       //
		}                                                                                                                    // 1754
	},                                                                                                                    // 1749
	"page": {                                                                                                             // 1758
		type: SimpleSchema.Integer,                                                                                          // 1759
		label: "Page",                                                                                                       // 1760
		optional: false,                                                                                                     // 1761
		autoform: {                                                                                                          // 1762
			placeholder: "page du registre" // Placeholder                                                                      // 1763
                                                                                                                       //
		}                                                                                                                    // 1762
	},                                                                                                                    // 1758
	"date": {                                                                                                             // 1766
		type: SCHEMA._date,                                                                                                  // 1767
		// Nom du schema visé                                                                                                // 1768
		doc: "_date",                                                                                                        // 1769
		label: "Date de l'acte",                                                                                             // 1770
		optional: false                                                                                                      // 1771
	},                                                                                                                    // 1766
	"type": {                                                                                                             // 1773
		type: String,                                                                                                        // 1774
		label: "Type d'acte",                                                                                                // 1775
		optional: false,                                                                                                     // 1776
		allowedValues: SCHEMA_allowedValues("typeActe"),                                                                     // 1777
		autoform: {                                                                                                          // 1778
			options: SCHEMA_options("typeActe"),                                                                                // 1779
			afFieldInput: {                                                                                                     // 1780
				firstOption: "- choisir un type d'acte"                                                                            // 1781
			}                                                                                                                   // 1780
		}                                                                                                                    // 1778
	},                                                                                                                    // 1773
	"pers_nom": {                                                                                                         // 1785
		type: String,                                                                                                        // 1786
		label: "Nom de la personne",                                                                                         // 1787
		optional: false,                                                                                                     // 1788
		autoform: {                                                                                                          // 1789
			placeholder: "nom en majuscule (ajouter ? si incertain)" // Placeholder                                             // 1790
                                                                                                                       //
		}                                                                                                                    // 1789
	},                                                                                                                    // 1785
	"pers_prenoms": {                                                                                                     // 1794
		type: String,                                                                                                        // 1795
		label: "Prénoms de la personne",                                                                                     // 1796
		optional: false,                                                                                                     // 1797
		autoform: {                                                                                                          // 1798
			placeholder: "prénoms séparés par , (ajouter ? si incertain)" // Placeholder                                        // 1799
                                                                                                                       //
		}                                                                                                                    // 1798
	},                                                                                                                    // 1794
	"pers_id": {                                                                                                          // 1802
		type: String,                                                                                                        // 1803
		label: "ID de la personne",                                                                                          // 1804
		regEx: /[0-9a-zA-Z]{17}$/,                                                                                           // 1805
		optional: true,                                                                                                      // 1806
		autoform: {                                                                                                          // 1807
			placeholder: "ID de la personne dans la base" // Placeholder                                                        // 1808
                                                                                                                       //
		}                                                                                                                    // 1807
	},                                                                                                                    // 1802
	"pers_age": {                                                                                                         // 1811
		type: Number,                                                                                                        // 1812
		label: "Age de la personne (mariage, décès)",                                                                        // 1813
		optional: true,                                                                                                      // 1814
		autoform: {                                                                                                          // 1815
			placeholder: "âge de la personne (années décimales)" // Placeholder                                                 // 1816
                                                                                                                       //
		}                                                                                                                    // 1815
	},                                                                                                                    // 1811
	"pere_nom": {                                                                                                         // 1819
		type: String,                                                                                                        // 1820
		label: "Nom du père",                                                                                                // 1821
		optional: true,                                                                                                      // 1822
		autoform: {                                                                                                          // 1823
			placeholder: "nom en majuscule (ajouter ? si incertain)" // Placeholder                                             // 1824
                                                                                                                       //
		}                                                                                                                    // 1823
	},                                                                                                                    // 1819
	"pere_prenoms": {                                                                                                     // 1827
		type: String,                                                                                                        // 1828
		label: "Prénoms du père",                                                                                            // 1829
		optional: true,                                                                                                      // 1830
		autoform: {                                                                                                          // 1831
			placeholder: "prénoms séparés par , (ajouter ? si incertain)" // Placeholder                                        // 1832
                                                                                                                       //
		}                                                                                                                    // 1831
	},                                                                                                                    // 1827
	"pere_id": {                                                                                                          // 1835
		type: String,                                                                                                        // 1836
		label: "ID du père dans la base",                                                                                    // 1837
		regEx: /[0-9a-zA-Z]{17}$/,                                                                                           // 1838
		optional: true,                                                                                                      // 1839
		autoform: {                                                                                                          // 1840
			placeholder: "ID de la personne dans la base" // Placeholder                                                        // 1841
                                                                                                                       //
		}                                                                                                                    // 1840
	},                                                                                                                    // 1835
	"mere_nom": {                                                                                                         // 1844
		type: String,                                                                                                        // 1845
		label: "Nom de la mère",                                                                                             // 1846
		optional: true,                                                                                                      // 1847
		autoform: {                                                                                                          // 1848
			placeholder: "nom en majuscule (ajouter ? si incertain)" // Placeholder                                             // 1849
                                                                                                                       //
		}                                                                                                                    // 1848
	},                                                                                                                    // 1844
	"mere_prenoms": {                                                                                                     // 1852
		type: String,                                                                                                        // 1853
		label: "Prénoms de la mère",                                                                                         // 1854
		optional: true,                                                                                                      // 1855
		autoform: {                                                                                                          // 1856
			placeholder: "prénoms séparés par , (ajouter ? si incertain)" // Placeholder                                        // 1857
                                                                                                                       //
		}                                                                                                                    // 1856
	},                                                                                                                    // 1852
	"mere_id": {                                                                                                          // 1860
		type: String,                                                                                                        // 1861
		label: "ID de la mère dans la base",                                                                                 // 1862
		regEx: /[0-9a-zA-Z]{17}$/,                                                                                           // 1863
		optional: true,                                                                                                      // 1864
		autoform: {                                                                                                          // 1865
			placeholder: "ID de la personne dans la base" // Placeholder                                                        // 1866
                                                                                                                       //
		}                                                                                                                    // 1865
	},                                                                                                                    // 1860
	"conjoint_nom": {                                                                                                     // 1869
		type: String,                                                                                                        // 1870
		label: "Nom du conjoint",                                                                                            // 1871
		optional: true,                                                                                                      // 1872
		autoform: {                                                                                                          // 1873
			placeholder: "nom en majuscule (ajouter ? si incertain)" // Placeholder                                             // 1874
                                                                                                                       //
		}                                                                                                                    // 1873
	},                                                                                                                    // 1869
	"conjoint_prenoms": {                                                                                                 // 1877
		type: String,                                                                                                        // 1878
		label: "Prénoms du conjoint",                                                                                        // 1879
		optional: true,                                                                                                      // 1880
		autoform: {                                                                                                          // 1881
			placeholder: "prénoms séparés par , (ajouter ? si incertain)" // Placeholder                                        // 1882
                                                                                                                       //
		}                                                                                                                    // 1881
	},                                                                                                                    // 1877
	"conjoint_id": {                                                                                                      // 1885
		type: String,                                                                                                        // 1886
		label: "ID du conjoint dans la base",                                                                                // 1887
		regEx: /[0-9a-zA-Z]{17}$/,                                                                                           // 1888
		optional: true,                                                                                                      // 1889
		autoform: {                                                                                                          // 1890
			placeholder: "ID de la personne dans la base" // Placeholder                                                        // 1891
                                                                                                                       //
		}                                                                                                                    // 1890
	},                                                                                                                    // 1885
	"lieudit_nom": {                                                                                                      // 1894
		type: String,                                                                                                        // 1895
		label: "Lieu-dit de l'acte",                                                                                         // 1896
		optional: true,                                                                                                      // 1897
		autoform: {                                                                                                          // 1898
			placeholder: "lieu-dit de l'acte"                                                                                   // 1899
		}                                                                                                                    // 1898
	},                                                                                                                    // 1894
	"lieudit_id": {                                                                                                       // 1902
		type: String,                                                                                                        // 1903
		label: "ID du lieu-dit de l'acte",                                                                                   // 1904
		optional: true,                                                                                                      // 1905
		autoform: {                                                                                                          // 1906
			placeholder: "ID du lieu-dit de l'acte"                                                                             // 1907
		}                                                                                                                    // 1906
	},                                                                                                                    // 1902
	"comment": {                                                                                                          // 1910
		type: String,                                                                                                        // 1911
		label: "Commentaire (témoins, parrain, marraine...)",                                                                // 1912
		optional: true,                                                                                                      // 1913
		autoform: {                                                                                                          // 1914
			placeholder: "commentaire (témoins, parrain, marraine...)"                                                          // 1915
		}                                                                                                                    // 1914
	},                                                                                                                    // 1910
	"createdBy": {                                                                                                        // 1918
		type: String,                                                                                                        // 1919
		label: "Créé par",                                                                                                   // 1920
		optional: true,                                                                                                      // 1921
		// Force value to the creator id at creation, not modified after                                                     // 1922
		autoValue: function () {                                                                                             // 1923
			if (this.isInsert) return this.userId || idAdministrateurAppli;else this.unset();                                   // 1924
		}                                                                                                                    // 1926
	},                                                                                                                    // 1918
	"createdAt": {                                                                                                        // 1928
		type: Date,                                                                                                          // 1929
		label: "Créé le",                                                                                                    // 1930
		optional: false,                                                                                                     // 1931
		// Force value to be current date (on server) upon insert                                                            // 1932
		autoValue: function () {                                                                                             // 1933
			if (this.isInsert) return new Date();else this.unset();                                                             // 1934
		}                                                                                                                    // 1936
	},                                                                                                                    // 1928
	"lastUpdateAt": {                                                                                                     // 1938
		type: Date,                                                                                                          // 1939
		label: "Dernière modif. le",                                                                                         // 1940
		optional: false,                                                                                                     // 1941
		// Force value to be current date (on server) upon insert                                                            // 1942
		autoValue: function () {                                                                                             // 1943
			if (this.isInsert) return new Date();                                                                               // 1944
			if (this.isUpdate) return new Date();                                                                               // 1945
		}                                                                                                                    // 1946
	}                                                                                                                     // 1938
}, {                                                                                                                   // 1734
	tracker: Tracker                                                                                                      // 1948
});                                                                                                                    // 1948
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"usersDefaultPrefs.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// common/usersDefaultPrefs.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// ==============================================                                                                      // 1
// Valeur par défaut des Paramètres Client paramétrables par l'utilisateur                                             // 2
// ==============================================                                                                      // 3
usersDefaultPrefs = {                                                                                                  // 4
	// Couleurs par génération pour les arbres descendants explorables                                                    // 5
	"couleursGenArbreDescExpl": ["#D9EDF7", // Bleu clair Bootstrap                                                       // 6
	"#FFFFFF", // Blanc                                                                                                   // 8
	"#FCF8E3" // Jaune clair Bootstrap                                                                                    // 9
	]                                                                                                                     // 6
};                                                                                                                     // 4
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./server/donneesInitiales/addRegistres.js");
require("./server/donneesInitiales/chargementCadastres.js");
require("./common/calendrierRepublicain.js");
require("./common/common.js");
require("./common/commonParms.js");
require("./common/parms_liens.js");
require("./common/periodesHist.js");
require("./common/schemas.js");
require("./common/usersDefaultPrefs.js");
require("./server/parametres.js");
require("./server/serveur.js");
//# sourceMappingURL=app.js.map
